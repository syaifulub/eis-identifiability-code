# Data

## Raw data: `PreparedData.zip` (in the package root)

- **Source:** Falagario C, De Momi E, Mattos LS. *In vivo tissue bioimpedance dataset.* Scientific Data (2026), doi:10.1038/s41597-026-07652-y.
- **Repository:** Zenodo, doi:10.5281/zenodo.18769577 (file `PreparedData.zip`, version v1).
- **License:** Creative Commons Attribution 4.0 International (CC BY 4.0). The file is redistributed here **unchanged** for reproducibility. Please cite the data descriptor and the Zenodo record when you use it.
- **SHA-256:** `3d255d1e264a914c97e9a0d6f888d4f4af9e4be711dbfe974de12f902ce99edd`. This is identical to the checksum recorded in `results/reproducibility_manifest.json`.

Contents: in vivo bioimpedance recordings from two Yorkshire pigs, organised by original subset (A, B1, B2, C, D, E) and by experimental task (1–6). Each text file holds one recording. The columns are device state, frequency (kHz), |Z| (Ω), phase (°), resistance (Ω), reactance (Ω), scaled time stamp and tissue label.

## Derived data: `data/derived/`

| File | Description |
|---|---|
| `ecm_ready_complete_scans.csv` | The 20 complete 10-frequency spectra used for fitting (median of repeated readings per frequency). A copy is also in `results/tables/`. |
| `file_qc_summary.csv` | Per-file quality-control summary: raw rows, duplicates, frequencies present. |

### Other derived files read directly from the raw data

- **Repeated sweeps (51 sweeps):** reconstructed on the fly by `src/review/r2_core.py::sweeps()` from `raw/PreparedData`, which `run_all.sh` and the notebook unzip automatically.
- **Single-frequency recordings (E12):** read by `src/review/e12_placement.py`. Its per-recording summary is in `results/tables/e12_recordings.csv`.
