# Identifiability-aware equivalent-circuit estimation: code, data and results

This repository holds the code, data and results for the manuscript *Identifiability-Aware Parameter Estimation and Frequency-Band Assessment of Equivalent-Circuit Models: Application to In Vivo Tissue Bioimpedance* (under double-blind review; author names are withheld).

It contains everything needed to reproduce every number, table and figure of the main text and of Online Resource 1:
- all analysis scripts, including the additional analyses of the current version (`src/revision/`);
- the open-source package `eisvarpro`;
- the raw data (CC BY 4.0);
- run-level results.

## Contents

| Path | Contents |
|---|---|
| `EIS_Complete.ipynb` | Single notebook (Parts A–F) that writes and runs all scripts. For Google Colab or Jupyter. It keeps the item numbering of an earlier draft; use the tables below for the current numbering. |
| `run_all.sh` | Command-line alternative to the notebook, organised in stages. |
| `src/` | Benchmark and design scripts (Parts A–C). Core library: `eis_core.py` (original parameterisation) and `vp_core.py` (variable projection). |
| `src/review/` | Analyses E1–E14 and the generators of the supplementary tables. `r2_core.py` is the shared GLS-VarPro engine. |
| `src/revision/` | Additional analyses of the current version (band truncation of the measured spectra, noise sweep, retrospective test of Algorithm 2; Table 3, Tables S51–S53) and the vector figures 1–5, with their outputs. See `src/revision/README.txt`. |
| `eisvarpro/` | Open-source package v0.3.3: VarPro fitting, KK check, calibrated profile likelihood, band criterion, drift and reproducibility limits, reporting decision (Fig. 5). Has its own README and 9 unit tests. |
| `PreparedData.zip` | Raw dataset of Falagario et al. (2026), unchanged. See `data/README_DATA.md`. |
| `data/derived/` | The 20 complete spectra and the per-file QC summary. |
| `results/tables/` | Run-level and summary results (CSV/JSON) of the runs reported in the manuscript. |
| `results/figures/`, `results/figures_vp/` | Figures as produced by the scripts. |
| `results/rerun_same_env/` | Benchmark rerun and timing in a single environment (Tables S29, S31). |
| `manuscript_tables/` | LaTeX of the supplementary tables as included in Online Resource 1. |
| `manuscript_figures/` | Figure files of Online Resource 1 and of an earlier draft (the main-text Figs. 1–5 are produced by `src/revision/`). |
| `requirements.txt`, `LICENSE` | Dependencies; code licence (MIT). The data keep their CC BY 4.0 licence. |
| `MANIFEST.sha256` | SHA-256 checksums of every file in the package. |

## Quick start

Install the dependencies:

```bash
pip install -r requirements.txt
```

Run the verification stage (about 3 minutes):

```bash
bash run_all.sh verify
```

This stage does three things:
- runs the 9 unit tests of `eisvarpro`;
- recomputes the cluster-aware inference (E13) from the stored run-level results;
- recomputes the KK-consistent analyses and the error-model sensitivity (E14) from the raw data.

It then writes `manuscript_tables/supp_e13.tex` and `supp_e14.tex`. Their contents should match Tables S38–S49 of Online Resource 1.

### Full reproduction

| Stage | Command | Time (1 core) | Reproduces |
|---|---|---|---|
| A | `bash run_all.sh A` | ~75 min | Original benchmark, ECM screening, identifiability (stored results already included) |
| B | `bash run_all.sh B` | ~90 min | VarPro benchmark (Table 4, Fig. S16), profiles, timing |
| C | `bash run_all.sh C` | ~40 min | Band design (fixed density), sensitivity, nested M13, feature stability |
| E | `bash run_all.sh E` | ~10 min | First-round reanalyses (Tables S8–S12) |
| F | `bash run_all.sh F` | ~90 min | E1–E14: error model, calibration, HF correction, model selection, band factorial, mechanism, closed-form criterion, drift, between-recording variability, cluster-aware inference, KK-primary analyses; Figs. 1–5; Tables S13–S49 |
| rerun | `bash run_all.sh rerun` | ~3 h | Full Table 4 benchmark rerun and same-machine timing (Tables S29, S31) |
| revision | see below | ~10 min | Table 3, Tables S51–S53, vector Figs. 1–5 |

Notes on running:
- Stages can be combined, for example `bash run_all.sh B C E F`.
- Stages B–F overwrite `results/`. Keep a copy of the folder if you want to compare.
- Seeds are fixed (`SEED0 = 20261101`, seed = SEED0 + 1000·spectrum + run).
- Scripts that take long cache finished spectra in `results/cache_*`, so a run can be resumed.
- The notebook runs the same code. On Colab, upload the package ZIP, open the notebook and run all cells.

### Additional analyses of the current version (`src/revision/`)

These scripts need no new measurements; they reuse `src/review/r2_core.py`, the stored spectra and `results/tables/`, and find the repository root from their own location. Seeds are fixed; `eB_noise_sweep.py` reproduces `e5_band_factorial.py` exactly at 2.5% noise.

```bash
cd src/revision
python eA_band_truncation.py      # Table 3, Table S51   -> out_A/
python eB_noise_sweep.py          # Table S52            -> out_B/
python eB2_boundary.py            # boundary test        -> out_B/EB2_stats.json
python eC_algorithm2_retro.py     # Table S53            -> out_C/
python make_fig1_workflow.py      # Fig. 1 (vector)      -> figures/
python make_vector_figs.py        # Figs. 2-4 (vector)   -> figures/
python make_fig5_decision.py      # Fig. 5 (vector)      -> figures/  (run after make_fig1_workflow.py)
```

The figure scripts use the Liberation Sans font (metrically identical to Arial) when it is installed.

## Where each result comes from

### Main text

| Item | Script (output) |
|---|---|
| Fig. 1 (workflow) | `src/revision/make_fig1_workflow.py` |
| Fig. 2 (coverage) | data: `src/review/e1_calibrate.py` (`e1_coverage_runs_M11.csv`); figure: `src/revision/make_vector_figs.py` |
| Fig. 3 (closed-form criterion) | data: `src/review/e10_asymptotic.py`, `e10b_refined.py` (`e10_synthetic.csv`, `e10_bias.csv`, `Table_E10_measured.csv`); figure: `src/revision/make_vector_figs.py` |
| Fig. 4 (band design) | data: `src/review/e5_band_factorial.py` (`Table_E5_band_factorial.csv`, `e5_band_runs.csv`); figure: `src/revision/make_vector_figs.py` |
| Fig. 5 (decision rule) | `src/revision/make_fig5_decision.py`; implemented in `eisvarpro.assess` |
| Table 1 (circuits) | Model definitions in `src/review/r2_core.py` (`MODELS`) |
| Table 2 (identifiability) | `src/review/e1_calibrate.py` (`e1_intervals_M10.csv`, `e1_intervals_M11.csv`) |
| Table 3 (band truncation) | `src/revision/eA_band_truncation.py` (`src/revision/out_A/`) |
| Table 4 (VarPro success) | `src/run_vp.py`, `analyze_vp.py` (`Table_VP_performance.csv`) |
| Algorithm 2 (band screening), retrospective test | `src/revision/eC_algorithm2_retro.py` (`src/revision/out_C/`) |
| Noise sweep (Sect. 3.6) | `src/revision/eB_noise_sweep.py`, `eB2_boundary.py` (`src/revision/out_B/`) |

### Online Resource 1

| Tables | Script |
|---|---|
| S14–S28 | `make_supp_round2.py` (E1–E11) |
| S29, S31 | `make_supp_rerun.py` (writes S29 into `supp_moved.tex` and S31 into `supp_rerun.tex`) |
| S30 | `make_supp_refined.py` (E10b) |
| S32–S37 | `make_supp_e12.py` (E12) |
| S38–S42 | `make_supp_e13.py` (E13) |
| S45–S49 | `make_supp_e14.py` (E14) |
| S43–S44 | Model definitions, transcribed from `src/run_experiment.py` (`SPECS`), `src/eis_core.py` (`MODELS`), `src/nested_vp.py` and `src/review/r2_core.py` (`MODELS`) |
| S50 | Between-recording variability (E12; `make_supp_e12.py`) |
| S51 | `src/revision/eA_band_truncation.py` (`out_A/EA_runs.csv`) |
| S52 | `src/revision/eB_noise_sweep.py`, `eB2_boundary.py` (`out_B/`) |
| S53 | `src/revision/eC_algorithm2_retro.py` (`out_C/`) |
| S54 | Comparison with previous studies (text only) |

Tables S1–S13 come from the Part A–E tables in `results/tables/` (`Table_*.csv`).

Two figures were renamed for the manuscript:
- `results/figures_vp/FigVP1_success_vs_NFE.png` became `manuscript_figures/Fig15_varpro_success_vs_NFE.png` (VarPro success versus NFE).
- `FigVP2_M12_success_heatmap.png` became `FigS9_M12_varpro_heatmap.png` (per-spectrum M12 success).

## Data and citation

When using this package, cite the manuscript and the data:
- Falagario C, De Momi E, Mattos LS. In vivo tissue bioimpedance dataset. *Sci Data* (2026), doi:10.1038/s41597-026-07652-y.
- Zenodo record doi:10.5281/zenodo.18769577 (CC BY 4.0).

The raw file is included unchanged; its SHA-256 matches the value recorded in `results/reproducibility_manifest.json`.
