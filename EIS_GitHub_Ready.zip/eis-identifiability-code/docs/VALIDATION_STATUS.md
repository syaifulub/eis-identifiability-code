# Validation status of this GitHub packaging

The package was prepared from the user-supplied `EIS_Repository_Anonymous.zip`.

## Confirmed checks

- All **378 original scientific files and supporting files** listed in the original manifest (excluding the original top-level README) match their original SHA-256 digests. The top-level README was replaced with this repository overview and the original preserved in `docs/README_SOURCE_SNAPSHOT.md`.
- The raw archive SHA-256 matches `data/README_DATA.md` and its internal ZIP CRC check succeeds.
- The processed spectrum CSV contains 20 groups of 10 frequencies, as expected.
- The Jupyter notebook parses as JSON; the final GitHub ZIP passes its ZIP CRC check.
- The dependency-free integrity script `python scripts/validate_repository.py` passes.

## Not independently validated in this packaging session

- **Full scientific recomputation:** time-consuming model benchmarks, calibration simulations, and figures were not rerun.
- **Numerical package unit tests:** the available local environment had Python 3.13 with SciPy 1.17.0 and repeatedly aborted with a native double-free error inside `scipy.optimize.nnls` during `test_bounded_lstsq_matches_enumeration`. Therefore, the 9 unit tests could not be declared successful in that environment. This may be specific to that environment/library build; it is not proof that the original code is incorrect, nor is it proof that newer versions resolve the issue. The author-reported tested versions (including SciPy 1.18.1) are listed in `requirements-reported.txt` for independent verification.
- **Journal correspondence:** table numbers should be checked against the exact manuscript PDF selected for submission.

A reviewer can repeat the full checks in a clean, supported environment. Do not state that scientific analyses or tests were independently rerun merely because the repository integrity checks pass.
