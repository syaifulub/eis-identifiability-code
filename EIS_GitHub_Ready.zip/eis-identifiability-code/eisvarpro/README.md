# eisvarpro

Reliable equivalent-circuit inversion of tissue electrical impedance spectra.

`eisvarpro` implements the workflow of the manuscript *Identifiability-Aware Parameter Estimation and
Frequency-Band Assessment of Equivalent-Circuit Models: Application to In Vivo Tissue Bioimpedance*
(authors withheld for double-blind review):

1. **Kramers–Kronig screening** (linear Voigt-element test; spectra above 3% RMS residual are flagged).
2. **Variable-projection fitting** of the Cole + inductance and resistance–CPE–inductance models: the
   resistive and inductive coefficients are solved exactly by bound-constrained linear least squares,
   so only one or two nonlinear parameters are searched (dense grid + local refinement = global fit).
3. **Globally optimised profile likelihood** for the Cole relaxation time (and any other parameter), with an
   optional **parametric-bootstrap calibration** of the likelihood-ratio threshold (`calibrated_threshold`,
   or `assess(..., calibrate=True, sigma=...)`). With few frequencies and correlated errors the chi-square
   value 3.84 can give intervals that cover the truth markedly less often than 95%.
4. **Reporting decision** (v0.3.3, Fig. 5 of the paper): every reported parameter must be practically identifiable,
   i.e. its (optionally calibrated) 95% profile interval is closed and narrower than 1 decade (log10 parameters) or
   0.2 (α). Cole parameters are reported only when the characteristic frequency lies in the band and both log10 τ and
   log10 ΔR meet the criterion; otherwise the R–CPE–L descriptors (R∞, Q, α) that meet it are reported and band
   extension is recommended. Calibration is conditional on the fitted model and the assumed error model.

## Install
```
pip install .            # from this folder; requires numpy, scipy, pandas
```

## Use
Command line (CSV columns `frequency_hz, resistance_ohm, reactance_ohm`):
```
eisvarpro examples/porcine_bladder_10-100kHz.csv
eisvarpro examples/synthetic_cole_100Hz-100kHz.csv --json
```
Python:
```python
import pandas as pd
from eisvarpro import assess, format_report, profile
d = pd.read_csv('examples/porcine_bladder_10-100kHz.csv')
Z = d.resistance_ohm + 1j*d.reactance_ohm
r = assess(d.frequency_hz, Z)          # dict with KK check, both fits, tau profile, decision
print(format_report(r))
p = profile('rcpe_l', d.frequency_hz, Z, 'log10_Q')   # profile of any parameter
```
Example output for the 10–100 kHz porcine bladder spectrum: Cole relaxation parameters are *not*
estimable (fc below the band, τ interval ≈ 4 decades); the R–CPE–L descriptors are reported.

Thresholds (`kk_threshold_pct=3.0`, `width_log=1.0`, `width_alpha=0.2`) are the paper's practical-identifiability
criterion; stricter values (e.g. 0.5 decade) can be passed when an application needs more precision.

Calibrated intervals:
```python
from eisvarpro import calibrated_threshold, profile
c = calibrated_threshold('rcpe_l', f, Z, 'log10_Q', n_boot=200, sigma=Sigma)  # Sigma: 2N x 2N covariance shape
P = profile('rcpe_l', f, Z, 'log10_Q', threshold=c)                           # of the stacked relative residual
```
`sigma=None` assumes independent errors. R–CPE–L descriptors are band-specific: report the band and the
high-frequency correction model with them.

Measurement design and reproducibility (`eisvarpro.design`, v0.3):
```python
from eisvarpro import band_criterion, rcpe_bias, cross_sweep_check, drift_variance, between_recording_sd, reproducibility_limits
c = band_criterion(f, Z)            # Gamma and detection limit f_c* = f_min/Gamma: tau identifiable only if f_c > f_c*
b = rcpe_bias(f, Z, fc_hz=300.0)    # predicted bias of log10 Q and alpha if the dispersion lies at 300 Hz
k = cross_sweep_check(f, sweeps, 'alpha')   # pairwise agreement of repeated sweeps within calibrated intervals
d = drift_variance([(est_rec1, se_rec1), (est_rec2, se_rec2)])   # REML drift SD between sweeps
b = between_recording_sd([logR_site_a, logR_site_b])              # pooled SD between replicate recordings (v0.3.2)
L = reproducibility_limits(s_fit, d['tau_drift'], b['sd'], differences=tissue_diffs)   # r = 2.77 s_w, R = 2.77 sqrt(s_w^2 + s_b^2)
```
Calibrated intervals describe one recording. When descriptors are compared across placements, sessions or probes,
use the reproducibility limit R, which includes the between-recording component.
The band criterion is a closed-form asymptotic result (valid for f_min/f_c >~ 1): the 95% width of the log10 tau
interval is about 2 z sigma (f_min/f_c)^alpha / (alpha ln10 D), with D computed from the spectrum.

## Tests
`python -m pytest tests` (nine tests: exact bounded solver, wide-band and narrow-band synthetic
spectra, real example, calibrated threshold, band criterion and bias formula, drift variance, refined width, reproducibility limits).

## Citation and data
Please cite the paper above. The example spectrum is taken from the in vivo tissue bioimpedance dataset
of Falagario et al., *Scientific Data* (2026), doi:10.1038/s41597-026-07652-y.

## License
MIT (see LICENSE).
