"""eisvarpro - reliable equivalent-circuit inversion of tissue impedance spectra by variable projection,
with Kramers-Kronig screening, globally optimised profile likelihood and a band-coverage reporting rule."""
from .core import MODELS, VarPro, bounded_lstsq, global_min
from .analysis import kk_check, fit, profile, calibrated_threshold, assess, format_report
from .design import band_criterion, predicted_tau_width, rcpe_bias, cross_sweep_check, drift_variance, between_recording_sd, reproducibility_limits
__version__ = '0.3.3'
__all__ = ['MODELS', 'VarPro', 'bounded_lstsq', 'global_min', 'kk_check', 'fit', 'profile', 'calibrated_threshold', 'band_criterion', 'predicted_tau_width', 'rcpe_bias', 'cross_sweep_check', 'drift_variance', 'between_recording_sd', 'reproducibility_limits', 'assess', 'format_report']
