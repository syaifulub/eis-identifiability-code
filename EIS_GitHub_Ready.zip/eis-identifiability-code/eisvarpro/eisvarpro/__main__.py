"""Command line: python -m eisvarpro spectrum.csv
CSV columns: frequency_hz, resistance_ohm, reactance_ohm (one row per frequency)."""
import sys, json
import numpy as np, pandas as pd
from .analysis import assess, format_report

def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print(__doc__); return 1
    d = pd.read_csv(argv[0]); r = assess(d.frequency_hz.to_numpy(float), d.resistance_ohm.to_numpy(float) + 1j*d.reactance_ohm.to_numpy(float))
    print(format_report(r))
    if '--json' in argv:
        conv = lambda o: o.tolist() if isinstance(o, np.ndarray) else float(o) if isinstance(o, np.floating) else str(o)
        print(json.dumps(r, default=conv, indent=2))
    return 0

if __name__ == '__main__':
    sys.exit(main())
