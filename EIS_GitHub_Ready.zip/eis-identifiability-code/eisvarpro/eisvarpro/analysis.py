"""Kramers-Kronig check, model fitting, profile likelihood and the reporting decision."""
import math
import numpy as np
from .core import MODELS, VarPro, global_min

def kk_check(f, Z, n_voigt=5):
    """Linear Kramers-Kronig test: |Z|-weighted fit of R + jwL + 1/(jwC) + n_voigt Voigt elements
    log-spaced over the band. Returns the RMS and maximum relative residual (%)."""
    w = 2*np.pi*np.asarray(f, float); Z = np.asarray(Z, complex)
    taus = np.logspace(np.log10(1/w.max()), np.log10(1/w.min()), n_voigt)
    A = np.array([np.ones_like(w)+0j, 1j*w, 1/(1j*w)] + [1/(1+1j*w*t) for t in taus]).T; wt = 1/np.abs(Z)
    Ar = np.vstack([(A*wt[:, None]).real, (A*wt[:, None]).imag]); br = np.r_[(Z*wt).real, (Z*wt).imag]
    c, *_ = np.linalg.lstsq(Ar, br, rcond=None); zk = A @ c
    r = np.r_[(zk.real-Z.real)/np.abs(Z), (zk.imag-Z.imag)/np.abs(Z)]
    return dict(kk_rms_pct=100*float(np.sqrt(np.mean(r**2))), kk_max_pct=100*float(np.max(np.abs(r))))

def fit(model, f, Z):
    """Global VarPro fit. Returns parameters, NRMSE and information criteria."""
    vp = VarPro(model, f, Z); rss, eta = global_min(vp); c, _ = vp.coef(eta); sp = MODELS[model]
    n = 2*vp.N; k = len(sp['nl']) + len(sp['lin']); aic = n*math.log(rss/n) + 2*k
    p = dict(zip(sp['nl'], eta)); p.update(dict(zip(sp['lin'], c)))
    if model == 'rcpe_l': p['Q'] = 1/p.pop('invQ')
    if model == 'cole_l':
        p['tau'] = 10**p['log10_tau']; p['fc_hz'] = 1/(2*math.pi*p['tau']); p['R0'] = p['Rinf'] + p['dR']
    return dict(model=model, params=p, eta=eta, rss=rss, NRMSE=math.sqrt(rss/vp.N), AICc=aic + 2*k*(k+1)/max(n-k-1, 1), n_obs=n)

def _ci(grid, lr, thr=3.84):
    i0 = int(np.argmin(lr))
    def cross(a, b): return grid[a] + (thr-lr[a])*(grid[b]-grid[a])/(lr[b]-lr[a]) if lr[b] != lr[a] else grid[a]
    j = i0
    while j > 0 and lr[j-1] <= thr: j -= 1
    lo = cross(j, j-1) if j > 0 else grid[0]
    j = i0
    while j < len(grid)-1 and lr[j+1] <= thr: j += 1
    hi = cross(j, j+1) if j < len(grid)-1 else grid[-1]
    return dict(ci_low=float(lo), ci_high=float(hi), ci_width=float(hi-lo), closed=bool(lr[0] > thr and lr[-1] > thr))

def _rss_fixed(model, f, Z, param, value):
    """Globally minimised RSS with one parameter fixed at `value` (profile scale)."""
    sp = MODELS[model]
    if param in sp['nl']:
        return global_min(VarPro(model, f, Z), fixed_nl=(sp['nl'].index(param), value))[0]
    name = param.replace('log10_', ''); sign = 1
    if name == 'Q': name, sign = 'invQ', -1
    j = sp['lin'].index(name); return global_min(VarPro(model, f, Z, fix=(j, 10**(sign*value))))[0]

def _profile_value(F, param):
    p = F['params']
    if param in ('log10_tau', 'alpha'): return p[param]
    return math.log10(p[param.replace('log10_', '')])

def calibrated_threshold(model, f, Z, param, n_boot=200, sigma=None, level=0.95, seed=0):
    """Parametric-bootstrap critical value of the profile likelihood-ratio statistic.
    Synthetic spectra are drawn from the fitted model with Gaussian noise on the stacked relative residual
    [Re; Im] / max(|Z|, 1); `sigma` (2N x 2N) gives its covariance shape (default: independent), scaled so that the
    expected RSS equals the observed RSS. Returns the `level` quantile of LR evaluated at the true value, to be used
    in place of 3.84. With correlated errors, the chi-square value can give substantially under-covering intervals."""
    f = np.asarray(f, float); Z = np.asarray(Z, complex); N = len(f); n = 2*N
    F = fit(model, f, Z); sp = MODELS[model]; k = len(sp['nl']) + len(sp['lin'])
    S = np.eye(n) if sigma is None else np.asarray(sigma, float)
    S = S*F['rss']/(np.trace(S)*(1 - k/n)); Lc = np.linalg.cholesky(S)
    w = 2*np.pi*f; vp = VarPro(model, f, Z); from .core import basis
    c, _ = vp.coef(F['eta']); zt = basis(model, F['eta'], w) @ c; truth = _profile_value(F, param)
    rng = np.random.default_rng(seed); sc = np.maximum(np.abs(zt), 1.0); lr = []
    for _ in range(n_boot):
        e = Lc @ rng.standard_normal(n); z = zt + sc*(e[:N] + 1j*e[N:])
        rmin = fit(model, f, z)['rss']; rf = _rss_fixed(model, f, z, param, truth)
        lr.append(n*math.log(max(rf, rmin)/rmin))
    return float(np.quantile(lr, level))

def profile(model, f, Z, param, n_grid=41, threshold=3.84):
    """Globally optimised profile likelihood (LR = n log(RSS/RSS_min), 95% threshold 3.84) for a
    nonlinear parameter ('log10_tau', 'alpha') or a log10 linear coefficient ('log10_dR', 'log10_Rinf',
    'log10_L', 'log10_Q')."""
    sp = MODELS[model]; base = fit(model, f, Z); n = base['n_obs']; rss_min = base['rss']
    if param in sp['nl']:
        i = sp['nl'].index(param); grid = np.linspace(sp['lo'][i], sp['hi'][i], n_grid)
        grid = np.unique(np.r_[grid, base['eta'][i] + np.linspace(-0.05, 0.05, 11)*(sp['hi'][i]-sp['lo'][i])].clip(sp['lo'][i], sp['hi'][i]))
        vp = VarPro(model, f, Z); prof = np.array([global_min(vp, fixed_nl=(i, g))[0] for g in grid])
    else:
        name = param.replace('log10_', ''); sign = 1
        if name == 'Q': name, sign = 'invQ', -1
        j = sp['lin'].index(name); lo, hi = np.log10(sp['llo'][j]), np.log10(sp['lhi'][j])
        if sign < 0: lo, hi = -hi, -lo
        est = math.log10(base['params']['Q'] if name == 'invQ' else base['params'][name])
        grid = np.unique(np.r_[np.linspace(lo, hi, n_grid), est + np.linspace(-0.05, 0.05, 11)*(hi-lo)].clip(lo, hi))
        prof = np.array([global_min(VarPro(model, f, Z, fix=(j, 10**(sign*g))))[0] for g in grid])
    rss_min = min(rss_min, prof.min()); lr = n*np.log(prof/rss_min)
    return dict(param=param, grid=grid, LR=lr, threshold=threshold, **_ci(grid, lr, threshold))

def _criterion(P, param, width_log, width_alpha):
    lim = width_alpha if param == 'alpha' else width_log
    return bool(P['closed'] and P['ci_width'] < lim)

def assess(f, Z, kk_threshold_pct=3.0, width_log=1.0, width_alpha=0.2, calibrate=False, sigma=None, n_boot=200, seed=0,
           tau_ci_max_decades=None):
    """Full workflow: KK screening, VarPro fits of Cole+L and R-CPE-L, profile likelihood of every parameter that
    might be reported, and the reporting decision (Fig. 5 of the paper). A parameter is practically identifiable when
    its 95% profile interval is closed and narrower than `width_log` decades (log10 parameters) or `width_alpha`
    (alpha); the same criterion applies to every reported parameter. Cole parameters are reported only when f_c lies
    in the band and both log10 tau and log10 dR meet the criterion; otherwise the R-CPE-L descriptors that meet it are
    reported. calibrate=True replaces the chi-square threshold by parametric-bootstrap critical values (one per
    parameter; `sigma` = covariance shape of the stacked relative residual): calibration is conditional on the fitted
    model and on that error model. `tau_ci_max_decades` is a deprecated alias of `width_log`."""
    if tau_ci_max_decades is not None: width_log = tau_ci_max_decades
    f = np.asarray(f, float); Z = np.asarray(Z, complex); o = np.argsort(f); f, Z = f[o], Z[o]
    kk = kk_check(f, Z); cole = fit('cole_l', f, Z); cpe = fit('rcpe_l', f, Z)
    def prof(model, param):
        thr = calibrated_threshold(model, f, Z, param, n_boot, sigma, seed=seed) if calibrate else 3.84
        P = profile(model, f, Z, param, threshold=thr); P = {k: v for k, v in P.items() if k not in ('grid', 'LR')}
        P['identifiable'] = _criterion(P, param, width_log, width_alpha); return P
    cole_prof = {p: prof('cole_l', p) for p in ['log10_tau', 'log10_dR', 'alpha', 'log10_Rinf']}
    cpe_prof = {p: prof('rcpe_l', p) for p in ['log10_Q', 'alpha', 'log10_Rinf']}
    fc = cole['params']['fc_hz']; in_band = f.min() <= fc
    core_ok = cole_prof['log10_tau']['identifiable'] and cole_prof['log10_dR']['identifiable']
    reportable = bool(in_band and core_ok)
    if reportable:
        ok = [p for p, P in cole_prof.items() if P['identifiable']]; bad = [p for p in cole_prof if p not in ok]
        decision = ('Cole parameters are estimable: report ' + ', '.join(ok) + ' with their profile intervals'
                    + (f"; do not report {', '.join(bad)} (interval not closed or too wide)." if bad else '.'))
    else:
        why = []
        if not in_band: why.append(f'the estimated fc ({fc:.3g} Hz) lies below the band (f_min = {f.min():.3g} Hz)')
        for p in ['log10_tau', 'log10_dR']:
            P = cole_prof[p]
            if not P['closed']: why.append(f'the 95% profile interval of {p} is not closed')
            elif not P['identifiable']: why.append(f"the {p} interval spans {P['ci_width']:.2f} decades")
        ok = [p for p, P in cpe_prof.items() if P['identifiable']]
        decision = ('Cole relaxation parameters are not estimable because ' + ' and '.join(why) + '. '
                    + (f"Report the R-CPE-L descriptors {', '.join(ok)} (band-specific; state band, high-frequency correction and probe)"
                       if ok else 'No R-CPE-L descriptor meets the identifiability criterion')
                    + '; do not interpret tau, dR, R0 or fc. To estimate them, extend the band down to the characteristic frequency.')
    warn = None if kk['kk_rms_pct'] < kk_threshold_pct else \
        f"Kramers-Kronig residual {kk['kk_rms_pct']:.2f}% exceeds {kk_threshold_pct}%: the spectrum may be inconsistent; interpret with caution."
    return dict(kk=kk, cole_l=cole, rcpe_l=cpe, tau_profile=cole_prof['log10_tau'], cole_profiles=cole_prof, rcpe_profiles=cpe_prof,
                fc_in_band=bool(in_band), cole_reportable=reportable, preferred_by_AICc='cole_l' if cole['AICc'] < cpe['AICc'] else 'rcpe_l',
                decision=decision, kk_warning=warn)

def format_report(r):
    c, q = r['cole_l']['params'], r['rcpe_l']['params']; t = r['tau_profile']
    lines = [f"Kramers-Kronig RMS residual: {r['kk']['kk_rms_pct']:.2f}%" + (f"  WARNING: {r['kk_warning']}" if r['kk_warning'] else ''),
             f"R-CPE-L : Rinf = {q['Rinf']:.4g} ohm, Q = {q['Q']:.4g} S s^alpha, alpha = {q['alpha']:.3f}, L = {q['L']:.3g} H, NRMSE = {r['rcpe_l']['NRMSE']:.4f}",
             f"Cole+L  : Rinf = {c['Rinf']:.4g} ohm, dR = {c['dR']:.4g} ohm, fc = {c['fc_hz']:.4g} Hz, alpha = {c['alpha']:.3f}, NRMSE = {r['cole_l']['NRMSE']:.4f}",
             f"log10 tau 95% profile interval: [{t['ci_low']:.2f}, {t['ci_high']:.2f}] (width {t['ci_width']:.3f} decades, closed: {t['closed']}, LR threshold {t.get('threshold', 3.84):.2f})",
             f"Preferred by AICc: {r['preferred_by_AICc']}", f"DECISION: {r['decision']}"]
    return '\n'.join(lines)
