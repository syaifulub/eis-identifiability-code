"""Core numerics: models, exact bounded linear solve and variable projection (VarPro).

Impedance models (Z in ohm, w = 2*pi*f in rad/s):
  cole_l : Z = Rinf + dR / (1 + (j w tau)^alpha) + j w L      nonlinear (log10 tau, alpha), linear (Rinf, dR, L)
  rcpe_l : Z = Rinf + (1/Q) (j w)^(-alpha)       + j w L      nonlinear (alpha),            linear (Rinf, 1/Q, L)
All fits minimise J = mean_k |Z_model(w_k) - Z_k|^2 / max(|Z_k|, 1)^2 (relative complex residual).
"""
import itertools, math
import numpy as np
from scipy.optimize import nnls, least_squares, minimize_scalar

MODELS = {
    'cole_l': dict(nl=['log10_tau', 'alpha'], lo=np.array([-7.0, 0.30]), hi=np.array([1.0, 1.0]),
                   lin=['Rinf', 'dR', 'L'], llo=np.array([1e-3, 1e-3, 1e-9]), lhi=np.array([1e7, 1e8, 1.0])),
    'rcpe_l': dict(nl=['alpha'], lo=np.array([0.30]), hi=np.array([1.0]),
                   lin=['Rinf', 'invQ', 'L'], llo=np.array([1e-3, 1.0, 1e-9]), lhi=np.array([1e7, 1e12, 1.0])),
}

def basis(model, eta, w):
    jw = 1j*w; one = np.ones_like(w) + 0j
    if model == 'cole_l':
        return np.column_stack([one, 1/(1 + (jw*10**eta[0])**eta[1]), jw])
    if model == 'rcpe_l':
        return np.column_stack([one, jw**(-eta[0]), jw])
    raise KeyError(model)

def _enum_lstsq(A, b, lb, ub):
    k = A.shape[1]; s = np.linalg.norm(A, axis=0); s[s == 0] = 1.0; As = A/s
    best_c, best_v = None, math.inf
    for state in itertools.product((0, 1, 2), repeat=k):
        st = np.array(state); c = np.where(st == 1, lb, np.where(st == 2, ub, 0.0)); free = np.flatnonzero(st == 0)
        if len(free):
            c[free] = np.linalg.lstsq(As[:, free], b - A @ c, rcond=None)[0]/s[free]
            if np.any(c[free] < lb[free]*(1-1e-12)) or np.any(c[free] > ub[free]*(1+1e-12)): continue
        r = A @ c - b; v = float(r @ r)
        if v < best_v: best_v, best_c = v, c
    return best_c, best_v

def bounded_lstsq(A, b, lb, ub):
    """Exact solution of min ||A c - b||^2 subject to lb <= c <= ub (few columns):
    shifted NNLS, upper-bound clamping with KKT certificate, active-set enumeration fallback."""
    s = np.linalg.norm(A, axis=0); s[s == 0] = 1.0
    d, _ = nnls(A/s, b - A @ lb, maxiter=50*A.shape[1]); c = lb + d/s
    if np.all(c <= ub):
        r = A @ c - b; return c, float(r @ r)
    up = c > ub
    for _ in range(A.shape[1]):
        fr = ~up; cc = np.where(up, ub, lb)
        d, _ = nnls(A[:, fr]/s[fr], b - A[:, up] @ ub[up] - A[:, fr] @ lb[fr], maxiter=50*A.shape[1]); cc[fr] = lb[fr] + d/s[fr]
        new = up | (cc > ub)
        if np.array_equal(new, up): break
        up = new
    r = A @ cc - b; g = A.T @ r
    if np.all(cc <= ub*(1+1e-12)) and np.all(g[up] <= 1e-10*max(1.0, float(np.abs(g).max()))):
        return cc, float(r @ r)
    return _enum_lstsq(A, b, lb, ub)

class VarPro:
    """Reduced (variable-projection) problem for one spectrum and model. Optionally one linear
    coefficient can be fixed (used for profiling it)."""
    def __init__(self, model, f, Z, fix=None):
        self.model = model; self.sp = MODELS[model]; self.w = 2*np.pi*np.asarray(f, float); self.Z = np.asarray(Z, complex)
        self.wt = 1/np.maximum(np.abs(self.Z), 1.0); zw = self.Z*self.wt; self.b = np.r_[zw.real, zw.imag]; self.N = len(self.w)
        self.fix = fix                                    # (index, value) of a fixed linear coefficient
    def _system(self, eta):
        A = basis(self.model, eta, self.w)*self.wt[:, None]; A = np.vstack([A.real, A.imag]); b = self.b
        lb, ub = self.sp['llo'], self.sp['lhi']
        if self.fix is not None:
            j, v = self.fix; keep = [i for i in range(A.shape[1]) if i != j]
            return A[:, keep], b - A[:, j]*v, lb[keep], ub[keep], A, keep
        return A, b, lb, ub, A, list(range(A.shape[1]))
    def coef(self, eta):
        A, b, lb, ub, _, keep = self._system(np.asarray(eta, float)); c, rss = bounded_lstsq(A, b, lb, ub)
        if self.fix is not None:
            full = np.empty(len(keep)+1); full[keep] = c; full[self.fix[0]] = self.fix[1]; c = full
        return c, rss
    def rss(self, eta): return self.coef(eta)[1]
    def residual(self, eta):
        A, b, lb, ub, _, _ = self._system(np.asarray(eta, float)); c, _ = bounded_lstsq(A, b, lb, ub); return A @ c - b

def global_min(vp, fixed_nl=None, n1=81, grid2=(33, 15), polish=3):
    """Global minimum of the reduced RSS over the free nonlinear parameters (1-2 dims):
    dense grid followed by local refinement. fixed_nl=(index, value) fixes one nonlinear parameter."""
    lo, hi = vp.sp['lo'], vp.sp['hi']; D = len(lo); free = [i for i in range(D) if not (fixed_nl and i == fixed_nl[0])]
    def full(u):
        e = np.empty(D); e[free] = u
        if fixed_nl: e[fixed_nl[0]] = fixed_nl[1]
        return e
    if not free:
        e = full([]); return vp.rss(e), e
    if len(free) == 1:
        i = free[0]; g = np.linspace(lo[i], hi[i], n1); v = np.array([vp.rss(full([x])) for x in g]); k = int(v.argmin())
        r = minimize_scalar(lambda x: vp.rss(full([x])), bounds=(g[max(0, k-1)], g[min(n1-1, k+1)]), method='bounded', options={'xatol': 1e-8})
        return (r.fun, full([r.x])) if r.fun < v[k] else (v[k], full([g[k]]))
    g0 = np.linspace(lo[free[0]], hi[free[0]], grid2[0]); g1 = np.linspace(lo[free[1]], hi[free[1]], grid2[1])
    P = np.array([[a, b] for a in g0 for b in g1]); v = np.array([vp.rss(full(p)) for p in P])
    best, be = v.min(), full(P[int(v.argmin())])
    for k in np.argsort(v)[:polish]:
        r = least_squares(lambda u: vp.residual(full(u)), P[k], bounds=(lo[free], hi[free]), xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400)
        if 2*r.cost < best: best, be = 2*r.cost, full(r.x)
    return best, be
