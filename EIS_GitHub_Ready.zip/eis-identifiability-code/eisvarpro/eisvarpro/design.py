"""Measurement-design and reproducibility tools.

band_criterion   closed-form criterion for practical identifiability of the Cole relaxation time from a given band
rcpe_bias        predicted bias of the R-CPE-L descriptors when the true dispersion lies at f_c below the band
cross_sweep_check  assumption-light check of interval calibration from repeated sweeps of one recording
drift_variance   REML separation of fitting uncertainty and between-sweep drift
between_recording_sd  pooled between-recording SD (chi-square interval) from groups of replicate recordings
reproducibility_limits  ISO 5725-type repeatability and reproducibility limits and the share of differences exceeding them

Theory (see the paper): above f_c, with u = (j w tau)^-alpha and the CPE term w = (j w)^-alpha / Q, the Cole term is
w - w u + O(w u^2). Information on tau enters only through w u, giving
    W95(log10 tau) ~= 2 z sigma (f_min/f_c)^alpha / (alpha ln10 D),    Gamma = (alpha ln10 D W* / (2 z sigma))^(1/alpha),
and tau is practically identifiable (interval narrower than W* decades) when f_min / f_c < Gamma, i.e. when
f_c > f_min / Gamma (the detection limit). D depends on band, sampling and impedance composition, not on f_c.
The approximation is asymptotic (f_min/f_c >~ 1); below that, tau is identifiable in practice anyway.
"""
import itertools, math
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import chi2
from .analysis import fit, profile, calibrated_threshold, _profile_value

LN10 = math.log(10.0)

def _stack(c): return np.r_[c.real, c.imag]

def _rcpe_geometry(f, Z, p):
    w = 2*np.pi*np.asarray(f, float); jw = 1j*w; absZ = np.maximum(np.abs(np.asarray(Z, complex)), 1.0)
    cpe = jw**(-p['alpha'])/p['Q']
    J = np.column_stack([_stack(c) for c in (p['Rinf']/absZ, -cpe/absZ, -np.log(jw)*cpe/absZ, jw*p['L']/absZ)])
    ht = _stack(cpe*(jw/w.min())**(-p['alpha'])/absZ)
    return J, ht

def band_criterion(f, Z, sigma=None, width=1.0, z=1.96):
    """Closed-form band-coverage criterion for the Cole relaxation time.
    sigma: SD of each stacked real component of the relative residual (default: from the Cole+L fit, RSS/(2N-5)).
    width: required 95% interval width of log10 tau in decades; z: 1.96 or sqrt(calibrated critical value).
    Returns D, Gamma, the detection limit f_c* = f_min/Gamma (tau identifiable only if f_c > f_c*), and sigma."""
    f = np.asarray(f, float); Z = np.asarray(Z, complex); o = np.argsort(f); f, Z = f[o], Z[o]
    p = fit('rcpe_l', f, Z)['params']
    if sigma is None: sigma = math.sqrt(fit('cole_l', f, Z)['rss']/(2*len(f) - 5))
    J, ht = _rcpe_geometry(f, Z, p); P = np.eye(len(ht)) - J @ np.linalg.pinv(J); D = float(np.linalg.norm(P @ ht))
    G = (p['alpha']*LN10*D*width/(2*z*sigma))**(1/p['alpha'])
    return dict(D=D, Gamma=G, fc_detect_hz=float(f.min()/G), sigma=sigma, alpha=p['alpha'])

def predicted_tau_width(f, Z, fc_hz, sigma=None, z=1.96, refined=True):
    """95% interval width (decades) of log10 tau if the true characteristic frequency were fc_hz.
    refined=False: first-order closed form, W = 2 z sigma (f_min/f_c)^alpha / (alpha ln10 D), accurate when
    (f_min/f_c)^-alpha <~ 0.5 (the remainder of the expansion is bounded by |u|/(1-|u|)).
    refined=True (default): exact derivative of the Cole term with respect to 1/dR and the delta method for
    log tau = (log Q - log(1/dR))/alpha including the covariances with Q and alpha (equals the exact linearized width)."""
    f = np.asarray(f, float); Z = np.asarray(Z, complex); o = np.argsort(f); f, Z = f[o], Z[o]
    c = band_criterion(f, Z, sigma, 1.0, z); a = c['alpha']
    if not refined:
        return 2*z*c['sigma']*(f.min()/fc_hz)**a/(a*LN10*c['D'])
    p = fit('rcpe_l', f, Z)['params']; w = 2*np.pi*f; jw = 1j*w; absZ = np.maximum(np.abs(Z), 1.0)
    tau = 1/(2*np.pi*fc_hz); cpe = jw**(-a)/p['Q']; u = (jw*tau)**(-a); d = 1/(1 + u)**2
    cols = [p['Rinf']/absZ, d*(-cpe)/absZ, d*(-np.log(jw)*cpe)/absZ, jw*p['L']/absZ, -(cpe*u*d)/absZ]
    J = np.column_stack([_stack(x) for x in cols]); C = np.linalg.pinv(J.T @ J)*c['sigma']**2
    g = np.array([0, 1/a, -math.log(tau)/a, 0, -1/a])
    return float(2*z*math.sqrt(max(g @ C @ g, 0))/LN10)

def rcpe_bias(f, Z, fc_hz):
    """Predicted bias of log10 Q and alpha of the R-CPE-L fit when the data follow a Cole dispersion with
    characteristic frequency fc_hz below the band (linearized; accurate to a few percent for f_min/f_c >= 10)."""
    f = np.asarray(f, float); Z = np.asarray(Z, complex); p = fit('rcpe_l', f, Z)['params']
    J, ht = _rcpe_geometry(f, Z, p); b = -np.linalg.lstsq(J, ht, rcond=None)[0]; k = (f.min()/fc_hz)**(-p['alpha'])
    return dict(bias_log10_Q=float(b[1]*k/LN10), bias_alpha=float(b[2]*k), coef_log10_Q=float(b[1]/LN10), coef_alpha=float(b[2]))

def cross_sweep_check(f, sweeps, param='log10_Q', model='rcpe_l', calibrate=True, sigma=None, n_boot=100, seed=0):
    """Fit and profile every sweep of one recording; for each pair of sweeps test |theta_i - theta_j| <= sqrt(h_i^2 + h_j^2)
    (h: 95% half-width). With calibrated intervals and no drift, about 95% of pairs should pass."""
    est, half = [], []
    for k, Z in enumerate(sweeps):
        thr = calibrated_threshold(model, f, Z, param, n_boot, sigma, seed=seed + k) if calibrate else 3.84
        P = profile(model, f, Z, param, threshold=thr); est.append(_profile_value(fit(model, f, Z), param)); half.append(P['ci_width']/2)
    ok = [abs(est[i] - est[j]) <= math.hypot(half[i], half[j]) for i, j in itertools.combinations(range(len(est)), 2)]
    return dict(estimates=est, half_widths=half, pairs=len(ok), agreement=float(np.mean(ok)) if ok else float('nan'))

def drift_variance(groups):
    """REML estimate of the between-sweep drift SD tau_d from groups = [(estimates, standard_errors), ...] (one group per
    recording; standard error = 95% half-width / 1.96). Returns tau_d and the reproducibility half-width multiplier."""
    G = [(np.asarray(t, float), np.asarray(s, float)**2) for t, s in groups if len(t) >= 2]
    def reml(t2):
        ll = 0.0
        for th, s2 in G:
            v = s2 + t2; w = 1/v; mu = (w*th).sum()/w.sum(); ll += -0.5*(np.log(v).sum() + math.log(w.sum()) + (w*(th - mu)**2).sum())
        return ll
    top = 3*math.sqrt(4*max(np.var(th) for th, _ in G) + 1e-12)
    r = minimize_scalar(lambda t: -reml(t**2), bounds=(0, top), method='bounded', options={'xatol': 1e-10})
    t = r.x if reml(r.x**2) > reml(0.0) else 0.0
    return dict(tau_drift=float(t), loglik_ratio=float(2*(reml(t**2) - reml(0.0))))

def between_recording_sd(groups, level=0.95):
    """Pooled between-recording SD from groups of replicate values (e.g. log10 R of recordings of the same medium with the
    same probe, animal and frequency). Returns the degrees-of-freedom-weighted SD, its chi-square interval and df."""
    G = [np.asarray(g, float) for g in groups if len(g) > 1]
    nu = sum(len(g) - 1 for g in G)
    if nu == 0: raise ValueError('need at least one group with two or more recordings')
    s = math.sqrt(sum((len(g) - 1)*np.var(g, ddof=1) for g in G)/nu); a = (1 - level)/2
    return dict(sd=s, ci_low=s*math.sqrt(nu/chi2.ppf(1 - a, nu)), ci_high=s*math.sqrt(nu/chi2.ppf(a, nu)), df=nu)

def reproducibility_limits(s_fit, s_drift=0.0, s_between=0.0, differences=None):
    """Repeatability limit r = 2.77 s_w (s_w^2 = s_fit^2 + s_drift^2: fitting error and between-sweep drift) and
    reproducibility limit R = 2.77 sqrt(s_w^2 + s_between^2) (between-recording component), in the form of ISO 5725.
    Two values from the same recording (or from different recordings) differ by more than r (or R) with probability
    about 5% when nothing but measurement variability separates them. If differences are given (e.g. between tissues),
    the percentages exceeding r and R are returned as well."""
    s_w = math.hypot(s_fit, s_drift); out = dict(s_within=s_w, r=2.77*s_w, R=2.77*math.hypot(s_w, s_between))
    if differences is not None:
        d = np.abs(np.asarray(differences, float)); out.update(pct_gt_r=100*float(np.mean(d > out['r'])), pct_gt_R=100*float(np.mean(d > out['R'])))
    return out
