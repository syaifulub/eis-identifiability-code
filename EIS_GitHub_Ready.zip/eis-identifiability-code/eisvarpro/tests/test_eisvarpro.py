import itertools
import numpy as np, pandas as pd
from pathlib import Path
from eisvarpro import bounded_lstsq, assess, fit, kk_check
from eisvarpro.core import _enum_lstsq
EX = Path(__file__).parent.parent/'examples'

def synth(fmin, fc=500.0, noise=0.01, seed=0):
    rng = np.random.default_rng(seed); f = np.logspace(np.log10(fmin), 5, int(10*np.log10(1e5/fmin))+1); w = 2*np.pi*f
    Z = 1000 + 3000/(1+(1j*w/(2*np.pi*fc))**0.75) + 1j*w*1e-3
    return f, Z + noise*np.abs(Z)*(rng.standard_normal(len(f)) + 1j*rng.standard_normal(len(f)))/np.sqrt(2)

def test_bounded_lstsq_matches_enumeration():
    rng = np.random.default_rng(0)
    for _ in range(200):
        A = rng.standard_normal((20, 3)); b = rng.standard_normal(20); lb = np.full(3, -0.2); ub = np.full(3, 0.3)
        c1, v1 = bounded_lstsq(A, b, lb, ub); c2, v2 = _enum_lstsq(A, b, lb, ub)
        assert v1 <= v2*(1+1e-10) + 1e-12

def test_wide_band_cole_is_reportable():
    f, Z = synth(100.0, fc=500.0); r = assess(f, Z)
    assert r['cole_reportable'] and abs(r['cole_l']['params']['fc_hz']/500 - 1) < 0.2

def test_narrow_band_cole_is_not_reportable():
    f, Z = synth(1e4, fc=500.0, noise=0.025); r = assess(f, Z)
    assert not r['cole_reportable'] and 'not estimable' in r['decision']

def test_real_example_runs_and_kk():
    d = pd.read_csv(EX/'porcine_bladder_10-100kHz.csv'); Z = d.resistance_ohm + 1j*d.reactance_ohm
    assert kk_check(d.frequency_hz, Z)['kk_rms_pct'] < 3
    r = fit('rcpe_l', d.frequency_hz, Z); assert 0.02 < r['NRMSE'] < 0.03

def test_calibrated_threshold_white_noise():
    """Under independent noise the calibrated critical value should be of the order of the chi-square value."""
    import numpy as np
    from eisvarpro import calibrated_threshold
    f = np.arange(1, 11)*1e4; w = 2*np.pi*f
    Z = 1000 + 1/(2e-8*(1j*w)**0.8) + 1j*w*1e-3
    rng = np.random.default_rng(3); Z = Z + 0.02*np.abs(Z)*(rng.standard_normal(10) + 1j*rng.standard_normal(10))
    c = calibrated_threshold('rcpe_l', f, Z, 'alpha', n_boot=60, seed=1)
    assert 1.5 < c < 15

def test_band_criterion_and_bias():
    """Wide-band synthetic Cole data: tau must be detectable (f_c above the detection limit); bias formula matches a refit."""
    import numpy as np
    from eisvarpro import band_criterion, rcpe_bias, fit
    f = np.arange(1, 11)*1e4; w = 2*np.pi*f
    Rinf, a, Q, L = 1000.0, 0.8, 2e-8, 1e-3
    Z = Rinf + 1/(Q*(1j*w)**a) + 1j*w*L
    c = band_criterion(f, Z, sigma=0.01)
    assert c['Gamma'] > 1 and c['fc_detect_hz'] < 1e4
    fc = 100.0; tau = 1/(2*np.pi*fc); dR = tau**a/Q
    Zc = Rinf + dR/(1 + (1j*w*tau)**a) + 1j*w*L
    b = rcpe_bias(f, Z, fc); p = fit('rcpe_l', f, Zc)['params']
    assert abs((np.log10(p['Q']) - np.log10(Q)) - b['bias_log10_Q']) < 0.02
    assert abs((p['alpha'] - a) - b['bias_alpha']) < 0.005

def test_drift_variance_recovers_drift():
    import numpy as np
    from eisvarpro import drift_variance
    rng = np.random.default_rng(0); groups = []
    for i in range(30):
        mu = rng.normal(); se = np.full(4, 0.05); groups.append((mu + rng.normal(0, 0.2, 4) + rng.normal(0, 0.05, 4), se))
    t = drift_variance(groups)['tau_drift']
    assert 0.12 < t < 0.3

def test_refined_width_is_wider_and_finite():
    import numpy as np
    from eisvarpro import predicted_tau_width
    f = np.arange(1, 11)*1e4; w = 2*np.pi*f
    Z = 1000 + 1/(2e-8*(1j*w)**0.8) + 1j*w*1e-3
    a = predicted_tau_width(f, Z, 2000.0, sigma=0.01, refined=False); b = predicted_tau_width(f, Z, 2000.0, sigma=0.01, refined=True)
    assert np.isfinite(a) and np.isfinite(b) and b > 0.5*a


def test_reproducibility_limits():
    from eisvarpro import between_recording_sd, reproducibility_limits
    rng = np.random.default_rng(1)
    groups = [rng.normal(0, 0.1, 6) for _ in range(40)]
    b = between_recording_sd(groups); assert 0.08 < b['sd'] < 0.12 and b['ci_low'] < b['sd'] < b['ci_high'] and b['df'] == 200
    L = reproducibility_limits(0.03, 0.04, 0.12, differences=[0.01, 0.2, 0.5])
    assert abs(L['s_within'] - 0.05) < 1e-12 and abs(L['r'] - 0.1385) < 1e-9 and abs(L['R'] - 2.77*0.13) < 1e-9
    assert L['pct_gt_r'] > L['pct_gt_R']
