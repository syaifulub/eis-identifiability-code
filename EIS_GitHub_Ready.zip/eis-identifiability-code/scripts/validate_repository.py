#!/usr/bin/env python3
"""Static checks for this repository; only the Python standard library is used.

This script does not run scientific analyses, so passing it does NOT establish
numerical reproducibility, statistical correctness, or compatibility of SciPy.
"""
from pathlib import Path
import csv
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CHECK = [
    'README.md', 'LICENSE', 'requirements.txt', 'run_all.sh', 'PreparedData.zip',
    'EIS_Complete.ipynb', 'eisvarpro/eisvarpro/core.py',
    'eisvarpro/eisvarpro/analysis.py', 'eisvarpro/eisvarpro/design.py',
    'eisvarpro/tests/test_eisvarpro.py',
    'src/eis_core.py', 'src/vp_core.py',
    'data/derived/ecm_ready_complete_scans.csv',
    'results/tables/Table_VP_performance.csv',
    'results/reproducibility_manifest.json',
    'MANIFEST.sha256',
]
EXPECTED_RAW_SHA256 = '3d255d1e264a914c97e9a0d6f888d4f4af9e4be711dbfe974de12f902ce99edd'


def sha256(p):
    h = hashlib.sha256()
    with p.open('rb') as inp:
        for b in iter(lambda: inp.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def main():
    failed = []
    for rel in CHECK:
        if not (ROOT / rel).is_file():
            failed.append('Missing: ' + rel)
    if failed:
        for f in failed: print('FAIL', f)
        return 1

    entries = 0
    for ln in (ROOT / 'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
        if not ln.strip(): continue
        expected, name = ln.split('  ', 1)
        p = ROOT / name
        if not p.is_file(): failed.append('Missing manifest file: ' + name)
        elif sha256(p) != expected: failed.append('Checksum mismatch: ' + name)
        entries += 1
    if sha256(ROOT / 'PreparedData.zip') != EXPECTED_RAW_SHA256:
        failed.append('Original raw ZIP checksum changed')
    with zipfile.ZipFile(ROOT / 'PreparedData.zip') as z:
        bad = z.testzip()
        if bad is not None: failed.append('CRC failure inside raw ZIP: ' + bad)
        raw_entries = len(z.infolist())
    with (ROOT / 'data/derived/ecm_ready_complete_scans.csv').open(newline='', encoding='utf-8') as f:
        reader = list(csv.DictReader(f))
    counts = {}
    for r in reader:
        counts[r['source_file']] = counts.get(r['source_file'], 0) + 1
    if len(reader) != 200 or len(counts) != 20 or set(counts.values()) != {10}:
        failed.append('Derived spectra shape unexpected (expect 20 x 10 frequencies)')
    try:
        obj = json.loads((ROOT / 'EIS_Complete.ipynb').read_text(encoding='utf-8'))
        if 'cells' not in obj: failed.append('Notebook has no cells')
    except (ValueError, UnicodeError) as exc:
        failed.append('Malformed notebook JSON: ' + str(exc))
    if failed:
        for e in failed: print('FAIL:', e)
        return 1
    print('PASS: mandatory files,', entries, 'SHA256 entries,',raw_entries, 'raw ZIP entries; 20 spectra x 10 frequencies.')
    print('Note: numerical tests and full experiments are NOT run by this integrity check.')
    return 0

if __name__ == '__main__':
    sys.exit(main())
