"""analyze_vp.py - merge the variable-projection benchmark with the original runs and
produce comparison tables and figures (same spectra, seeds, budget and success rule)."""
import math, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
from vp_common import TAB
FIG = TAB.parent/'figures_vp'; FIG.mkdir(exist_ok=True)
CPS = [100, 200, 500, 1000, 1500, 2000]; TOL = 1e-3
OLD = ['HO', 'L-SHADE', 'ASHO-LSHADE', 'MS-TRF', 'L-SHADE+TRF', 'ASHO-LSHADE+TRF']
COL = dict(zip(['HO','L-SHADE','ASHO-LSHADE','MS-TRF','L-SHADE+TRF','ASHO-LSHADE+TRF','VP-L-SHADE','VP-ASHO-LSHADE','VP-MS-TRF','VP-L-SHADE+TRF','VP-Screen+TRF'],
 ['#bbbbbb','#f4a582','#d6604d','#b2182b','#c2a5cf','#9970ab','#4393c3','#92c5de','#1b7837','#2166ac','#5aae61']))
NEW = ['VP-L-SHADE', 'VP-ASHO-LSHADE', 'VP-MS-TRF', 'VP-L-SHADE+TRF', 'VP-Screen+TRF']

def load(model):
    if model == 'M12_DoubleColeL':
        o = pd.read_csv(TAB/'optimizer_runs_M12.csv').rename(columns={'ref': 'ref_old'})
    else:
        o = pd.read_csv(TAB/'optimizer_runs.csv'); o = o[o.model == model].rename(columns={'ref_NRMSE': 'ref_old'})
        tr = pd.read_csv(TAB/'convergence_traces.csv'); tr = tr[tr.model == model]
        tr = tr.pivot_table(index=['source_file', 'algorithm', 'run'], columns='NFE', values='best_NRMSE')
        tr.columns = [f'trace_{c}' for c in tr.columns]; o = o.merge(tr.reset_index(), on=['source_file', 'algorithm', 'run'], how='left')
    o = o[o.algorithm.isin(OLD)]
    n = pd.read_csv(TAB/f'vp_runs_{model}.csv')
    ref_old = o.groupby('source_file').ref_old.first()
    best_vp = n.groupby('source_file').NRMSE.min()
    ref = pd.concat([ref_old, best_vp], axis=1).min(axis=1)
    improved = ((ref_old - best_vp)/ref_old > TOL)
    d = pd.concat([o, n], ignore_index=True); d['ref'] = d.source_file.map(ref)
    d['rel_gap'] = (d.NRMSE - d.ref)/d.ref; d['success'] = d.rel_gap <= TOL
    for c in CPS: d[f'succ_{c}'] = (d[f'trace_{c}'] - d.ref)/d.ref <= TOL
    return d, ref_old, best_vp, improved

def first_success_nfe(row):
    for c in CPS:
        if row[f'succ_{c}']: return c
    return np.nan

summary, paired, refinfo = [], [], []
fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
for ax, model in zip(axes, ['M11_RCPEL', 'M10_ColeL', 'M12_DoubleColeL']):
    d, ref_old, best_vp, improved = load(model)
    refinfo.append(dict(model=model, spectra=len(ref_old), ref_improved_by_VP=int(improved.sum()),
                        max_improvement_pct=100*float(((ref_old-best_vp)/ref_old).max()),
                        VP_worse_than_old_ref=int(((best_vp-ref_old)/ref_old > TOL).sum())))
    d['nfe_first_success'] = d.apply(first_success_nfe, axis=1)
    for a in OLD + NEW:
        x = d[d.algorithm == a]
        summary.append(dict(model=model, algorithm=a, success_rate=x.success.mean(),
                            median_rel_gap=x.rel_gap.median(), p90_rel_gap=x.rel_gap.quantile(.9), worst_rel_gap=x.rel_gap.max(),
                            spectra_all_runs_success=int(x.groupby('source_file').success.mean().eq(1).sum()),
                            **{f'success_at_{c}': x[f'succ_{c}'].mean() for c in CPS},
                            median_runtime_ms=1000*x.runtime_sec.median()))
        ax.plot(CPS, [100*d[d.algorithm == a][f'succ_{c}'].mean() for c in CPS],
                color=COL[a], ls='-' if a in NEW else '--', marker='o' if a in NEW else 's', ms=4, lw=1.6 if a in NEW else 1.0,
                alpha=1 if a in NEW else .7, label=a)
    ax.set_xscale('log'); ax.set_xlabel('NFE'); ax.set_title(model.replace('_', ' ')); ax.set_ylim(-3, 103); ax.grid(alpha=.3)
    if model == 'M11_RCPEL': ax.set_ylabel('runs within 0.1% of best-known (%)')
    med = d.groupby(['source_file', 'algorithm']).NRMSE.median().unstack()
    for a, b in [('VP-MS-TRF', 'MS-TRF'), ('VP-L-SHADE', 'L-SHADE'), ('VP-ASHO-LSHADE', 'ASHO-LSHADE'),
                 ('VP-ASHO-LSHADE', 'VP-L-SHADE'), ('VP-L-SHADE+TRF', 'L-SHADE+TRF'), ('VP-Screen+TRF', 'MS-TRF'),
                 ('VP-Screen+TRF', 'VP-MS-TRF')]:
        diff = med[a] - med[b]; rel = diff/med[b]
        try: p = wilcoxon(med[a], med[b]).pvalue if np.any(np.abs(rel) > 1e-12) else 1.0
        except ValueError: p = 1.0
        paired.append(dict(model=model, comparison=f'{a} vs {b}', better=int((rel < -TOL).sum()), worse=int((rel > TOL).sum()),
                           ties=int((rel.abs() <= TOL).sum()), median_rel_diff=float(rel.median()), p_raw=p))
    d.to_csv(TAB/f'vp_merged_{model}.csv', index=False)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc='lower center', ncol=6, fontsize=8, frameon=False, bbox_to_anchor=(.5, -0.08))
plt.tight_layout(); plt.savefig(FIG/'FigVP1_success_vs_NFE.png', dpi=300, bbox_inches='tight'); plt.close()

S = pd.DataFrame(summary); P = pd.DataFrame(paired); R = pd.DataFrame(refinfo)
# Holm within model
P['p_holm'] = np.nan
for m, g in P.groupby('model'):
    o = g.p_raw.sort_values(); k = len(o); adj = np.maximum.accumulate([min(1, (k-i)*p) for i, p in enumerate(o)])
    P.loc[o.index, 'p_holm'] = adj
S.to_csv(TAB/'Table_VP_performance.csv', index=False); P.to_csv(TAB/'Table_VP_paired.csv', index=False)
R.to_csv(TAB/'Table_VP_reference_check.csv', index=False)

# M12 per-spectrum success: hardest spectra
d12 = pd.read_csv(TAB/'vp_merged_M12_DoubleColeL.csv')
ps = d12.groupby(['source_file', 'algorithm']).success.mean().unstack()[['MS-TRF', 'L-SHADE+TRF', 'ASHO-LSHADE+TRF'] + NEW]
ps.index = [i.split('bipolar_')[-1].replace('.txt', '') + '_' + i[3:15] for i in ps.index]
ps.to_csv(TAB/'Table_VP_M12_success_by_spectrum.csv')
fig, ax = plt.subplots(figsize=(9, 6)); im = ax.imshow(100*ps.values, cmap='viridis', vmin=0, vmax=100, aspect='auto')
ax.set_xticks(range(ps.shape[1])); ax.set_xticklabels(ps.columns, rotation=45, ha='right', fontsize=8)
ax.set_yticks(range(ps.shape[0])); ax.set_yticklabels(ps.index, fontsize=7)
for i in range(ps.shape[0]):
    for j in range(ps.shape[1]): ax.text(j, i, f'{100*ps.values[i, j]:.0f}', ha='center', va='center', fontsize=6,
                                         color='w' if ps.values[i, j] < .6 else 'k')
plt.colorbar(im, label='success (%)'); ax.set_title('M12: per-spectrum success at 2,000 NFE')
plt.tight_layout(); plt.savefig(FIG/'FigVP2_M12_success_heatmap.png', dpi=300); plt.close()

pd.set_option('display.width', 250)
print(R.to_string()); print(S.round(4).to_string()); print(P.round(4).to_string())
