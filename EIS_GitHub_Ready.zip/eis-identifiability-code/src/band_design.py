"""band_design.py - how far below the current 10-100 kHz band must measurements extend for the
Cole relaxation time and resistive dispersion (M10) to become practically identifiable?

Synthetic Cole+L spectra with tissue-like parameters and f_c below 10 kHz (as in the measured
spectra) are generated on bands [f_min, 100 kHz] with 10 log-spaced points per decade and 1%
complex Gaussian noise. Each spectrum is fitted globally with VarPro and profiled with the
globally optimised VarPro profile likelihood (same 3.84 rule as the main analysis).
Usage: python3 band_design.py [n_spectra]
"""
import sys, time, pickle, numpy as np, pandas as pd
from pathlib import Path
from vp_core import VarPro, VP_SPECS
from run_vp_profiles import profile, min_nonlinear
from scipy.optimize import least_squares
from eis_core import MODELS

SEED0 = 20261101 + 990000
N = int(sys.argv[1]) if len(sys.argv) > 1 else 40
FMIN = [10e3, 3e3, 1e3, 300.0, 100.0]
NOISE = [0.01, 0.025]   # 2.5% ~ residual level of the KK-consistent measured spectra (M10 NRMSE 0.020-0.036)
TAB = Path(__file__).parent.parent/'results'/'tables'; CACHE = TAB.parent/'cache_band'; CACHE.mkdir(exist_ok=True)

def cole(x, w):
    Rinf, dR, tau, a, L = 10**x[0], 10**x[1], 10**x[2], x[3], 10**x[4]
    return Rinf + dR/(1 + (1j*w*tau)**a) + 1j*w*L

def truth(i):
    rng = np.random.default_rng(SEED0 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(np.log10(100), np.log10(3000)); tau = 1/(2*np.pi*fc)
    target = rng.uniform(2, 4)*Rinf; w10 = np.array([2*np.pi*1e4]); lo, hi = 0.0, 9.0
    for _ in range(60):   # dR such that |Z(10 kHz)| is 2-4 x Rinf, as in the measured spectra
        mid = (lo+hi)/2; zt = cole([np.log10(Rinf), mid, np.log10(tau), a, np.log10(L)], w10)
        lo, hi = (mid, hi) if abs(zt[0]) < target else (lo, mid)
    return np.array([np.log10(Rinf), (lo+hi)/2, np.log10(tau), a, np.log10(L)]), fc, rng

def vp_fit(w, z):
    """global VarPro fit of M10 (dense 2-D grid + TRF polish); returns eis_core log10 parameter vector."""
    vp = VarPro('M10_ColeL', w, z); lo, hi = vp.sp['lo'], vp.sp['hi']
    g = np.array([[a, b] for a in np.linspace(lo[0], hi[0], 33) for b in np.linspace(lo[1], hi[1], 15)])
    v = np.array([vp.f(p) for p in g]); best, bx = np.inf, None
    for k in np.argsort(v)[:3]:
        r = least_squares(vp.res, g[k], bounds=(lo, hi), xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400)
        if 2*r.cost < best: best, bx = 2*r.cost, r.x
    return vp.full_params(bx)

rows = []; t0 = time.time()
for i in range(N):
    p = CACHE/f'band_{i}.pkl'
    if p.exists(): rows += pickle.load(open(p, 'rb')); continue
    xt, fc, rng = truth(i); out = []
    noise_seed = rng.integers(1 << 30)
    for fmin, sig in [(a, b) for b in NOISE for a in FMIN]:
        f = np.logspace(np.log10(fmin), 5, int(round(10*np.log10(1e5/fmin))) + 1); w = 2*np.pi*f
        z0 = cole(xt, w); nr = np.random.default_rng(noise_seed)
        z = z0 + sig*np.abs(z0)*(nr.standard_normal(len(w)) + 1j*nr.standard_normal(len(w)))/np.sqrt(2)
        xh = vp_fit(w, z); s = dict(w=w, z=z)
        rec = dict(spectrum=i, noise=sig, fc_true_hz=fc, fmin_hz=fmin, n_freq=len(w), ratio_fmin_fc=fmin/fc)
        for pn in ['logdR', 'logtau']:
            o, _, _ = profile('M10_ColeL', s, xh, pn); j = MODELS['M10_ColeL'][0].index(pn)
            rec.update({f'{pn}_ident': o['identifiable'], f'{pn}_ciw': o['ci_width'], f'{pn}_abserr': abs(xh[j]-xt[j])})
        out.append(rec)
    pickle.dump(out, open(p, 'wb')); rows += out
    print(time.strftime('%H:%M:%S'), i, f'fc={fc:.0f}', f'{time.time()-t0:.0f}s', flush=True)

D = pd.DataFrame(rows); D.to_csv(TAB/'band_design_runs.csv', index=False)
S = D.groupby(['noise', 'fmin_hz']).agg(n=('spectrum', 'size'), n_freq=('n_freq', 'first'),
        tau_identifiable_pct=('logtau_ident', lambda x: 100*x.mean()), dR_identifiable_pct=('logdR_ident', lambda x: 100*x.mean()),
        median_tau_ciw=('logtau_ciw', 'median'), median_dR_ciw=('logdR_ciw', 'median'),
        median_tau_abserr=('logtau_abserr', 'median'), median_dR_abserr=('logdR_abserr', 'median')).reset_index().sort_values(['noise', 'fmin_hz'], ascending=[True, False])
S.to_csv(TAB/'Table_band_design.csv', index=False); print(S.round(3).to_string())
D['ratio_bin'] = pd.cut(D.ratio_fmin_fc, [0, 0.3, 1, 3, 10, 1000], labels=['<0.3', '0.3-1', '1-3', '3-10', '>10'])
R = D.groupby(['noise', 'ratio_bin'], observed=True).agg(n=('spectrum', 'size'), tau_identifiable_pct=('logtau_ident', lambda x: 100*x.mean()),
        dR_identifiable_pct=('logdR_ident', lambda x: 100*x.mean()), median_tau_ciw=('logtau_ciw', 'median')).reset_index()
R.to_csv(TAB/'Table_band_design_ratio.csv', index=False); print(R.round(3).to_string())
