"""Development set (synthetic M12 spectra only) used to choose ASHO-LR settings; real data untouched."""
import numpy as np, math, sys
sys.path.insert(0,'.'); from eis_core import *
w=2*np.pi*1000*np.arange(10,101,10.)
specs=[]
for i in range(8):
    r=np.random.default_rng(900+i)
    x=np.array([r.uniform(2.7,3.7),r.uniform(3,5),np.log10(1/(2*np.pi*10**r.uniform(4.2,4.9))),r.uniform(3,5),np.log10(1/(2*np.pi*10**r.uniform(2,3.5))),r.uniform(.6,.95),r.uniform(.6,.95),r.uniform(-3.4,-2.6)])
    z0=predict('M12_DoubleColeL',x,w); z=z0+0.01*abs(z0)*(r.standard_normal(10)+1j*r.standard_normal(10))/np.sqrt(2); specs.append(z)
import eis_core
for name,kw in [('MS-TRF',None),('LR c80',dict(cap_per_dim=80)),('LR full w0',dict(cap_per_dim=10**6,cap_max_per_dim=10**6,adapt_cap=False,warmup_gens=0)),('LR c200 w0',dict(cap_per_dim=200,cap_max_per_dim=400,warmup_gens=0))]:
    res=[]
    for z in specs:
        vals=[]
        for s in range(8):
            if kw is None: vals.append(run_algorithm('MS-TRF','M12_DoubleColeL',w,z,2000,s)[1])
            else: vals.append(asho_lr('M12_DoubleColeL',w,z,*MODELS['M12_DoubleColeL'][1:],2000,s,**kw)[1])
        res.append(vals)
    res=np.sqrt(np.array(res)); best=res.min(1,keepdims=True)
    print(name, 'median NRMSE',np.median(res).round(5))
    globals().setdefault('ALL',{})[name]=res
best=np.min([v.min(1) for v in ALL.values()],0)[:,None]
for k,v in ALL.items(): print(k,'success vs pooled best', ((v-best)/best<=1e-3).mean().round(3))
