"""
eis_core.py - Core library for the revised ASHO-LSHADE tissue-EIS study.

Pure Python/NumPy (no numba required). Algorithms are line-by-line ports of the
frozen numba implementation in the original notebook, generalised to any
dimension so that they can be applied to both the 5-parameter Cole+L model
(M10) and the identifiable 4-parameter R-CPE-L model (M11).

Hyperparameters (identical for every model and every spectrum):
  L-SHADE : N_init=20, N_min=4, H=6, p=0.11, |A|=NP, M_F=M_CR=0.5 initially,
            current-to-pbest/1/bin, linear population-size reduction.
  Trigger : stagnation >= max(4, round(12-7*progress)) generations AND
            normalised diversity < 0.20+0.20*progress; only the poorer half
            of the population is eligible.
  SAHO    : fixed rescue probability 0.25.
  ASHO    : p_HO(0)=0.25, p_min=0.05, p_max=0.45, lambda=0.25.
  Restart : same trigger, uniform re-sampling with probability 0.25.
"""
import math, random, time
import numpy as np
from scipy.optimize import least_squares

POP0, POPMIN, H, PBEST = 20, 4, 6, 0.11

# ------------------------------------------------------------------ models
MODELS = {
    # name: (parameter names, lower bounds, upper bounds)
    'M10_ColeL': (['logRinf', 'logdR', 'logtau', 'alpha', 'logL'],
                  np.array([-3., -3., -7., 0.30, -9.]), np.array([7., 8., 1., 1.0, 0.])),
    'M11_RCPEL': (['logRinf', 'logQ', 'alpha', 'logL'],
                  np.array([-3., -12., 0.30, -9.]), np.array([7., 0., 1.0, 0.])),
    # higher-dimensional stress test: double Cole + series inductance (8 parameters)
    'M12_DoubleColeL': (['logRinf', 'logdR1', 'logtau1', 'logdR2', 'logtau2', 'alpha1', 'alpha2', 'logL'],
                  np.array([-3., -3., -7., -3., -7., 0.30, 0.30, -9.]), np.array([7., 8., 1., 8., 1., 1.0, 1.0, 0.])),
}

def predict(model, x, w):
    x = np.asarray(x, float)
    if model == 'M10_ColeL':
        Rinf, dR, tau, L = 10**x[0], 10**x[1], 10**x[2], 10**x[4]; a = x[3]
        return Rinf + dR/(1 + (1j*w*tau)**a) + 1j*w*L
    if model == 'M11_RCPEL':
        Rinf, Q, L = 10**x[0], 10**x[1], 10**x[3]; a = x[2]
        return Rinf + 1/(Q*(1j*w)**a) + 1j*w*L
    if model == 'M12_DoubleColeL':
        Rinf, d1, t1, d2, t2, L = 10**x[0], 10**x[1], 10**x[2], 10**x[3], 10**x[4], 10**x[7]
        return Rinf + d1/(1 + (1j*w*t1)**x[5]) + d2/(1 + (1j*w*t2)**x[6]) + 1j*w*L
    raise KeyError(model)

def residual(model, x, w, z):
    e = (predict(model, x, w) - z)/np.maximum(np.abs(z), 1.0)
    return np.r_[e.real, e.imag]

def make_objective(model, w, z):
    """J(theta) = (1/N) sum_k |Zhat_k - Z_k|^2/|Z_k|^2 ; NRMSE = sqrt(J)."""
    sc = np.maximum(np.abs(z), 1.0); N = len(w)
    if model == 'M10_ColeL':
        jw = 1j*w
        def f(x):
            zh = 10**x[0] + 10**x[1]/(1 + (jw*10**x[2])**x[3]) + jw*10**x[4]
            e = np.abs(zh - z)/sc
            return float(np.dot(e, e)/N)
    elif model == 'M11_RCPEL':
        jw = 1j*w
        def f(x):
            zh = 10**x[0] + 1/(10**x[1]*jw**x[2]) + jw*10**x[3]
            e = np.abs(zh - z)/sc
            return float(np.dot(e, e)/N)
    else:
        def f(x):
            e = np.abs(predict(model, x, w) - z)/sc
            return float(np.dot(e, e)/N)
    return f

# ------------------------------------------------------------ utilities
class Tracker:
    """Counts NFE and records best-so-far objective at checkpoints."""
    def __init__(self, f, budget, checkpoints):
        self.f, self.budget, self.nfe = f, budget, 0
        self.best = math.inf; self.xbest = None
        self.cps = sorted(c for c in checkpoints if c <= budget); self.ci = 0
        self.trace = {}
    def __call__(self, x):
        v = self.f(x); self.nfe += 1
        if v < self.best: self.best = v; self.xbest = list(x)
        while self.ci < len(self.cps) and self.nfe >= self.cps[self.ci]:
            self.trace[self.cps[self.ci]] = self.best; self.ci += 1
        return v

def _clip(u, lo, hi):
    for d in range(len(u)):
        if u[d] < lo[d]: u[d] = lo[d]
        elif u[d] > hi[d]: u[d] = hi[d]
    return u

def _levy(rnd, beta=1.5):
    sigma = (math.gamma(1+beta)*math.sin(math.pi*beta/2) /
             (math.gamma((1+beta)/2)*beta*2**((beta-1)/2)))**(1/beta)
    return rnd.gauss(0, 1)*sigma/(abs(rnd.gauss(0, 1))**(1/beta) + 1e-12)

def _ho_rescue(rnd, x, best, progress, lo, hi):
    D = len(x); u = list(x)
    if rnd.random() < 0.5:   # HO river/pond position update (dominant-hippo guidance)
        I1 = 1 + rnd.randint(0, 1); y = rnd.random()
        for d in range(D): u[d] = x[d] + y*(best[d] - I1*x[d])
    else:                    # HO defence/escape-inspired heavy-tailed move
        lev = _levy(rnd); shrink = max(0.03, 0.35*(1.0 - progress))
        for d in range(D):
            u[d] = x[d] + rnd.random()*lev*shrink*(hi[d]-lo[d]) + 0.25*rnd.random()*(best[d]-x[d])
    return _clip(u, lo, hi)

def _init(rnd, lo, hi, n):
    D = len(lo)
    return [[lo[d] + (hi[d]-lo[d])*rnd.random() for d in range(D)] for _ in range(n)]

# ------------------------------------------------------- L-SHADE family
def lshade_family(f, lo, hi, budget, seed, mode, checkpoints=()):
    """mode: 'lshade' | 'restart' | 'saho' | 'asho'"""
    rnd = random.Random(seed); D = len(lo); lo = list(lo); hi = list(hi)
    T = Tracker(f, budget, checkpoints)
    NP = POP0; X = _init(rnd, lo, hi, NP); fx = [T(x) for x in X]
    MF = [0.5]*H; MCR = [0.5]*H; mem = 0; archive = []
    best_prev = min(fx); stagn = 0; maxdiv = 1e-12
    rt = rs = 0; p_ho = 0.25; pmin, pmax, lam = 0.05, 0.45, 0.25; asum = 0.0; an = 0
    while T.nfe < budget and NP >= POPMIN:
        cen = [sum(X[i][d] for i in range(NP))/NP for d in range(D)]
        div = sum(math.sqrt(sum((X[i][d]-cen[d])**2 for d in range(D))) for i in range(NP))/NP
        maxdiv = max(maxdiv, div); dnorm = div/maxdiv; progress = T.nfe/budget
        stag_thr = max(4, int(round(12 - 7*progress)))
        active = mode != 'lshade' and stagn >= stag_thr and dnorm < (0.20 + 0.20*progress)
        prob = 0.25 if mode in ('saho', 'restart') else p_ho
        order = sorted(range(NP), key=fx.__getitem__); pnum = max(2, int(math.ceil(PBEST*NP)))
        Xold = [list(x) for x in X]; fold = list(fx); ib = order[0]
        sF = []; sCR = []; simp = []; arch_add = []; grt = grs = 0
        for i in range(NP):
            if T.nfe >= budget: break
            k = rnd.randrange(H)
            Fi = MF[k] + 0.1*math.tan(math.pi*(rnd.random()-0.5))
            while Fi <= 0: Fi = MF[k] + 0.1*math.tan(math.pi*(rnd.random()-0.5))
            Fi = min(1.0, Fi); CRi = min(1.0, max(0.0, rnd.gauss(MCR[k], 0.1)))
            special = active and i >= max(1, NP//2) and rnd.random() < prob
            if special and mode in ('saho', 'asho'):
                rt += 1; grt += 1; u = _ho_rescue(rnd, Xold[i], Xold[ib], progress, lo, hi)
            elif special and mode == 'restart':
                rt += 1; u = [lo[d] + (hi[d]-lo[d])*rnd.random() for d in range(D)]
            else:
                special = False
                pb = order[rnd.randrange(pnum)]
                while True:
                    r1 = rnd.randrange(NP)
                    if r1 != i and r1 != pb: break
                tot = NP + len(archive)
                while True:
                    r2 = rnd.randrange(tot)
                    if r2 >= NP or (r2 != i and r2 != pb and r2 != r1): break
                xr2 = Xold[r2] if r2 < NP else archive[r2-NP]
                xi = Xold[i]; xp = Xold[pb]; x1 = Xold[r1]
                v = _clip([xi[d] + Fi*(xp[d]-xi[d]) + Fi*(x1[d]-xr2[d]) for d in range(D)], lo, hi)
                jr = rnd.randrange(D)
                u = [v[d] if (rnd.random() < CRi or d == jr) else xi[d] for d in range(D)]
            fu = T(u)
            if fu < fold[i]:
                X[i] = u; fx[i] = fu
                if special:
                    rs += 1; grs += 1
                else:
                    sF.append(Fi); sCR.append(CRi); simp.append(fold[i]-fu); arch_add.append(Xold[i])
        if mode == 'asho' and grt > 0:
            p_ho = (1-lam)*p_ho + lam*(pmin + (pmax-pmin)*grs/grt)
            p_ho = min(pmax, max(pmin, p_ho)); asum += p_ho; an += 1
        if arch_add:
            archive.extend(arch_add)
            if len(archive) > NP: archive = rnd.sample(archive, NP)
        if sF:
            tot = sum(simp); wts = [s/tot for s in simp]
            den = sum(wt*F for wt, F in zip(wts, sF))
            if den > 0: MF[mem] = sum(wt*F*F for wt, F in zip(wts, sF))/den
            MCR[mem] = sum(wt*c for wt, c in zip(wts, sCR)); mem = (mem+1) % H
        cur = min(fx)
        if cur < best_prev - 1e-14: best_prev = cur; stagn = 0
        else: stagn += 1
        if T.nfe < budget:
            tgt = int(round(POPMIN + (POP0-POPMIN)*(budget-T.nfe)/budget)); tgt = max(POPMIN, min(NP, tgt))
            if tgt < NP:
                ids = sorted(range(NP), key=fx.__getitem__)[:tgt]
                X = [X[j] for j in ids]; fx = [fx[j] for j in ids]; NP = tgt
                if len(archive) > NP: archive = rnd.sample(archive, NP)
    order = sorted(range(NP), key=fx.__getitem__)
    extra = {'final_pop': [X[j] for j in order], 'rescue_trials': rt, 'rescue_success': rs,
             'mean_pHO': (asum/an if an else p_ho) if mode == 'asho' else np.nan,
             'final_pHO': p_ho if mode == 'asho' else np.nan}
    return np.array(T.xbest), T.best, T.trace, extra

# ------------------------------------------------------------------- HO
def ho(f, lo, hi, budget, seed, checkpoints=()):
    """Compact NFE-fair HO (Amiri et al., 2024): position update, defence, escape."""
    rnd = random.Random(seed); D = len(lo); lo = list(lo); hi = list(hi)
    T = Tracker(f, budget, checkpoints)
    N = POP0; X = _init(rnd, lo, hi, N); fx = [T(x) for x in X]; it = 1
    maxit = max(1, (budget-N)//N)
    while T.nfe < budget:
        best = list(X[min(range(N), key=fx.__getitem__)]); half = max(1, N//2); Tt = math.exp(-it/maxit)
        for i in range(half):
            if T.nfe >= budget: break
            I1 = 1 + rnd.randint(0, 1); y = rnd.random()
            u = _clip([X[i][d] + y*(best[d]-I1*X[i][d]) for d in range(D)], lo, hi)
            fu = T(u)
            if fu < fx[i]: X[i] = u; fx[i] = fu
        for i in range(half, N):
            if T.nfe >= budget: break
            pred = [lo[d] + (hi[d]-lo[d])*rnd.random() for d in range(D)]; fp = T(pred)
            if T.nfe >= budget: break
            lev = _levy(rnd); u = list(X[i])
            for d in range(D):
                dist = abs(pred[d]-X[i][d]) + 1e-9; step = 0.05*lev*(hi[d]-lo[d])/dist
                u[d] = pred[d] + step if fp < fx[i] else X[i][d] + rnd.random()*(best[d]-X[i][d]) + step*rnd.random()
            u = _clip(u, lo, hi); fu = T(u)
            if fu < fx[i]: X[i] = u; fx[i] = fu
        for _ in range(max(1, N//4)):
            if T.nfe >= budget: break
            i = rnd.randrange(N); shrink = max(0.02, 0.25*Tt)
            u = _clip([X[i][d] + (2*rnd.random()-1)*shrink*(hi[d]-lo[d]) + 0.2*rnd.random()*(best[d]-X[i][d])
                       for d in range(D)], lo, hi)
            fu = T(u)
            if fu < fx[i]: X[i] = u; fx[i] = fu
        it += 1
    return np.array(T.xbest), T.best, T.trace, {'rescue_trials': 0, 'rescue_success': 0, 'mean_pHO': np.nan, 'final_pHO': np.nan}

# ----------------------------------------- multistart trust-region baseline
class _Budget(Exception): pass

def ms_trf(model, w, z, lo, hi, budget, seed, checkpoints=()):
    """Multistart bounded nonlinear least squares (trust-region reflective,
    2-point Jacobian). Every residual evaluation, including those used for the
    finite-difference Jacobian, is counted against the same NFE budget."""
    rng = np.random.default_rng(seed); f = make_objective(model, w, z)
    T = Tracker(f, budget, checkpoints)
    def res(x):
        if T.nfe >= budget: raise _Budget
        T(x); return residual(model, x, w, z)
    while T.nfe < budget:
        try:
            least_squares(res, rng.uniform(lo, hi), bounds=(lo, hi), jac='2-point', max_nfev=10000)
        except _Budget:
            break
    return np.array(T.xbest), T.best, T.trace, {'rescue_trials': 0, 'rescue_success': 0, 'mean_pHO': np.nan, 'final_pHO': np.nan}

def hybrid_trf(model, w, z, lo, hi, budget, seed, mode, checkpoints=(), frac_global=0.5):
    """Memetic variant: L-SHADE-family global stage for frac_global*budget NFE,
    then bounded TRF refinement started from the best and the remaining final
    population members (then uniform random points) until the SAME total NFE
    budget is exhausted."""
    f = make_objective(model, w, z); b1 = int(frac_global*budget)
    x1, f1, tr1, ex = lshade_family(f, lo, hi, b1, seed, mode, checkpoints)
    T = Tracker(f, budget, checkpoints); T.nfe = b1; T.best = f1; T.xbest = list(x1)
    while T.ci < len(T.cps) and T.cps[T.ci] <= b1: T.ci += 1
    rng = np.random.default_rng(seed)
    starts = [np.asarray(p, float) for p in ex.pop('final_pop')]
    def res(x):
        if T.nfe >= budget: raise _Budget
        T(x); return residual(model, x, w, z)
    k = 0
    while T.nfe < budget:
        x0 = starts[k] if k < len(starts) else rng.uniform(lo, hi); k += 1
        try:
            least_squares(res, np.clip(x0, lo, hi), bounds=(lo, hi), jac='2-point', max_nfev=10000)
        except _Budget:
            break
    trace = dict(tr1); trace.update(T.trace)
    return np.array(T.xbest), T.best, trace, ex

ALGORITHMS = ['HO', 'MS-TRF', 'L-SHADE', 'L-SHADE-Restart', 'SAHO-LSHADE', 'ASHO-LSHADE', 'L-SHADE+TRF', 'ASHO-LSHADE+TRF']

def run_algorithm(name, model, w, z, budget, seed, checkpoints=()):
    _, lo, hi = MODELS[model]; f = make_objective(model, w, z)
    t0 = time.perf_counter()
    if name == 'HO': out = ho(f, lo, hi, budget, seed, checkpoints)
    elif name == 'MS-TRF': out = ms_trf(model, w, z, lo, hi, budget, seed, checkpoints)
    elif name.endswith('+TRF'):
        out = hybrid_trf(model, w, z, lo, hi, budget, seed, 'asho' if name.startswith('ASHO') else 'lshade', checkpoints)
    else:
        mode = {'L-SHADE': 'lshade', 'L-SHADE-Restart': 'restart', 'SAHO-LSHADE': 'saho', 'ASHO-LSHADE': 'asho'}[name]
        out = lshade_family(f, lo, hi, budget, seed, mode, checkpoints)
    out[3].pop('final_pop', None)
    return (*out, time.perf_counter()-t0)

# --------------------------------------------------------- identifiability
def jacobian_svd(model, x, w, z):
    _, lo, hi = MODELS[model]; x = np.asarray(x, float); r0 = residual(model, x, w, z)
    J = np.empty((len(r0), len(x)))
    for d in range(len(x)):
        h = 1e-5*max(1, abs(x[d])); xp = x.copy(); xm = x.copy()
        xp[d] = min(hi[d], xp[d]+h); xm[d] = max(lo[d], xm[d]-h)
        J[:, d] = (residual(model, xp, w, z) - residual(model, xm, w, z))/max(xp[d]-xm[d], 1e-15)
    s = np.linalg.svd(J, compute_uv=False)
    return s[0]/max(s[-1], 1e-300), s[-1]

def best_fit(model, w, z, x0s, rng, extra_starts=20):
    _, lo, hi = MODELS[model]; best = None
    starts = [np.clip(np.asarray(x, float), lo, hi) for x in x0s] + [rng.uniform(lo, hi) for _ in range(extra_starts)]
    for x0 in starts:
        r = least_squares(lambda x: residual(model, x, w, z), x0, bounds=(lo, hi), max_nfev=5000,
                          xtol=1e-12, ftol=1e-12, gtol=1e-12)
        if best is None or r.cost < best.cost: best = r
    return best.x, 2*best.cost

def profile_likelihood(model, w, z, xhat, pidx, ngrid=41, rng=None):
    """Profile of parameter pidx (others re-optimised). Gaussian likelihood with
    unknown variance: LR(theta) = n*log(RSS(theta)/RSS_min); 95% CI where LR<=3.84."""
    names, lo, hi = MODELS[model]; n = 2*len(w)
    free = [d for d in range(len(lo)) if d != pidx]
    rss_min = float(np.sum(residual(model, xhat, w, z)**2))
    span = 0.05*(hi[pidx]-lo[pidx])
    grid = np.unique(np.clip(np.r_[np.linspace(lo[pidx], hi[pidx], ngrid),
                                   xhat[pidx] + np.linspace(-span, span, 21), xhat[pidx]], lo[pidx], hi[pidx]))
    prof = []
    for g in grid:
        best = None
        starts = [xhat[free]] + [rng.uniform(lo[free], hi[free]) for _ in range(3)]
        for x0 in starts:
            def rf(xf, g=g):
                x = np.array(xhat, float); x[free] = xf; x[pidx] = g; return residual(model, x, w, z)
            r = least_squares(rf, np.clip(x0, lo[free], hi[free]), bounds=(lo[free], hi[free]), max_nfev=3000)
            if best is None or r.cost < best: best = r.cost
        prof.append(2*best)
    prof = np.minimum(np.array(prof), np.inf); rss_min = min(rss_min, prof.min())
    lr = n*np.log(prof/rss_min); inside = grid[lr <= 3.84]
    i0 = int(np.argmin(lr)); thr = 3.84
    def cross(j_in, j_out):   # linear interpolation of the LR=3.84 crossing
        a, b = lr[j_in], lr[j_out]
        return grid[j_in] + (thr-a)*(grid[j_out]-grid[j_in])/(b-a) if b != a else grid[j_in]
    j = i0
    while j > 0 and lr[j-1] <= thr: j -= 1
    lo_ci = cross(j, j-1) if j > 0 else grid[0]
    j = i0
    while j < len(grid)-1 and lr[j+1] <= thr: j += 1
    hi_ci = cross(j, j+1) if j < len(grid)-1 else grid[-1]
    # identifiable (practically) if the 95% profile CI closes before both search bounds
    bounded = (lr[0] > 3.84) and (lr[-1] > 3.84)
    return grid, lr, lo_ci, hi_ci, bounded

# ------------------------------------------------------------------------------
# ASHO-LR: Adaptive Stagnation-triggered, HO-seeded Local Refinement (revision 3)
# ------------------------------------------------------------------------------
class _LocalCap(Exception): pass

def asho_lr(model, w, z, lo, hi, budget, seed, checkpoints=(), cap_per_dim=40, warmup_gens=2, cap_max_per_dim=160, adapt_cap=True):
    """L-SHADE backbone. When the best objective stagnates (same progress-dependent
    threshold as ASHO, no diversity condition), a bounded TRF refinement is launched.
    The first refinement starts from the population best; subsequent ones start from
    an HO-rescue move applied to a poorer-half individual, so HO proposes a new basin
    and TRF polishes it. Each refinement is capped at cap_per_dim*D evaluations
    (doubled after a refinement improves the global best, halved otherwise, within
    [10D, 160D]). The refined point replaces the worst individual if it is better.
    All evaluations (population, HO, TRF incl. Jacobians) share one NFE budget."""
    rnd = random.Random(seed); D = len(lo); lo_l = list(lo); hi_l = list(hi)
    f = make_objective(model, w, z); T = Tracker(f, budget, checkpoints)
    NP = POP0; X = _init(rnd, lo_l, hi_l, NP); fx = [T(x) for x in X]
    MF = [0.5]*H; MCR = [0.5]*H; mem = 0; archive = []
    best_prev = min(fx); stagn = 0; gen = 0; nref = 0; cap = cap_per_dim*D
    ref_trials = ref_success = 0; cap_max = cap_max_per_dim*D
    def refine(x0, cap_):
        start = T.nfe; best_seen = [math.inf, None]
        def res(x):
            if T.nfe >= budget: raise _Budget
            if T.nfe - start >= cap_: raise _LocalCap
            v = T(x)
            if v < best_seen[0]: best_seen[0] = v; best_seen[1] = list(x)
            return residual(model, x, w, z)
        try:
            least_squares(res, np.clip(np.asarray(x0, float), lo, hi), bounds=(lo, hi), jac='2-point', max_nfev=100000)
        except (_Budget, _LocalCap):
            pass
        return best_seen
    while T.nfe < budget and NP >= POPMIN:
        progress = T.nfe/budget; stag_thr = max(4, int(round(12 - 7*progress)))
        if gen >= warmup_gens and stagn >= stag_thr:
            ib = min(range(NP), key=fx.__getitem__)
            if nref == 0: x0 = X[ib]
            else:
                i = rnd.randrange(max(1, NP//2), NP) if NP > 1 else 0
                order = sorted(range(NP), key=fx.__getitem__)
                x0 = _ho_rescue(rnd, X[order[i]], X[ib], progress, lo_l, hi_l)
            gb = T.best; v, xr = refine(x0, cap); nref += 1; ref_trials += 1
            if xr is not None:
                iw = max(range(NP), key=fx.__getitem__)
                if v < fx[iw]: X[iw] = xr; fx[iw] = v
            if T.best < gb*(1 - 1e-9): ref_success += 1; cap = min(cap_max, cap*2)
            else: cap = max(10*D, cap//2) if adapt_cap else cap
            stagn = 0; best_prev = min(fx)
            if T.nfe >= budget: break
        order = sorted(range(NP), key=fx.__getitem__); pnum = max(2, int(math.ceil(PBEST*NP)))
        Xold = [list(x) for x in X]; fold = list(fx)
        sF = []; sCR = []; simp = []; arch_add = []
        for i in range(NP):
            if T.nfe >= budget: break
            k = rnd.randrange(H)
            Fi = MF[k] + 0.1*math.tan(math.pi*(rnd.random()-0.5))
            while Fi <= 0: Fi = MF[k] + 0.1*math.tan(math.pi*(rnd.random()-0.5))
            Fi = min(1.0, Fi); CRi = min(1.0, max(0.0, rnd.gauss(MCR[k], 0.1)))
            pb = order[rnd.randrange(pnum)]
            while True:
                r1 = rnd.randrange(NP)
                if r1 != i and r1 != pb: break
            tot = NP + len(archive)
            while True:
                r2 = rnd.randrange(tot)
                if r2 >= NP or (r2 != i and r2 != pb and r2 != r1): break
            xr2 = Xold[r2] if r2 < NP else archive[r2-NP]; xi = Xold[i]
            v = _clip([xi[d] + Fi*(Xold[pb][d]-xi[d]) + Fi*(Xold[r1][d]-xr2[d]) for d in range(D)], lo_l, hi_l)
            jr = rnd.randrange(D); u = [v[d] if (rnd.random() < CRi or d == jr) else xi[d] for d in range(D)]
            fu = T(u)
            if fu < fold[i]:
                X[i] = u; fx[i] = fu; sF.append(Fi); sCR.append(CRi); simp.append(fold[i]-fu); arch_add.append(Xold[i])
        if arch_add:
            archive.extend(arch_add)
            if len(archive) > NP: archive = rnd.sample(archive, NP)
        if sF:
            tot = sum(simp); wts = [s/tot for s in simp]; den = sum(a*b for a, b in zip(wts, sF))
            if den > 0: MF[mem] = sum(a*b*b for a, b in zip(wts, sF))/den
            MCR[mem] = sum(a*b for a, b in zip(wts, sCR)); mem = (mem+1) % H
        cur = min(fx)
        if cur < best_prev - 1e-14: best_prev = cur; stagn = 0
        else: stagn += 1
        gen += 1
        if T.nfe < budget:
            tgt = int(round(POPMIN + (POP0-POPMIN)*(budget-T.nfe)/budget)); tgt = max(POPMIN, min(NP, tgt))
            if tgt < NP:
                ids = sorted(range(NP), key=fx.__getitem__)[:tgt]; X = [X[j] for j in ids]; fx = [fx[j] for j in ids]; NP = tgt
                if len(archive) > NP: archive = rnd.sample(archive, NP)
    return np.array(T.xbest), T.best, T.trace, {'rescue_trials': ref_trials, 'rescue_success': ref_success, 'mean_pHO': np.nan, 'final_pHO': np.nan}

_old_run_algorithm = run_algorithm
def run_algorithm(name, model, w, z, budget, seed, checkpoints=()):
    if name == 'ASHO-LR':
        _, lo, hi = MODELS[model]; t0 = time.perf_counter()
        out = asho_lr(model, w, z, lo, hi, budget, seed, checkpoints)
        return (*out, time.perf_counter()-t0)
    return _old_run_algorithm(name, model, w, z, budget, seed, checkpoints)
