"""feature_stability.py - consequence of non-identifiability for diagnostic features.
Uses the 40 reading-level resamples per spectrum (repeatability_bootstrap_fits.csv). For each fitted
parameter, spectra are ranked separately in every resample; stability is summarized by
(i) the median Spearman correlation between rankings from different resamples, and
(ii) the share of spectrum pairs whose ordering is the same in at least 95% of resamples."""
import itertools, numpy as np, pandas as pd
from scipy.stats import spearmanr
from pathlib import Path
T = Path(__file__).parent.parent/'results'/'tables'
d = pd.read_csv(T/'repeatability_bootstrap_fits.csv'); kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct
FEATS = [('M10_ColeL', 'logtau', 'M10 log10 tau'), ('M10_ColeL', 'logdR', 'M10 log10 dR'), ('M10_ColeL', 'alpha', 'M10 alpha'),
         ('M10_ColeL', 'logRinf', 'M10 log10 Rinf'), ('M11_RCPEL', 'logQ', 'M11 log10 Q'), ('M11_RCPEL', 'alpha', 'M11 alpha'),
         ('M11_RCPEL', 'logRinf', 'M11 log10 Rinf')]
rows = []
for subset, keep in [('KK-consistent (12)', lambda s: kk[s] < 3), ('All spectra (20)', lambda s: True)]:
    for m, p, lab in FEATS:
        x = d[(d.model == m) & d.source_file.map(keep)].pivot_table(index='b', columns='source_file', values=p)
        X = x.to_numpy()                                   # resamples x spectra
        rho = [spearmanr(X[i], X[j]).statistic for i, j in itertools.combinations(range(len(X)), 2)]
        n = X.shape[1]; stable = 0
        for i, j in itertools.combinations(range(n), 2):
            agree = np.mean(X[:, i] > X[:, j]); stable += max(agree, 1-agree) >= 0.95
        npairs = n*(n-1)//2
        rows.append(dict(subset=subset, feature=lab, median_rank_rho=np.median(rho), q05_rank_rho=np.quantile(rho, .05),
                         stable_pairs_pct=100*stable/npairs, n_pairs=npairs))
R = pd.DataFrame(rows); R.to_csv(T/'Table_feature_stability.csv', index=False)
pd.set_option('display.width', 200); print(R.round(3).to_string())
