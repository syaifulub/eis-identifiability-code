import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle
plt.rcParams.update({'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold'})
W,H=100,142
fig=plt.figure(figsize=(11,15.6)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(0,H); ax.axis('off')
HL='#e8f1fb'; HE='#1f5f9e'
def box(x,y,w,h,title=None,lines=(),fs=10,tfs=11,fc='white',ec='black',lw=1.1,center=False,rounded=0.6):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={rounded}',fc=fc,ec=ec,lw=lw))
    if center:
        t=title if title else ''
        if lines: t=(r'$\bf{'+title.replace(' ',r'\ ')+'}$\n' if title else '')+'\n'.join(lines)
        ax.text(x+w/2,y+h/2,t if lines else r'$\bf{'+title.replace(' ',r'\ ')+'}$',ha='center',va='center',fontsize=fs,linespacing=1.35)
        return
    yy=y+h-1.3
    if title:
        ax.text(x+1.2,yy,title,ha='left',va='top',fontsize=tfs,fontweight='bold'); yy-=2.6
    for l in lines:
        ax.text(x+2.0,yy,'\u2022  '+l,ha='left',va='top',fontsize=fs); yy-=2.25
def para(xc,y,w,h,title,sub):
    s=2.2
    ax.add_patch(Polygon([(xc-w/2+s,y+h),(xc+w/2+s,y+h),(xc+w/2-s,y),(xc-w/2-s,y)],closed=True,fc='white',ec='black',lw=1.1))
    ax.text(xc,y+h*0.64,title,ha='center',va='center',fontsize=11,fontweight='bold')
    ax.text(xc,y+h*0.27,sub,ha='center',va='center',fontsize=9.5)
def arrow(x,y1,y2):
    ax.annotate('',xy=(x,y2),xytext=(x,y1),arrowprops=dict(arrowstyle='-|>',lw=1.1,color='black',mutation_scale=12))
def group(y,h,title,ec='black',fc='none'):
    ax.add_patch(Rectangle((2,y),96,h,fill=fc!='none',fc=fc,ec=ec,lw=1.0,ls=(0,(5,3))))
    ax.text(3,y+h-1.2,title,ha='left',va='top',fontsize=12,fontweight='bold',color=ec if ec!='black' else 'black')
cx=50
# start
box(42,138,16,3,'Start',center=True,rounded=1.4); arrow(cx,138,135.8)
para(cx,131,40,4.8,'Raw EIS spectra','In vivo porcine dataset: 12 tissues, 10\u2013100 kHz')
arrow(cx,131,129)
box(28,118.4,44,10.6,'Data preprocessing and quality control',['Median of readings; 51 complete repeated sweeps','Retain complete 10-frequency spectra (n = 20)','Linear Kramers\u2013Kronig check (3% threshold)'],fs=9.5)
arrow(cx,118.4,116.4)
box(28,105.8,44,10.6,'Equivalent-circuit model selection',['Fit 11 candidate ECMs; weighted AICc and BIC','Reduced R\u2013CPE\u2013L (M11) preferred','M10 (Cole + L) and M12 (double Cole + L) kept'],fs=9.5)
arrow(cx,105.8,103.4)
# optimization group
gy=67.2; gh=36.0
group(gy,gh,'Parameter optimization  (M10, M11, M12; 20 spectra \u00d7 25 runs \u00d7 2,000 NFE)')
ax.text(4,gy+gh-5.0,'(a) Original parameterization: all 4\u20138 parameters searched',fontsize=10.5,fontstyle='italic',va='top')
algs=['HO','L-SHADE','L-SHADE-\nRestart','SAHO-\nLSHADE','ASHO-\nLSHADE','MS-TRF','L-SHADE\n+TRF','ASHO-LSHADE\n+TRF']
bw=10.9; gap=(92-8*bw)/7
for i,a in enumerate(algs):
    box(4+i*(bw+gap),gy+gh-13.6,bw,6.4,a,center=True,fs=8.8) if False else None
    x=4+i*(bw+gap); ax.add_patch(FancyBboxPatch((x,gy+gh-13.6),bw,6.4,boxstyle='round,pad=0,rounding_size=0.5',fc='white',ec='black',lw=1))
    ax.text(x+bw/2,gy+gh-10.4,a,ha='center',va='center',fontsize=8.8,linespacing=1.15)
# VarPro box
vy=gy+1.4; vh=17.6
ax.add_patch(FancyBboxPatch((4,vy),92,vh,boxstyle='round,pad=0,rounding_size=0.8',fc=HL,ec=HE,lw=1.8))
ax.text(5.5,vy+vh-1.2,'(b) Variable-projection reformulation',fontsize=11,fontweight='bold',color=HE,va='top')
ax.text(5.5,vy+vh-4.3,r'$Z(\omega)=\boldsymbol{\varphi}(\omega;\boldsymbol{\eta})^{\top}\mathbf{c}$:  linear coefficients $\mathbf{c}=(R_\infty,\ \Delta R\ \mathrm{or}\ 1/Q,\ L)$ solved exactly by'
        '\nbound-constrained linear least squares;  search only the nonlinear $\\boldsymbol{\\eta}$ (1, 2 or 4 dimensions)',fontsize=9.6,va='top',linespacing=1.4)
vals=['VP-L-SHADE','VP-ASHO-\nLSHADE','VP-MS-TRF','VP-L-SHADE\n+TRF','VP-Screen\n+TRF']
bw2=16.4; gap2=(88-5*bw2)/4
for i,a in enumerate(vals):
    x=6+i*(bw2+gap2); ax.add_patch(FancyBboxPatch((x,vy+1.3),bw2,5.6,boxstyle='round,pad=0,rounding_size=0.5',fc='white',ec=HE,lw=1.1))
    ax.text(x+bw2/2,vy+4.1,a,ha='center',va='center',fontsize=8.8,linespacing=1.15)
arrow(cx,gy+gh-13.6,vy+vh+0.1)
ax.text(cx+1,gy+gh-15.3,'same spectra, seeds, budget and success criterion',fontsize=8.6,fontstyle='italic',va='center',ha='left')
arrow(cx,gy,gy-2.2)
# performance
py=46.4; ph=18.4
group(py,ph,'Performance evaluation')
box(4,py+1.2,29.5,13.4,'Benchmark comparison',['Success rate vs. NFE','Friedman, Wilcoxon, Holm','Bootstrap 95% CIs','10,000-NFE budget check'],fs=9,tfs=10)
box(35.2,py+1.2,29.5,13.4,'Mechanism and rescue',['VPinit control (projection vs. start)','Jacobian condition numbers','HO rescue: ±5 pp equivalence','Restart / fixed-rescue ablation'],fs=9,tfs=10)
box(66.5,py+1.2,29.5,13.4,'Computational cost',['NFE to first success','Wall-clock time to solution','Same computer for both','MS-TRF vs. VP-MS-TRF'],fs=9,tfs=10)
arrow(cx,py,py-2.2)
# identifiability
iy=25.6; ih=18.4
group(iy,ih,'Identifiability and calibrated uncertainty')
box(4,iy+1.2,29.5,13.4,'Profile likelihood',['Global inner fit via VP','Error model from 51 sweeps','Bootstrap-calibrated, GLS','Coverage validation'],fs=9,tfs=10)
box(35.2,iy+1.2,29.5,13.4,'Synthetic experiments',['$f_c$ inside vs. below band','Bias of R–CPE–L descriptors','Band design: range vs. $N$','Electrode polarization, mismatch'],fs=9,tfs=10)
box(66.5,iy+1.2,29.5,13.4,'Robustness',['Width thresholds, bounds','High-frequency correction','Model selection (GLS, LOFO)','Sweep-level repeatability'],fs=9,tfs=10)
arrow(cx,iy,iy-2.2)
# interpretation
qy=6.0; qh=17.4
group(qy,qh,'Physical and medical interpretation')
box(4,qy+1.2,45,12.4,'Identifiable parameters (M11)',['$R_\\infty$, $Q$ and $\\alpha$ interpreted','Effective $L$ interpreted conservatively','Extrapolated $R_0$ and $f_c$ not interpreted'],fs=9,tfs=10)
box(51,qy+1.2,45,12.4,'Descriptive tissue characterization',['Parameter distributions across tissues','Band-specific descriptors with intervals','Reporting recommendations for tissue EIS'],fs=9,tfs=10)
arrow(cx,qy,qy-2.2)
box(42,0.6,16,3,'End',center=True,rounded=1.4)
fig.savefig(str(__import__('pathlib').Path(__file__).parent.parent/'results'/'figures'/'Fig01_Methods_v2.png'),dpi=300)
