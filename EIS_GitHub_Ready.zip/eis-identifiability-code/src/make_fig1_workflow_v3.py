"""Simplified study workflow (manuscript Fig. 1, round 3): six stages, print-size fonts."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path
plt.rcParams.update({'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold'})
fig = plt.figure(figsize=(7.1, 3.3)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 46); ax.axis('off')
HL, HE = '#e8f1fb', '#1f5f9e'
def stage(x, y, n, title, lines, hl=False):
    w, h = 30, 18.5
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0,rounding_size=1.2', fc=HL if hl else 'white', ec=HE if hl else 'black', lw=1.4 if hl else 1.0))
    ax.text(x + 1.6, y + h - 2.0, f'{n}', fontsize=11, fontweight='bold', color=HE, va='top')
    ax.text(x + 5.0, y + h - 2.0, title, fontsize=9.5, fontweight='bold', va='top')
    ax.text(x + 1.8, y + h - 6.2, '\n'.join(lines), fontsize=8.2, va='top', linespacing=1.4)
def arr(x1, y1, x2, y2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', lw=1.1, color='black', mutation_scale=11))
xs = [2, 35, 68]; yt, yb = 25.5, 1.5
stage(xs[0], yt, 1, 'Data and quality control', ['20 in vivo spectra, 10–100 kHz', '51 repeated sweeps', 'Kramers–Kronig check:', '12 consistent, 8 not'])
stage(xs[1], yt, 2, 'Circuit representation', ['11 candidate circuits (AICc, BIC)', 'R–CPE–L (M11), Cole+L (M10),', 'double Cole+L (M12)', 'High-frequency correction variants'])
stage(xs[2], yt, 3, 'Inversion', ['Original vs variable projection', '13 algorithms, equal budget', '(2,000 evaluations, 25 runs)', 'Mechanism control, timing'], hl=True)
stage(xs[2], yb, 4, 'Uncertainty, identifiability', ['Error model from sweeps', 'Calibrated profile likelihood', 'Closed-form band criterion', 'Band-design simulation'], hl=True)
stage(xs[1], yb, 5, 'Reproducibility', ['Between sweeps: drift', 'Between recordings: 35', 'single-frequency recordings', 'Per animal'])
stage(xs[0], yb, 6, 'Reporting', ['Decision rule (Fig. 5)', 'Calibrated intervals,', 'reproducibility limits', 'Open-source eisvarpro'])
arr(32, 34.7, 35, 34.7); arr(65, 34.7, 68, 34.7); arr(83, 25.5, 83, 20); arr(68, 10.7, 65, 10.7); arr(35, 10.7, 32, 10.7)
out = Path(__file__).parent.parent/'results'/'figures'/'Fig01_Methods_v3.png'; fig.savefig(out, dpi=400); print(out)
