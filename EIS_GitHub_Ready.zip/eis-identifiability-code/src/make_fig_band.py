import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
T = Path(__file__).parent.parent/'results'; D = pd.read_csv(T/'tables'/'band_design_runs.csv')
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
fig, ax = plt.subplots(1, 2, figsize=(9.2, 3.5))
C = {0.01: '#2166ac', 0.025: '#b2182b'}
for sig, g in D.groupby('noise'):
    for pn, ls, lab in [('logtau', '-', r'$\log_{10}\tau$'), ('logdR', '--', r'$\log_{10}\Delta R$')]:
        q = g.groupby('fmin_hz')[f'{pn}_ciw'].quantile([.25, .5, .75]).unstack()
        ax[0].plot(q.index, q[0.5], ls=ls, marker='o', ms=3.5, color=C[sig], label=f'{lab}, noise {100*sig:g}%')
        ax[0].fill_between(q.index, q[0.25], q[0.75], color=C[sig], alpha=.10, lw=0)
ax[0].set_xscale('log'); ax[0].set_yscale('log'); ax[0].invert_xaxis()
ax[0].set_xlabel('Lower band limit $f_{\\min}$ (Hz); upper limit 100 kHz'); ax[0].set_ylabel('95% profile CI width (decades)')
ax[0].axvline(1e4, color='0.5', lw=.8, ls=':'); ax[0].text(9e3, ax[0].get_ylim()[1]*0.6, 'measured\nband', fontsize=7.5, color='0.4', ha='left', va='top')
ax[0].legend(fontsize=7, frameon=False, loc='lower left'); ax[0].set_title('(a) Precision versus band extension', fontsize=9, loc='left')
for sig, g in D.groupby('noise'):
    ax[1].scatter(g.ratio_fmin_fc, g.logtau_ciw, s=9, alpha=.55, color=C[sig], label=f'noise {100*sig:g}%', edgecolors='none')
ax[1].set_xscale('log'); ax[1].set_yscale('log'); ax[1].axvline(1, color='0.4', lw=.8, ls='--')
ax[1].set_xlabel('$f_{\\min}/f_c$'); ax[1].set_ylabel(r'$\log_{10}\tau$ CI width (decades)')
ax[1].legend(fontsize=7, frameon=False, loc='upper left'); ax[1].set_title(r'(b) Precision versus $f_{\min}/f_c$', fontsize=9, loc='left')
plt.tight_layout(); plt.savefig(T/'figures_vp'/'Fig16_band_design.png', dpi=300)
