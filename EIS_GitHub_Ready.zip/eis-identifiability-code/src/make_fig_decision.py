"""Reporting decision diagram for Cole parameters (manuscript Fig. 10)."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon
from pathlib import Path
plt.rcParams.update({'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold', 'font.size': 8.5})
fig = plt.figure(figsize=(8.6, 6.2)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 72); ax.axis('off')
def box(x, y, w, h, txt, fc='white', ec='black', bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0,rounding_size=1.2', fc=fc, ec=ec, lw=1.1))
    ax.text(x+w/2, y+h/2, txt, ha='center', va='center', fontsize=8.5, fontweight='bold' if bold else 'normal', linespacing=1.35)
def diamond(xc, yc, w, h, txt):
    ax.add_patch(Polygon([(xc, yc+h/2), (xc+w/2, yc), (xc, yc-h/2), (xc-w/2, yc)], closed=True, fc='#f7f7f7', ec='black', lw=1.1))
    ax.text(xc, yc, txt, ha='center', va='center', fontsize=8.2, linespacing=1.3)
def arr(x1, y1, x2, y2, lab=None, lx=0, ly=0):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', lw=1.0, color='black', mutation_scale=11))
    if lab: ax.text((x1+x2)/2+lx, (y1+y2)/2+ly, lab, fontsize=8, fontstyle='italic')
box(30, 64, 40, 6, 'Measured spectrum $Z(f)$, band $[f_{\\min}, f_{\\max}]$', bold=True)
arr(50, 64, 50, 60.6)
diamond(50, 56, 34, 9, 'Linear Kramers–Kronig\nRMS residual < 3%?')
arr(67, 56, 74, 56, 'no', -3, 1)
box(74, 51.5, 24, 9, 'Flag spectrum:\nre-measure or interpret\nwith caution', fc='#fdecea', ec='#b2182b')
arr(50, 51.5, 50, 47.6, 'yes', 1, 0)
box(22, 40, 56, 7.6, 'Fit Cole+L and R–CPE–L by variable projection\nwith multistart local refinement; compare by AICc', bold=False)
arr(50, 40, 50, 36.6)
diamond(50, 30.5, 50, 12, 'Characteristic frequency inside the band\n($f_{\\min} \\leq f_c$) and calibrated 95% profile\ninterval of $\\log_{10}\\tau$ closed and < ~0.5 decade?')
ax.plot([25, 14], [30.5, 30.5], color='black', lw=1.0); arr(14, 30.5, 14, 27.6); ax.text(18.5, 31.6, 'yes', fontsize=8, fontstyle='italic')
box(1, 13, 26, 14.5, 'Report Cole parameters\n$R_0$, $R_\\infty$, $\\tau$ ($f_c$), $\\alpha$\nwith calibrated profile intervals', fc='#e8f1fb', ec='#2166ac', bold=False)
ax.plot([75, 84.5], [30.5, 30.5], color='black', lw=1.0); arr(84.5, 30.5, 84.5, 27.6); ax.text(78.5, 31.6, 'no', fontsize=8, fontstyle='italic')
box(70, 13, 29, 14.5, 'Report R–CPE–L descriptors\n$R_\\infty$, $Q$, $\\alpha$ (band-specific; state\nband and HF correction); do not\ninterpret $\\tau$, $\\Delta R$, $R_0$, $f_c$', fc='#e8f1fb', ec='#2166ac')
ax.plot([84.5, 84.5], [13, 7.8], color='black', lw=1.0, ls=(0, (3, 2))); arr(84.5, 7.8, 66.2, 7.8); ax.text(75.3, 5.4, 'if Cole parameters\nare needed', fontsize=7.6, fontstyle='italic', ha='center', va='top')
box(24, 3, 42, 9.6, 'To estimate Cole parameters, extend the band\nto $f_{\\min} \\leq f_c$ of the target tissue, control electrode\npolarization (e.g. tetrapolar), and repeat the assessment', fc='#fff7e6', ec='#b35806')
ax.text(50, 0.6, 'Thresholds are pragmatic suggestions from the band-design simulation; calibrate interval thresholds to the error model of the instrument.',
        ha='center', fontsize=7, color='0.35')
fig.savefig(Path(__file__).parent.parent/'results'/'figures'/'Fig18_reporting_decision_v2.png', dpi=300)
