"""Reporting decision rule (manuscript Fig. 5, round 3): thresholds identical to the Methods; every reported
parameter must itself be practically identifiable with a calibrated interval."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon
from pathlib import Path
plt.rcParams.update({'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold', 'font.size': 8.5})
fig = plt.figure(figsize=(7.1, 5.6)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 79); ax.axis('off')
def box(x, y, w, h, txt, fc='white', ec='black', bold=False, fs=8.4):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0,rounding_size=1.2', fc=fc, ec=ec, lw=1.1))
    ax.text(x+w/2, y+h/2, txt, ha='center', va='center', fontsize=fs, fontweight='bold' if bold else 'normal', linespacing=1.35)
def diamond(xc, yc, w, h, txt, fs=8.0):
    ax.add_patch(Polygon([(xc, yc+h/2), (xc+w/2, yc), (xc, yc-h/2), (xc-w/2, yc)], closed=True, fc='#f7f7f7', ec='black', lw=1.1))
    ax.text(xc, yc, txt, ha='center', va='center', fontsize=fs, linespacing=1.3)
def arr(x1, y1, x2, y2, lab=None, lx=0, ly=0):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', lw=1.0, color='black', mutation_scale=10))
    if lab: ax.text((x1+x2)/2+lx, (y1+y2)/2+ly, lab, fontsize=8, fontstyle='italic')
B, BE = '#e8f1fb', '#2166ac'; Rf, Re = '#fdecea', '#b2182b'
box(28, 72, 44, 6, 'Measured spectrum $Z(f)$ on band $[f_{\\min}, f_{\\max}]$', bold=True)
arr(50, 72, 50, 69)
diamond(50, 64.5, 34, 9, 'Linear Kramers–Kronig\nRMS residual < 3%?')
arr(67, 64.5, 73, 64.5, 'no', -3.2, 1)
box(73, 60, 26, 9, 'Flag: re-measure, or report\nas KK-inconsistent with\nreproducibility limits', fc=Rf, ec=Re)
arr(50, 60, 50, 56.6, 'yes', 1, 0)
box(16, 49, 68, 7.6, 'Fit Cole+L and R–CPE–L by variable projection with multistart refinement;\ncalibrate profile-likelihood thresholds to the error model of the instrument')
arr(50, 49, 50, 45.6)
diamond(50, 38.5, 72, 15, '$f_{\\min} \\leq f_c$ and, for every Cole parameter\nto be reported, a calibrated 95% interval\nthat is closed and < 1 decade (< 0.2 for $\\alpha$)?', fs=8.0)
ax.plot([14, 12], [38.5, 38.5], color='black', lw=1.0); arr(12, 38.5, 12, 30.6); ax.text(9, 39.8, 'yes', fontsize=8, fontstyle='italic')
box(1, 17, 25, 13.6, 'Report those Cole\nparameters with calibrated\nintervals; leave out any\nthat fail the criterion', fc=B, ec=BE)
ax.plot([86, 88], [38.5, 38.5], color='black', lw=1.0); arr(88, 38.5, 88, 30.6); ax.text(88.5, 39.8, 'no', fontsize=8, fontstyle='italic')
box(71, 17, 28, 13.6, 'Report $R_\\infty$, $Q$, $\\alpha$ that meet\nthe same criterion (band-\nspecific; state band, HF\ncorrection and probe); do not\ninterpret $\\tau$, $\\Delta R$, $R_0$, $f_c$', fc=B, ec=BE)
box(29, 17, 39, 13.6, 'With repeated sweeps or recordings,\nadd the reproducibility half-width\nor limit; detection limit $f_{\\min}/\\Gamma$ and\nEq. (10) state which dispersions\nthe band could resolve', fc='white', ec='0.4')
arr(26, 23.8, 29, 23.8); arr(71, 23.8, 68, 23.8)
box(24, 3, 52, 9.6, 'To estimate Cole parameters: extend the band to $f_{\\min} \\leq f_c$ of the\ntarget tissue, control electrode polarization (e.g. tetrapolar)\nand repeat the assessment', fc='#fff7e6', ec='#b35806')
ax.plot([85, 85], [17, 7.8], color='black', lw=1.0, ls=(0, (3, 2))); arr(85, 7.8, 76, 7.8)
out = Path(__file__).parent.parent/'results'/'figures'/'Fig18_reporting_decision_v3.png'; fig.savefig(out, dpi=400); print(out)
