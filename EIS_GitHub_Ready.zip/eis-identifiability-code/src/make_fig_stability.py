import pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
T = Path(__file__).parent.parent/'results'
R = pd.read_csv(T/'tables'/'Table_feature_stability.csv'); R = R[R.subset.str.startswith('KK')]
order = ['M10 log10 tau', 'M10 log10 dR', 'M10 alpha', 'M11 log10 Q', 'M11 alpha', 'M10 log10 Rinf', 'M11 log10 Rinf']
lab = {'M10 log10 tau': r'M10 $\log_{10}\tau$', 'M10 log10 dR': r'M10 $\log_{10}\Delta R$', 'M10 alpha': r'M10 $\alpha$',
       'M11 log10 Q': r'M11 $\log_{10}Q$', 'M11 alpha': r'M11 $\alpha$', 'M10 log10 Rinf': r'M10 $\log_{10}R_\infty$', 'M11 log10 Rinf': r'M11 $\log_{10}R_\infty$'}
R = R.set_index('feature').loc[order[::-1]]
col = ['#b2182b' if f in order[:3] else '#2166ac' for f in R.index]
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
fig, ax = plt.subplots(1, 2, figsize=(9, 3.4), sharey=True)
y = range(len(R))
ax[0].barh(y, R.median_rank_rho, color=col); ax[0].errorbar(R.q05_rank_rho, y, fmt='|', color='0.3', ms=8)
ax[0].set_yticks(list(y)); ax[0].set_yticklabels([lab[f] for f in R.index]); ax[0].set_xlim(-0.1, 1.02); ax[0].axvline(0, color='0.6', lw=.6)
ax[0].set_xlabel('Spearman correlation of spectrum rankings\nbetween resamples (bar: median; tick: 5th percentile)')
ax[0].set_title('(a) Ranking stability', fontsize=9, loc='left')
ax[1].barh(y, R.stable_pairs_pct, color=col); ax[1].set_xlim(0, 100)
for yi, v in zip(y, R.stable_pairs_pct): ax[1].text(v+1.5, yi, f'{v:.0f}%', va='center', fontsize=8)
ax[1].set_xlabel('Spectrum pairs ordered identically\nin at least 95% of resamples (%)')
ax[1].set_title('(b) Reliable pairwise discrimination', fontsize=9, loc='left')
plt.tight_layout(); plt.savefig(T/'figures_vp'/'Fig17_feature_stability.png', dpi=300)
