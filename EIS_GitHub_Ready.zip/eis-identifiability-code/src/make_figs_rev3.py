import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
T='results/tables/'; F='results/figures/'
plt.rcParams.update({'savefig.dpi':300,'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
kk=pd.read_csv(T+'Table_KK_check.csv'); bt=pd.read_csv(T+'repeatability_bootstrap_fits.csv')
# Fig: KK vs NRMSE
fig,ax=plt.subplots(figsize=(5.5,4)); ax.scatter(kk.kk_rms_pct,100*kk.ref_NRMSE,c='0.25')
for _,r in kk[kk.kk_rms_pct>3].iterrows(): ax.annotate(r.tissue,(r.kk_rms_pct,100*r.ref_NRMSE),fontsize=7,xytext=(3,2),textcoords='offset points')
ax.axvline(3,ls='--',c='0.5'); ax.set_xlabel('Linear Kramers–Kronig residual, RMS (%)'); ax.set_ylabel('M11 NRMSE (%)')
plt.tight_layout(); plt.savefig(F+'Fig13_KK_vs_fit.png'); plt.close()
# repeatability, KK-consistent only
good=kk[kk.kk_rms_pct<=3].source_file
rows=[]
for m,params in [('M10_ColeL',['logRinf','logdR','logtau','alpha','logL']),('M11_RCPEL',['logRinf','logQ','alpha','logL'])]:
    d=bt[(bt.model==m)&bt.source_file.isin(good)]
    for p in params:
        sd=d.groupby('source_file')[p].std(); mu=d.groupby('source_file')[p].mean(); vw=(sd**2).mean(); vb=mu.var()
        rows.append(dict(model=m,parameter=p,median_within_SD=sd.median(),ICC=vb/(vb+vw),sds=sd.values))
r=pd.DataFrame(rows); r.drop(columns='sds').to_csv(T+'Table_repeatability_KKconsistent.csv',index=False); print(r.drop(columns='sds').round(4).to_string()); print('n good',len(good))
lab={('M10_ColeL','logRinf'):'M10 log R∞',('M10_ColeL','logdR'):'M10 log ΔR',('M10_ColeL','logtau'):'M10 log τ',('M10_ColeL','alpha'):'M10 α',('M10_ColeL','logL'):'M10 log L',
     ('M11_RCPEL','logRinf'):'M11 log R∞',('M11_RCPEL','logQ'):'M11 log Q',('M11_RCPEL','alpha'):'M11 α',('M11_RCPEL','logL'):'M11 log L'}
fig,axs=plt.subplots(1,2,figsize=(11,3.8))
axs[0].boxplot([np.maximum(x,1e-4) for x in r.sds],tick_labels=[lab[(a,b)] for a,b in zip(r.model,r.parameter)]); axs[0].set_yscale('log')
axs[0].set_ylabel('Within-spectrum SD (reading-level bootstrap)'); axs[0].tick_params(axis='x',rotation=45,labelsize=7)
axs[1].bar([lab[(a,b)] for a,b in zip(r.model,r.parameter)],r.ICC,color=['0.65']*5+['0.25']*4); axs[1].set_ylabel('ICC (between / total variance)')
axs[1].tick_params(axis='x',rotation=45,labelsize=7); axs[1].set_ylim(0,1)
plt.tight_layout(); plt.savefig(F+'Fig14_repeatability.png'); plt.close()
# Graphical abstract 200:500
fig,ax=plt.subplots(figsize=(10,4)); ax.set_xlim(0,10); ax.set_ylim(0,4); ax.axis('off')
boxes=[(0.2,'In vivo porcine EIS\n20 spectra, 12 tissues\n10–100 kHz'),(2.7,'Equal-budget benchmark\n8 optimizers\nASHO-LSHADE ≈ L-SHADE\nMS-TRF: 100% success'),
       (5.2,'Identifiability\nf$_c$ below band (19/20)\nτ, ΔR not recoverable'),(7.7,'Reduced R–CPE–L\nidentifiable, repeatable\n(ICC 0.7–0.8)')]
for x,t in boxes:
    ax.add_patch(FancyBboxPatch((x,1.0),2.1,2.0,boxstyle='round,pad=0.05',fill=False,lw=1.6)); ax.text(x+1.05,2.0,t,ha='center',va='center',fontsize=10.5)
for x in [2.3,4.8,7.3]: ax.add_patch(FancyArrowPatch((x,2.0),(x+0.4,2.0),arrowstyle='->',mutation_scale=16,lw=1.5))
ax.text(5,3.55,'When do metaheuristics help in tissue EIS inversion?',ha='center',fontsize=13,weight='bold')
ax.text(5,0.45,'Recommendation: multistart/memetic local refinement + profile-likelihood check + identifiable descriptors',ha='center',fontsize=9.5)
plt.savefig(F+'Graphical_abstract.png',dpi=300); plt.close()
from PIL import Image; print(Image.open(F+'Graphical_abstract.png').size)
