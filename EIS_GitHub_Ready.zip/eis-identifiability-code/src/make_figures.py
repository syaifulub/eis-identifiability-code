"""make_figures.py - publication figures for the revised manuscript (reads results/tables)."""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent)); from eis_core import predict, MODELS
R = Path(__file__).resolve().parent.parent/('results_quick' if '--quick' in sys.argv else 'results'); T = R/'tables'; F = R/'figures'; F.mkdir(exist_ok=True)
plt.rcParams.update({'figure.dpi': 110, 'savefig.dpi': 300, 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
ALG = ['HO','MS-TRF','L-SHADE','L-SHADE-Restart','SAHO-LSHADE','ASHO-LSHADE','L-SHADE+TRF','ASHO-LSHADE+TRF']
MK = dict(zip(ALG, ['v','s','o','^','D','*','P','X']))
MNAME = {'M10_ColeL': 'M10 (Cole + L)', 'M11_RCPEL': 'M11 (R–CPE–L)'}
def save(name): plt.tight_layout(); plt.savefig(F/name, bbox_inches='tight'); plt.close()
short = lambda sf: sf.replace('pr_','').replace('_SP_yellow_bipolar_',' ').replace('.txt','')

# Fig 1 workflow
fig, ax = plt.subplots(figsize=(13, 2.9)); ax.set_xlim(0, 13.2); ax.set_ylim(0.6, 2.9); ax.axis('off')
lab = ['Raw EIS\n(10–100 kHz)', 'QC & complete-\nspectrum unit', 'ECM screening\n(weighted AICc/BIC)',
       'Optimizer benchmark\n(equal NFE, 25 runs)', 'Identifiability\n(profile likelihood,\nsynthetic recovery)',
       'Model reduction\nM10 → M11 (R–CPE–L)', 'Bounded physical\ninterpretation']
xs = np.linspace(0.1, 11.4, 7); wd = 1.65
for x, l in zip(xs, lab):
    ax.add_patch(FancyBboxPatch((x, 1.0), wd, 1.15, boxstyle='round,pad=0.04', fill=False, lw=1.2))
    ax.text(x+wd/2, 1.575, l, ha='center', va='center', fontsize=8.5)
for i in range(6):
    ax.add_patch(FancyArrowPatch((xs[i]+wd+0.02, 1.575), (xs[i+1]-0.04, 1.575), arrowstyle='->', mutation_scale=11))
ax.text(6.6, 2.6, 'Optimization–identifiability framework for tissue EIS inverse modelling', ha='center', weight='bold', fontsize=11)
save('Fig01_workflow.png')

comp = pd.read_csv(T/'ecm_ready_complete_scans.csv')
comp = comp[comp.source_file.isin(pd.read_csv(T/'best_known_solutions.csv').source_file)]
fig, ax = plt.subplots(figsize=(6.5, 3.4)); comp.groupby('tissue').source_file.nunique().sort_values(ascending=False).plot.bar(ax=ax, color='0.55')
ax.set_ylabel('Complete spectra'); ax.set_xlabel(''); ax.tick_params(axis='x', rotation=40); save('Fig02a_complete_spectra_by_tissue.png')
fig, ax = plt.subplots(figsize=(6.2, 4.6))
for sf, g in comp.groupby('source_file'):
    g = g.sort_values('frequency_khz'); ax.plot(g.resistance_ohm, -g.reactance_ohm, 'o-', ms=2.5, lw=0.9, label=g.tissue.iloc[0])
h, l = ax.get_legend_handles_labels(); u = dict(zip(l, h)); ax.legend(u.values(), u.keys(), fontsize=6.5, ncol=2)
ax.set_xlabel("Z′ (Ω)"); ax.set_ylabel("−Z″ (Ω)"); ax.set_title('All 20 complete spectra (10–100 kHz)'); save('Fig02b_nyquist_all.png')

ecm = pd.read_csv(T/'Table_ECM_screening.csv')
fig, ax = plt.subplots(figsize=(7.5, 3.4)); e = ecm.sort_values('mean_AICc_rank')
ax.bar(e.model.str.replace('_',' '), e.mean_AICc_rank, color=['0.2' if m in ('M10_ColeL','M11_RCPEL') else '0.65' for m in e.model])
ax.set_ylabel('Mean AICc rank (lower is better)'); ax.tick_params(axis='x', rotation=40); save('Fig03_ECM_AICc_rank.png')

# Fig 4 representative fit
ref = pd.read_csv(T/'best_known_solutions.csv'); sfs = sorted(comp.source_file.unique())
sfs = sorted(ref.source_file.unique()); rep = ref[ref.model=='M11_RCPEL'].sort_values('ref_NRMSE').source_file.iloc[len(sfs)//2]
g = comp[comp.source_file==rep].sort_values('frequency_khz'); w = 2*np.pi*1000*g.frequency_khz.to_numpy(); z = g.resistance_ohm.to_numpy()+1j*g.reactance_ohm.to_numpy()
wf = 2*np.pi*1000*np.linspace(10, 100, 200)
fig, axs = plt.subplots(1, 2, figsize=(10, 4))
axs[0].plot(z.real, -z.imag, 'ko', label='Measured')
for m, ls in [('M10_ColeL','-'), ('M11_RCPEL','--')]:
    x = ref[(ref.model==m)&(ref.source_file==rep)][MODELS[m][0]].to_numpy(float)[0]; zf = predict(m, x, wf)
    axs[0].plot(zf.real, -zf.imag, ls, label=MNAME[m])
axs[0].set_xlabel("Z′ (Ω)"); axs[0].set_ylabel("−Z″ (Ω)"); axs[0].legend(); axs[0].set_title(short(rep))
for m, mk in [('M10_ColeL','o'), ('M11_RCPEL','s')]:
    res = []
    for sf in sfs:
        gg = comp[comp.source_file==sf].sort_values('frequency_khz'); ww = 2*np.pi*1000*gg.frequency_khz.to_numpy()
        zz = gg.resistance_ohm.to_numpy()+1j*gg.reactance_ohm.to_numpy()
        x = ref[(ref.model==m)&(ref.source_file==sf)][MODELS[m][0]].to_numpy(float)[0]
        res.append(np.abs(predict(m, x, ww)-zz)/np.abs(zz))
    res = np.array(res); axs[1].plot(np.arange(10,101,10), np.median(res, 0), mk+'-', label=MNAME[m])
axs[1].set_xlabel('Frequency (kHz)'); axs[1].set_ylabel('Median |relative residual|'); axs[1].legend(); axs[1].set_title('Residuals across 20 spectra')
save('Fig04_representative_fit_residuals.png')

# Fig 5 convergence
tr = pd.read_csv(T/'convergence_traces.csv').merge(ref[['model','source_file','ref_NRMSE']], on=['model','source_file'])
tr['gap'] = (tr.best_NRMSE - tr.ref_NRMSE)/tr.ref_NRMSE
fig, axs = plt.subplots(1, 2, figsize=(10.5, 4), sharey=True)
for ax, m in zip(axs, MNAME):
    d = tr[tr.model==m].groupby(['algorithm','NFE']).gap.median().reset_index()
    for a in ALG:
        q = d[d.algorithm==a]; ax.plot(q.NFE, np.maximum(q.gap, 1e-7), marker=MK[a], ms=4, label=a)
    ax.set_yscale('log'); ax.set_xlabel('NFE'); ax.set_title(MNAME[m])
axs[0].set_ylabel('Median relative NRMSE gap to best-known'); axs[1].legend(fontsize=7)
save('Fig05_convergence.png')

# Fig 6 gap distribution and success
runs = pd.read_csv(T/'optimizer_runs.csv')
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2), sharey=True)
for ax, m in zip(axs, MNAME):
    d = runs[runs.model==m]; data = [np.maximum(d[d.algorithm==a].rel_gap, 1e-7) for a in ALG]
    ax.boxplot(data, tick_labels=ALG, showfliers=False); ax.set_yscale('log'); ax.tick_params(axis='x', rotation=45, labelsize=7)
    ax.axhline(1e-3, ls=':', c='0.4'); ax.set_title(MNAME[m])
    for i, a in enumerate(ALG):
        ax.text(i+1, 2e-7, f"{100*d[d.algorithm==a].success.mean():.0f}%", ha='center', fontsize=7)
axs[0].set_ylabel('Relative NRMSE gap (per run)'); save('Fig06_gap_success.png')

# Fig 7 ASHO adaptation
a = runs[(runs.algorithm=='ASHO-LSHADE')]
fig, axs = plt.subplots(1, 2, figsize=(9.5, 3.6))
for m in MNAME:
    q = a[a.model==m].groupby('source_file')[['rescue_trials','rescue_success']].sum()
    axs[0].hist(q.rescue_success/q.rescue_trials.replace(0, np.nan), bins=10, alpha=.6, label=MNAME[m])
    axs[1].hist(a[a.model==m].final_pHO.dropna(), bins=15, alpha=.6, label=MNAME[m])
axs[0].set_xlabel('HO rescue success rate per spectrum'); axs[0].set_ylabel('Spectra'); axs[0].legend(fontsize=7)
axs[1].axvline(0.25, ls='--', c='k', lw=1); axs[1].set_xlabel('Final adaptive $p_{HO}$ per run'); axs[1].set_ylabel('Runs')
save('Fig07_ASHO_adaptation.png')

# Fig 8 profiles
pc = pd.read_csv(T/'profile_curves.csv')
fig, axs = plt.subplots(2, 4, figsize=(13, 5.6))
panels = [('M10_ColeL','logtau','log$_{10}$ τ (M10)'), ('M10_ColeL','logdR','log$_{10}$ ΔR (M10)'),
          ('M10_ColeL','alpha','α (M10)'), ('M10_ColeL','logRinf','log$_{10}$ R$_∞$ (M10)'),
          ('M11_RCPEL','logQ','log$_{10}$ Q (M11)'), ('M11_RCPEL','alpha','α (M11)'),
          ('M11_RCPEL','logRinf','log$_{10}$ R$_∞$ (M11)'), ('M11_RCPEL','logL','log$_{10}$ L (M11)')]
for ax, (m, p, t) in zip(axs.ravel(), panels):
    for sf, g in pc[(pc.model==m)&(pc.parameter==p)].groupby('source_file'):
        ax.plot(g.value, np.minimum(g.LR, 60), lw=0.8, alpha=0.75)
    ax.axhline(3.84, ls='--', c='k', lw=0.9); ax.set_ylim(-1, 61); ax.set_title(t, fontsize=9)
for ax in axs[:, 0]: ax.set_ylabel('Profile LR (capped at 60)')
save('Fig08_profile_likelihood.png')

# Fig 9 fc band coverage
b = pd.read_csv(T/'Table_fc_band_coverage.csv').sort_values('fc_hat_hz').reset_index(drop=True)
fig, ax = plt.subplots(figsize=(8, 4.6)); y = np.arange(len(b))
ax.axvspan(10e3, 100e3, color='0.85', label='Measured band (10–100 kHz)')
lo = np.maximum(b.fc_ci_low_hz, 1e-2); hi = np.minimum(b.fc_ci_high_hz, 1e8)
ax.hlines(y, lo, hi, color='0.3'); ax.plot(b.fc_hat_hz, y, 'ko', ms=4, label='M10 estimate $f_c$')
ax.set_xscale('log'); ax.set_yticks(y); ax.set_yticklabels([f'{t} ({s[3:15]})' for t, s in zip(b.tissue, b.source_file)], fontsize=6.5)
ax.set_xlabel('Characteristic frequency $f_c$ (Hz) with 95% profile CI'); ax.legend(fontsize=7, loc='lower right')
save('Fig09_fc_band_coverage.png')

# Fig 10 synthetic recovery
s = pd.read_csv(T/'synthetic_recovery_runs.csv')
pars = ['abs_err_logRinf','abs_err_logdR','abs_err_logtau','abs_err_alpha','abs_err_logL','abs_err_logQ']
lbl = ['log R$_∞$','log ΔR','log τ','α','log L','log Q']
fig, axs = plt.subplots(1, 2, figsize=(12, 4), sharey=True)
algs_show = ['HO','MS-TRF','L-SHADE','ASHO-LSHADE','ASHO-LSHADE+TRF']
for ax, rg, tt in zip(axs, ['A','B'], ['Regime A: $f_c$ inside band', 'Regime B: $f_c$ below band (as in real data)']):
    d = s[s.regime==rg]; wdt = 0.16
    for k, alg in enumerate(algs_show):
        med = [d[d.algorithm==alg][p].median() for p in pars]
        ax.bar(np.arange(len(pars)) + (k-2)*wdt, np.maximum(med, 1e-5), wdt, label=alg)
    ax.set_xticks(range(len(pars))); ax.set_xticklabels(lbl); ax.set_yscale('log'); ax.set_title(tt)
axs[0].set_ylabel('Median absolute recovery error'); axs[1].legend(fontsize=7); save('Fig10_synthetic_recovery.png')

# Fig 11 M11 descriptors by tissue
ph = pd.read_csv(T/'Table_M11_physical_parameters.csv')
fig, axs = plt.subplots(1, 4, figsize=(13, 3.6))
for ax, (c, t, lg) in zip(axs, [('Rinf_ohm','R$_∞$ (Ω)',True), ('Q','Q (S·s$^α$)',True), ('alpha','α',False), ('L_H','L (H)',True)]):
    o = ph.groupby('tissue')[c].median().sort_values().index
    for i, ti in enumerate(o):
        v = ph[ph.tissue==ti][c]; ax.plot([i]*len(v), v, 'o', c='0.3', ms=4)
    ax.set_xticks(range(len(o))); ax.set_xticklabels(o, rotation=60, fontsize=7); ax.set_title(t)
    if lg: ax.set_yscale('log')
save('Fig11_M11_descriptors_by_tissue.png')
print('figures:', sorted(p.name for p in F.glob('*.png')))

# Fig 12 higher-dimensional stress test (M12, 8 parameters)
p12 = T/'Table_M12_performance.csv'
if p12.exists():
    m = pd.read_csv(p12); cps = [100,200,500,1000,1500,2000]
    fig, ax = plt.subplots(figsize=(6.8, 4))
    for _, r in m.iterrows():
        ax.plot(cps, [100*r[f'success_at_{c}'] for c in cps], marker=MK[r.algorithm], ms=4, label=r.algorithm)
    ax.set_xlabel('NFE'); ax.set_ylabel('Runs within 0.1% of best-known (%)'); ax.set_title('M12 double Cole + L (8 parameters)')
    ax.legend(fontsize=7); save('Fig12_M12_stress_test.png')
