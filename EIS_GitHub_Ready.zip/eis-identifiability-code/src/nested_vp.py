"""nested_vp.py - limit of the variable-projection gain for a weakly separable (nested) circuit.

M13: Cole + L tissue model shunted by a parallel constant-phase element (stray/electrode capacitance),
    Z = 1 / (1/Z_C + Q_p (jw)^beta) + jwL,   Z_C = Rinf + dR/(1 + (jw tau)^alpha).
Because R_inf and dR are nested inside the inversion, only L enters linearly: partial VarPro
eliminates one of seven parameters (6-D nonlinear search), compared with 3 of 5 for M10.
Same 20 spectra, seeds, 25 runs, 2,000 NFE and 0.1% success rule as the main benchmark.
Usage: python3 nested_vp.py [runs]
"""
import sys, math, time, pickle, numpy as np, pandas as pd
from pathlib import Path
from scipy.optimize import least_squares
from scipy.stats import wilcoxon
from eis_core import lshade_family, Tracker, _Budget
from vp_common import load_spectra, TAB

NAMES = ['logRinf', 'logdR', 'logtau', 'alpha', 'logQp', 'beta', 'logL']
LO = np.array([-3., -3., -7., 0.30, -14., 0.50, -9.]); HI = np.array([7., 8., 1., 1.0, -6., 1.0, 0.])
RUNS = int(sys.argv[1]) if len(sys.argv) > 1 else 25; BUDGET = 2000; SEED0 = 20261101 + 330000
CPS = (100, 200, 500, 1000, 1500, 2000)
CACHE = TAB.parent/'cache_nested'; CACHE.mkdir(exist_ok=True)

def zpar(x, w):
    jw = 1j*w; zc = 10**x[0] + 10**x[1]/(1 + (jw*10**x[2])**x[3])
    return 1/(1/zc + 10**x[4]*jw**x[5])

class Problem:
    def __init__(self, w, z):
        self.w, self.z = w, z; self.wt = 1/np.maximum(np.abs(z), 1.0); self.N = len(w)
    # full parameterization
    def res(self, x):
        r = (zpar(x, self.w) + 1j*self.w*10**x[6] - self.z)*self.wt; return np.r_[r.real, r.imag]
    def f(self, x): r = self.res(x); return float(r @ r)/self.N
    # partial VarPro: L solved exactly (scalar bounded LS; clipping is exact for one variable)
    def res_vp(self, t):
        a = 1j*self.w*self.wt; b = (self.z - zpar(t, self.w))*self.wt
        A = np.r_[a.real, a.imag]; B = np.r_[b.real, b.imag]
        L = float(np.clip((A @ B)/(A @ A), 10**LO[6], 10**HI[6])); return A*L - B
    def f_vp(self, t): r = self.res_vp(t); return float(r @ r)/self.N

def ms(fun_res, fun_f, lo, hi, seed):
    rng = np.random.default_rng(seed); T = Tracker(fun_f, BUDGET, CPS)
    def r(x):
        if T.nfe >= BUDGET: raise _Budget
        T(x); return fun_res(x)
    while T.nfe < BUDGET:
        try: least_squares(r, rng.uniform(lo, hi), bounds=(lo, hi), jac='2-point', max_nfev=10000)
        except _Budget: break
    return T.best, T.trace

def run(alg, P, seed):
    t0 = time.perf_counter()
    if alg == 'MS-TRF': fb, tr = ms(P.res, P.f, LO, HI, seed)
    elif alg == 'VP-MS-TRF': fb, tr = ms(P.res_vp, P.f_vp, LO[:6], HI[:6], seed)
    elif alg == 'L-SHADE': _, fb, tr, _ = lshade_family(P.f, LO, HI, BUDGET, seed, 'lshade', CPS)
    elif alg == 'VP-L-SHADE': _, fb, tr, _ = lshade_family(P.f_vp, LO[:6], HI[:6], BUDGET, seed, 'lshade', CPS)
    tr = {c: tr.get(c, fb) for c in CPS}
    return fb, tr, time.perf_counter()-t0

if __name__ == '__main__':
    ALGS = ['MS-TRF', 'VP-MS-TRF', 'L-SHADE', 'VP-L-SHADE']; rows = []
    for s in load_spectra():
        p = CACHE/f"m13_{s['si']}_{RUNS}.pkl"
        if p.exists(): rows += pickle.load(open(p, 'rb')); continue
        P = Problem(s['w'], s['z']); out = []
        for r in range(RUNS):
            seed = SEED0 + s['si']*1000 + r
            for a in ALGS:
                fb, tr, sec = run(a, P, seed)
                out.append(dict(source_file=s['sf'], tissue=s['tissue'], algorithm=a, run=r+1, NRMSE=math.sqrt(fb),
                                runtime_sec=sec, **{f'trace_{c}': math.sqrt(v) for c, v in tr.items()}))
        pickle.dump(out, open(p, 'wb')); rows += out
        print(time.strftime('%H:%M:%S'), s['si'], s['tissue'], flush=True)
    D = pd.DataFrame(rows); ref = D.groupby('source_file').NRMSE.min(); D['ref'] = D.source_file.map(ref)
    for c in CPS: D[f'succ_{c}'] = (D[f'trace_{c}'] - D.ref)/D.ref <= 1e-3
    D.to_csv(TAB/'nested_m13_runs.csv', index=False)
    S = D.groupby('algorithm').agg(**{f'success_at_{c}': (f'succ_{c}', 'mean') for c in CPS},
                                    spectra_all_success=('succ_2000', lambda x: 0)).reset_index()
    S['spectra_all_success'] = [int(D[D.algorithm == a].groupby('source_file').succ_2000.mean().eq(1).sum()) for a in S.algorithm]
    S.to_csv(TAB/'Table_nested_M13.csv', index=False)
    med = D.groupby(['source_file', 'algorithm']).NRMSE.median().unstack(); P_ = []
    for a, b in [('VP-MS-TRF', 'MS-TRF'), ('VP-L-SHADE', 'L-SHADE')]:
        rel = (med[a]-med[b])/med[b]
        try: p = wilcoxon(med[a], med[b]).pvalue
        except ValueError: p = 1.0
        P_.append(dict(comparison=f'{a} vs {b}', better=int((rel < -1e-3).sum()), worse=int((rel > 1e-3).sum()), p=p))
    pd.DataFrame(P_).to_csv(TAB/'Table_nested_M13_paired.csv', index=False)
    pd.set_option('display.width', 200); print(S.round(3).to_string()); print(pd.DataFrame(P_).to_string())
