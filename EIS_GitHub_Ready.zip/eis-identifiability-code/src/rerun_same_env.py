"""rerun_same_env.py - reruns the complete Table 2 benchmark (8 original + 5 VarPro algorithms, 20 spectra x 25 runs,
2,000 NFE, same seeds) in the environment used for the timing experiment, so that success rates and timings come from
one computer. Usage: python rerun_same_env.py MODEL   (M10_ColeL | M11_RCPEL | M12_DoubleColeL)"""
import sys, math, time, pickle, platform, numpy as np, pandas as pd
from pathlib import Path
from vp_common import load_spectra, TAB
import eis_core as E, vp_core as V
model = sys.argv[1]; SEED0 = 20261101; RUNS = 25; CPS = (500, 2000)
OUT = TAB.parent/'rerun_same_env'; OUT.mkdir(exist_ok=True)
rows = []
for s in load_spectra():
    cp = OUT/f'{model}_{s["si"]}.pkl'
    if cp.exists(): rows += pickle.load(open(cp, 'rb')); continue
    out = []
    for r in range(RUNS):
        seed = SEED0 + s['si']*1000 + r
        for a in E.ALGORITHMS:
            x, fb, tr, ex, sec = E.run_algorithm(a, model, s['w'], s['z'], 2000, seed, CPS)
            out.append(dict(source_file=s['sf'], run=r+1, algorithm=a, NRMSE=math.sqrt(fb), sec=sec, **{f't{c}': math.sqrt(tr.get(c, fb)) for c in CPS}))
        for a in V.VP_ALGORITHMS:
            x, fb, tr, sec = V.run_vp(a, model, s['w'], s['z'], 2000, seed, CPS)
            out.append(dict(source_file=s['sf'], run=r+1, algorithm=a, NRMSE=math.sqrt(fb), sec=sec, **{f't{c}': math.sqrt(tr.get(c, fb)) for c in CPS}))
    pickle.dump(out, open(cp, 'wb')); rows += out; print(time.strftime('%H:%M:%S'), model, s['si'], flush=True)
D = pd.DataFrame(rows); ref = pd.read_csv(TAB/f'vp_merged_{model}.csv').groupby('source_file').ref.first()
D['ref'] = D.source_file.map(ref)
for c in CPS: D[f's{c}'] = (D[f't{c}'] - D.ref)/D.ref <= 1e-3
D.to_csv(OUT/f'runs_{model}.csv', index=False)
S = D.groupby('algorithm')[['s500', 's2000']].mean().mul(100); S['new_minima'] = D.groupby('algorithm').apply(lambda g: int(((g.NRMSE - g.ref)/g.ref < -1e-6).sum()), include_groups=False)
S.to_csv(OUT/f'success_{model}.csv'); print(S.round(1).to_string()); print(platform.platform(), platform.processor())
