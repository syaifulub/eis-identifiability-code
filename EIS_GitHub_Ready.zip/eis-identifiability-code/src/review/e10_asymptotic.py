"""E10: closed-form band-coverage criterion and bias formula for the Cole model above its characteristic frequency.

Above f_c, with u = (j w tau)^-alpha and the CPE term w(w) = dR u = (j w)^-alpha / Q,
    Cole term = w/(1+u) = w - w u + O(w u^2).
Hence the data carry information on tau only through the second-order term w u, whose size relative to |Z| at f_min
is rho_min (f_min/f_c)^-alpha. Writing eta = 1/dR (eta -> 0 is the R-CPE-L limit), the Fisher information for eta with
R_inf, Q, alpha, L as nuisance parameters is ||P h||^2 / sigma^2 (h = w^2/|Z|, P the projector onto the complement of
the R-CPE-L tangent space, sigma the SD of each stacked real component of the relative residual). Since
alpha ln tau = ln Q - ln eta,
    W95(log10 tau) ~= 2 z sigma (f_min/f_c)^alpha / (alpha ln10 D),   D = ||P h~||,  h~_k = w_k (j w_k / w_min)^-alpha / |Z_k|,
where D depends on the band, the sampling and the impedance composition but not on f_c. Practical identifiability
(W95 < W*) therefore requires
    f_min / f_c < Gamma = (alpha ln10 D W* / (2 z sigma))^(1/alpha).
Fitting R-CPE-L to Cole data leaves the misfit -w u; its linearized least-squares projection gives the bias
    delta theta = -(J^T J)^-1 J^T h~ (f_min/f_c)^-alpha,   J the R-CPE-L Jacobian (relative, stacked).
Validation: (a) synthetic spectra of the band-design study (profile widths, Table S21) and the exact linearized
(Wald) width from the full Cole Jacobian; (b) bias against the numerical fits of Table S17; (c) the 20 measured spectra."""
import math, json, numpy as np, pandas as pd
from scipy.stats import spearmanr
import r2_core as R
T = R.T; LN10 = math.log(10)

def stack(c): return np.r_[c.real, c.imag]
def m11_tangent(w, Rinf, Q, alpha, L, absZ):
    jw = 1j*w; cpe = jw**(-alpha)/Q
    cols = [Rinf/absZ, -cpe/absZ, -np.log(jw)*cpe/absZ, jw*L/absZ]
    return np.column_stack([stack(c) for c in cols]), cpe
def D_factor(w, Rinf, Q, alpha, L, absZ):
    J, cpe = m11_tangent(w, Rinf, Q, alpha, L, absZ); wmin = w.min()
    ht = stack(cpe*(1j*w/wmin)**(-alpha)/absZ)
    P = np.eye(len(ht)) - J @ np.linalg.pinv(J); return float(np.linalg.norm(P @ ht)), J, ht
def W_asym(D, alpha, sigma, ratio, z=1.96): return 2*z*sigma*ratio**alpha/(alpha*LN10*D)
def Gamma(D, alpha, sigma, Wstar=1.0, z=1.96): return (alpha*LN10*D*Wstar/(2*z*sigma))**(1/alpha)
def cole(x, w): return x['Rinf'] + x['dR']/(1 + (1j*w*x['tau'])**x['alpha']) + 1j*w*x['L']
def W_wald(x, w, sigma, z=1.96):
    """exact linearized width from the full Cole+L Jacobian (log10 parameters, alpha)"""
    th = np.array([math.log10(x['Rinf']), math.log10(x['dR']), math.log10(x['tau']), x['alpha'], math.log10(x['L'])]); absZ = np.abs(cole(x, w))
    def m(t): return stack(cole(dict(Rinf=10**t[0], dR=10**t[1], tau=10**t[2], alpha=t[3], L=10**t[4]), w)/absZ)
    J = np.column_stack([(m(th + 1e-6*np.eye(5)[k]) - m(th - 1e-6*np.eye(5)[k]))/2e-6 for k in range(5)])
    C = np.linalg.pinv(J.T @ J)*sigma**2; return 2*z*math.sqrt(max(C[2, 2], 0))

# (a) synthetic band-design spectra
FC = {'low': (100, 1000), 'mid': (1000, 10000), 'near': (10000, 30000)}
def truth(i, fc_rng):
    rng = np.random.default_rng(424242 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(*np.log10(fc_rng)); tau = 1/(2*np.pi*fc); dR = rng.uniform(1, 3)*Rinf
    return dict(Rinf=Rinf, dR=dR, tau=tau, alpha=a, L=L, fc=fc)
E = pd.read_csv(T/'e5_band_runs.csv'); rows = []
sig_white = 0.025/math.sqrt(2)
for r in E.itertuples():
    x = truth(r.spectrum, FC[r.fc_class]); N = r.N
    f = np.linspace(r.fmin_hz, 1e5, N) if r.design == 'linear' else np.logspace(np.log10(r.fmin_hz), 5, N); w = 2*np.pi*f
    absZ = np.abs(cole(x, w)); Q = x['tau']**x['alpha']/x['dR']
    D, _, _ = D_factor(w, x['Rinf'], Q, x['alpha'], x['L'], absZ); ratio = r.fmin_hz/x['fc']
    rows.append(dict(design=r.design, N=N, fc_class=r.fc_class, spectrum=r.spectrum, fmin_hz=r.fmin_hz, ratio=ratio, alpha=x['alpha'], D=D,
                     Gamma=Gamma(D, x['alpha'], sig_white), W_asym=W_asym(D, x['alpha'], sig_white, ratio), W_wald=W_wald(x, w, sig_white),
                     W_prof=r.tau_width, closed=r.tau_closed, ident_obs=r.tau_ident))
A = pd.DataFrame(rows); A['ident_pred'] = A.W_asym < 1.0; A['ident_pred_wald'] = A.W_wald < 1.0; A.to_csv(T/'e10_synthetic.csv', index=False)
out = []
for d, g in A.groupby('design'):
    c = g[g.closed]; rec = dict(design=d, n=len(g), closed=len(c))
    rec['spearman_asym_prof'] = spearmanr(np.log(c.W_asym), np.log(c.W_prof)).statistic if len(c) > 5 else np.nan
    rec['median_ratio_asym_prof'] = float(np.median(c.W_asym/c.W_prof)) if len(c) else np.nan
    rec['median_ratio_wald_prof'] = float(np.median(c.W_wald/c.W_prof)) if len(c) else np.nan
    rec['agree_asym_pct'] = 100*float((g.ident_pred == g.ident_obs).mean()); rec['agree_wald_pct'] = 100*float((g.ident_pred_wald == g.ident_obs).mean())
    rec['false_ident_pct'] = 100*float((g.ident_pred & ~g.ident_obs).mean()); rec['missed_ident_pct'] = 100*float((~g.ident_pred & g.ident_obs).mean())
    out.append(rec)
SA = pd.DataFrame(out); SA.to_csv(T/'Table_E10_synthetic.csv', index=False); print(SA.round(3).to_string())
# accuracy of the asymptotic width by f_min/f_c (white-noise designs, closed profiles)
g = A[A.design.isin(['base', 'linear']) & A.closed].copy(); g['bin'] = pd.cut(g.ratio, [0, 1, 3, 10, 1e4], labels=['<1', '1-3', '3-10', '>10'])
print(g.groupby('bin', observed=True).apply(lambda h: pd.Series(dict(n=len(h), med_asym_over_prof=np.median(h.W_asym/h.W_prof), med_wald_over_prof=np.median(h.W_wald/h.W_prof))), include_groups=False).round(2))
print('Gamma (white 2.5%, Wstar = 1 decade): median', A[A.design == 'base'].Gamma.median(), 'IQR', A[A.design == 'base'].Gamma.quantile([.25, .75]).round(2).tolist())

# (b) bias formula against numerical R-CPE-L fits of Cole data (Table S17)
Bn = pd.read_csv(T/'e1b_bias_runs.csv'); SP = {s['sf']: s for s in R.spectra()}; rows = []
for sf, g in Bn.groupby('source_file'):
    s = SP[sf]; p = R.fit('rcpe_l', s['f'], s['Z'])['params']; a = min(max(p['alpha'], 0.5), 0.95); w = 2*np.pi*s['f']
    Z11 = p['Rinf'] + (1j*w)**(-a)/p['Q'] + 1j*w*p['L']; absZ = np.maximum(np.abs(Z11), 1.0)
    D, J, ht = D_factor(w, p['Rinf'], p['Q'], a, p['L'], absZ); b = -np.linalg.lstsq(J, ht, rcond=None)[0]   # per unit (f_min/f_c)^-alpha
    for r in g.itertuples():
        k = r.fmin_over_fc**(-a)
        rows.append(dict(source_file=sf, fc_hz=r.fc_hz, fmin_over_fc=r.fmin_over_fc, alpha=a, bias_logQ_num=r.bias_log10_Q, bias_logQ_formula=b[1]*k/LN10,
                         bias_alpha_num=r.bias_alpha, bias_alpha_formula=b[2]*k, bQ=b[1]/LN10, balpha=b[2]))
Bb = pd.DataFrame(rows); Bb.to_csv(T/'e10_bias.csv', index=False)
SB = Bb.groupby('fmin_over_fc')[['bias_logQ_num', 'bias_logQ_formula', 'bias_alpha_num', 'bias_alpha_formula']].median().sort_index(ascending=False)
SB.to_csv(T/'Table_E10_bias.csv'); print(SB.round(3).to_string())
print('median coefficient b_Q (decades per unit (fmin/fc)^-alpha)', Bb.bQ.median(), 'b_alpha', Bb.balpha.median())

# (c) measured spectra: detection limit f_c* = f_min / Gamma and predicted vs profile width at the fitted f_c
I = pd.read_csv(T/'e1_intervals_M10.csv'); I = I[(I.param == 'log10_tau') & (I.objective == 'nom') & (I.threshold == 'chi2')].set_index('source_file')
Ic = pd.read_csv(T/'e1_intervals_M10.csv'); Ic = Ic[(Ic.param == 'log10_tau') & (Ic.objective == 'nom') & (Ic.threshold == 'cal')].set_index('source_file')
rows = []
for s in R.spectra():
    F11 = R.fit('rcpe_l', s['f'], s['Z']); p = F11['params']; F10 = R.fit('cole_l', s['f'], s['Z']); q = F10['params']
    w = 2*np.pi*s['f']; absZ = np.maximum(np.abs(s['Z']), 1.0); sig = math.sqrt(F10['rss']/(20 - 5))
    D, _, _ = D_factor(w, p['Rinf'], p['Q'], p['alpha'], p['L'], absZ)
    G = Gamma(D, p['alpha'], sig); Gc = Gamma(D, p['alpha'], sig, z=math.sqrt(Ic.loc[s['sf'], 'thr']))
    fc_hat = 1/(2*np.pi*10**q['log10_tau']); ratio = s['f'].min()/fc_hat
    rows.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], sigma=sig, alpha=p['alpha'], D=D, Gamma=G, fc_detect_hz=s['f'].min()/G,
                     fc_detect_cal_hz=s['f'].min()/Gc, fc_hat_hz=fc_hat, fc_ci_high_hz=1/(2*np.pi*10**I.loc[s['sf'], 'ci_low']),
                     W_asym_at_fchat=W_asym(D, p['alpha'], sig, ratio), W_prof=I.loc[s['sf'], 'width'], closed=bool(I.loc[s['sf'], 'closed']),
                     ident_obs=bool(I.loc[s['sf'], 'closed'] and I.loc[s['sf'], 'width'] < 1)))
M = pd.DataFrame(rows); M['ident_pred'] = M.W_asym_at_fchat < 1; M.to_csv(T/'Table_E10_measured.csv', index=False)
print(M[['tissue', 'kk_ok', 'sigma', 'alpha', 'Gamma', 'fc_detect_hz', 'fc_hat_hz', 'fc_ci_high_hz', 'W_asym_at_fchat', 'W_prof', 'ident_obs', 'ident_pred']].round(3).to_string())
print('agreement measured', (M.ident_pred == M.ident_obs).mean(), 'spearman log fc_detect vs log fc_ci_high', spearmanr(np.log(M.fc_detect_hz), np.log(M.fc_ci_high_hz)).statistic)
print('median Gamma measured', M.Gamma.median(), M.Gamma.quantile([.25, .75]).tolist(), 'median f_c detect (Hz)', M.fc_detect_hz.median())
