"""Figure for the asymptotic band criterion (E10)."""
import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import r2_core as R
T = R.T; OUT = T.parent/'figures'
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'; C1, C2 = '#2a78d6', '#eb6834'
plt.rcParams.update({'font.size': 8.3, 'axes.edgecolor': INK2, 'xtick.color': INK2, 'ytick.color': INK2, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold'})
A = pd.read_csv(T/'e10_synthetic.csv'); B = pd.read_csv(T/'e10_bias.csv'); M = pd.read_csv(T/'Table_E10_measured.csv')
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.7))
a = ax[0]; g = A[A.design.isin(['base', 'linear', 'corr']) & A.closed]
bins = [(0, 1, '#cde2fb', '$<1$'), (1, 3, '#86b6ef', '1–3'), (3, 10, '#2a78d6', '3–10'), (10, 1e4, '#104281', '$>10$')]
for lo, hi, col, lab in bins:
    h = g[(g.ratio >= lo) & (g.ratio < hi)]; a.scatter(h.W_asym, h.W_prof, s=7, color=col, edgecolor='none', label=lab, alpha=0.9)
lim = [3e-4, 30]; a.plot(lim, lim, color=INK2, lw=0.8); a.axhline(1, color=INK2, lw=0.6, ls='--'); a.axvline(1, color=INK2, lw=0.6, ls='--')
a.set_xscale('log'); a.set_yscale('log'); a.set_xlim(lim); a.set_ylim(lim); a.set_xlabel('Predicted width, Eq. (8) (decades)'); a.set_ylabel('Profile-likelihood width (decades)')
a.legend(title='$f_{\\min}/f_c$', frameon=False, fontsize=6.5, title_fontsize=6.5, loc='upper left', markerscale=1.5)
a.set_title('(a) Width of the $\\log_{10}\\tau$ interval', fontsize=8.5, loc='left')
a = ax[1]; m = B.groupby('fmin_over_fc')[['bias_logQ_num', 'bias_logQ_formula', 'bias_alpha_num', 'bias_alpha_formula']].median()
x = m.index.values
a.plot(x, m.bias_logQ_formula, color=C1, lw=1.6, label='$\\log_{10}Q$, Eq. (10)'); a.plot(x, m.bias_logQ_num, 'o', color=C1, ms=4.5, mec='#fcfcfb', mew=0.6, label='$\\log_{10}Q$, refit')
a.plot(x, -m.bias_alpha_formula, color=C2, lw=1.6, label='$-\\alpha$, Eq. (10)'); a.plot(x, -m.bias_alpha_num, 's', color=C2, ms=4.5, mec='#fcfcfb', mew=0.6, label='$-\\alpha$, refit')
a.set_xscale('log'); a.set_yscale('log'); a.set_xlabel('$f_{\\min}/f_c$'); a.set_ylabel('Bias of R–CPE–L descriptor'); a.grid(color=GRID, lw=0.5); a.set_axisbelow(True)
a.legend(frameon=False, fontsize=6.3); a.set_title('(b) Bias of $Q$ and $\\alpha$', fontsize=8.5, loc='left')
a = ax[2]
for kk, mk, col, lab in [(True, 'o', C1, 'KK-consistent'), (False, 's', C2, 'KK-inconsistent')]:
    h = M[(M.kk_ok == kk) & (M.fc_detect_hz < 1e5)]; a.plot(h.fc_detect_hz, h.fc_ci_high_hz, mk, color=col, ms=4.5, mec='#fcfcfb', mew=0.6, label=lab, ls='none')
lim = [3e2, 1e5]; a.plot(lim, lim, color=INK2, lw=0.8); a.set_xscale('log'); a.set_yscale('log'); a.set_xlim(lim); a.set_ylim(lim)
a.set_xlabel('Detection limit $f_{\\min}/\\Gamma$ (Hz)'); a.set_ylabel('Upper 95% bound of $f_c$ (Hz)'); a.legend(frameon=False, fontsize=6.5, loc='upper left')
a.set_title('(c) Measured spectra', fontsize=8.5, loc='left')
fig.tight_layout(); fig.savefig(OUT/'Fig20_asymptotic_criterion.png', dpi=300); print('ok', (M.fc_detect_hz >= 1e5).sum(), 'off-scale')
