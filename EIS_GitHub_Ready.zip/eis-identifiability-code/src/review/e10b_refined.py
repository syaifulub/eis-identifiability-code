"""E10b: refinement of the closed-form criterion.
(1) Truncation bound: the expansion w/(1+u) = w - w u + w u^2 - ... has relative remainder |u|/(1-|u|) with
    |u| <= (f_min/f_c)^-alpha, so the first-order formula is accurate (remainder < 30%) when f_min/f_c > (0.3)^(-1/alpha)/... ;
    we report r_max = (f_min/f_c)^-alpha for every case and the accuracy of Eq. (8) as a function of r_max.
(2) Refined width: exact derivative of the Cole term with respect to eta = 1/dR at the true f_c, -w^2/(1+u)^2, and the
    full delta method for log10 tau = (log10 Q - log10 eta)/alpha including the alpha and Q covariances
    (Fisher matrix of (ln Rinf, ln Q, alpha, ln L, ln eta) at the truth).
Compared with the profile-likelihood widths of the band-design spectra (white and correlated noise, closed profiles)."""
import math, numpy as np, pandas as pd
import r2_core as R
LN10 = math.log(10); sig_white = 0.025/math.sqrt(2)
FC = {'low': (100, 1000), 'mid': (1000, 10000), 'near': (10000, 30000)}
def stack(c): return np.r_[c.real, c.imag]
def cole(x, w): return x['Rinf'] + x['dR']/(1 + (1j*w*x['tau'])**x['alpha']) + 1j*w*x['L']
def truth(i, fc_rng):     # identical to e5_band_factorial.py / e10_asymptotic.py
    rng = np.random.default_rng(424242 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(*np.log10(fc_rng)); tau = 1/(2*np.pi*fc); dR = rng.uniform(1, 3)*Rinf
    return dict(Rinf=Rinf, dR=dR, tau=tau, alpha=a, L=L, fc=fc)
T = R.T; A = pd.read_csv(T/'e10_synthetic.csv'); rows = []
for r in A[A.design.isin(['base', 'linear', 'corr'])].itertuples():
    x = truth(r.spectrum, FC[r.fc_class]); f = np.linspace(r.fmin_hz, 1e5, r.N) if r.design == 'linear' else np.logspace(np.log10(r.fmin_hz), 5, r.N)
    w = 2*np.pi*f; jw = 1j*w; a = x['alpha']; Z = cole(x, w); absZ = np.abs(Z); Q = x['tau']**a/x['dR']; eta = 1/x['dR']
    cpe = jw**(-a)/Q; u = (jw*x['tau'])**(-a)
    # Cole term written as cpe/(1+eta*cpe); parameters p = (ln Rinf, ln Q, alpha, ln L, ln eta)
    d_cole = 1/(1 + u)**2                                          # d[cpe/(1+eta cpe)]/d cpe
    cols = [x['Rinf']/absZ, d_cole*(-cpe)/absZ, d_cole*(-np.log(jw)*cpe)/absZ, jw*x['L']/absZ, -(cpe*u/(1 + u)**2)/absZ]
    J = np.column_stack([stack(c) for c in cols]); C = np.linalg.pinv(J.T @ J)*sig_white**2
    g = np.array([0, 1/a, -math.log(x['tau'])/a, 0, -1/a])           # d ln tau / d p  (ln tau = (ln Q - ln eta)/alpha)
    W_ref = 2*1.96*math.sqrt(max(g @ C @ g, 0))/LN10
    g0 = np.array([0, 0, 0, 0, -1/a]); W_eta_only = 2*1.96*math.sqrt(max(g0 @ C @ g0, 0))/LN10   # without Q and alpha terms
    rows.append(dict(design=r.design, ratio=r.ratio, rmax=r.ratio**(-a), alpha=a, W_asym=r.W_asym, W_wald=r.W_wald, W_ref=W_ref, W_eta_only=W_eta_only,
                     W_prof=r.W_prof, closed=r.closed, ident_obs=r.ident_obs))
B = pd.DataFrame(rows); B.to_csv(T/'e10b_refined.csv', index=False)
c = B[B.closed].copy(); c['rbin'] = pd.cut(c.rmax, [0, 0.1, 0.3, 0.6, 1.0, 100], labels=['<0.1', '0.1-0.3', '0.3-0.6', '0.6-1', '>1'])
S = c.groupby('rbin', observed=True).apply(lambda h: pd.Series(dict(n=len(h), asym=np.median(h.W_asym/h.W_prof), refined=np.median(h.W_ref/h.W_prof),
        eta_only=np.median(h.W_eta_only/h.W_prof), wald=np.median(h.W_wald/h.W_prof))), include_groups=False)
S.to_csv(T/'Table_E10b_refined.csv'); print(S.round(2).to_string())
agree = lambda col: 100*((B[col] < 1) == B.ident_obs).mean()
print('classification agreement %: asym', round(agree('W_asym'), 1), 'refined', round(agree('W_ref'), 1), 'wald', round(agree('W_wald'), 1))
print('alpha/Q coupling inflates width by median factor', round(float(np.median(B.W_ref/B.W_eta_only)), 2), 'IQR', B.eval('W_ref/W_eta_only').quantile([.25, .75]).round(2).tolist())
