"""E11: separation of fitting uncertainty and between-sweep drift.
For every sweep of the recordings with >= 2 sweeps, the R-CPE-L descriptors are estimated with calibrated 95% profile
intervals (B = 100, residual-based covariance); s = half-width/1.96 is the fitting standard error. Within recording i,
    theta_is = mu_i + d_is + e_is,   d_is ~ N(0, tau_d^2) (drift),   e_is ~ N(0, s_is^2) (fitting error, known),
and tau_d^2 is estimated by restricted maximum likelihood with mu_i profiled out, separately for KK-consistent and
KK-inconsistent recordings; 95% intervals from 1,000 resamples of recordings; test of tau_d = 0 by the likelihood
ratio with a 50:50 chi2_0/chi2_1 reference. Reproducibility half-width: 1.96 sqrt(s^2 + tau_d^2).
Usage: python e11_drift.py RAW_DIR"""
import sys, json, math, time, numpy as np, pandas as pd
from scipy.optimize import minimize_scalar
from scipy.stats import chi2
import r2_core as R
T = R.T; SW = R.sweeps(sys.argv[1]); S = R.sigma_struct(json.load(open(T/'E1_psi.json'))['psi']); PARS = ['log10_Q', 'alpha', 'log10_Rinf']
rows = []
for si, s in enumerate(R.spectra()):
    X = SW[s['sf']]
    if len(X) < 2: continue
    for i, z in enumerate(X):
        F = R.fit('rcpe_l', s['f'], z); p = F['params']; zt = R.predict('rcpe_l', p, s['f'])
        tv = {'log10_Q': math.log10(p['Q']), 'alpha': p['alpha'], 'log10_Rinf': math.log10(p['Rinf'])}
        Lc = np.linalg.cholesky(S*F['rss']/(np.trace(S)*(1 - 4/20))); rng = np.random.default_rng(9100 + 100*si + i); L = {q: [] for q in PARS}
        for b in range(100):
            zz = R.noise_draw(rng, Lc, zt); rm = R.fit('rcpe_l', s['f'], zz)['rss']
            for q in PARS: L[q].append(R.lr_at('rcpe_l', s['f'], zz, q, tv[q], None, rm))
        rec = dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], sweep=i)
        for q in PARS:
            g, lr, est = R.profile_curve('rcpe_l', s['f'], z, q); lo, hi, w, cl = R.ci_from_curve(g, lr, float(np.quantile(L[q], .95)))
            rec[q] = est; rec['s_'+q] = w/2/1.96; rec['closed_'+q] = cl
        rows.append(rec)
    print(time.strftime('%H:%M:%S'), si, len(X), flush=True)
D = pd.DataFrame(rows); D.to_csv(T/'e11_sweep_estimates.csv', index=False)

def reml(groups, t2):
    ll = 0.0
    for th, s2 in groups:
        v = s2 + t2; wgt = 1/v; mu = (wgt*th).sum()/wgt.sum()
        ll += -0.5*(np.log(v).sum() + math.log(wgt.sum()) + (wgt*(th - mu)**2).sum())
    return ll
def fit_tau(groups):
    top = max(1e-12, 4*max(np.var(th) for th, _ in groups) + 1e-6)
    r = minimize_scalar(lambda t: -reml(groups, t**2), bounds=(0, math.sqrt(top)*3), method='bounded', options={'xatol': 1e-9})
    t = r.x if reml(groups, r.x**2) > reml(groups, 0.0) else 0.0
    lr = 2*(reml(groups, t**2) - reml(groups, 0.0)); return t, max(lr, 0.0)
out = []; rng = np.random.default_rng(5)
for kk in [True, False]:
    d = D[D.kk_ok == kk]; recs = d.source_file.unique()
    for q in PARS:
        groups = {r: (g[q].to_numpy(), (g['s_'+q]**2).to_numpy()) for r, g in d.groupby('source_file')}
        t, lr = fit_tau(list(groups.values())); p = 0.5*chi2.sf(lr, 1) if lr > 0 else 1.0
        bs = [fit_tau([groups[r] for r in rng.choice(recs, len(recs), replace=True)])[0] for _ in range(1000)]
        s_med = float(np.sqrt(np.median(d['s_'+q]**2)))
        out.append(dict(kk_ok=kk, param=q, recordings=len(recs), sweeps=len(d), median_fit_se=s_med, tau_drift=t, tau_ci_low=np.quantile(bs, .025),
                        tau_ci_high=np.quantile(bs, .975), drift_to_fit_ratio=t/s_med, p_drift=p,
                        fit_halfwidth=1.96*s_med, reproducibility_halfwidth=1.96*math.sqrt(s_med**2 + t**2)))
O = pd.DataFrame(out); O.to_csv(T/'Table_E11_drift.csv', index=False); print(O.round(4).to_string())
