"""E11b: inference for the drift SD tau_d that does not rely on the bootstrap (which is degenerate at tau_d = 0).
(a) Profile (REML) likelihood interval: one-sided 95% upper bound {tau: 2[l(tau_hat) - l(tau)] <= 2.71} (boundary at 0),
    and the two-sided 95% interval with 3.84 when tau_hat > 0.
(b) Bayesian sensitivity: posterior of tau_d under half-normal priors (scale 0.05 and 0.2 decade for log parameters,
    0.01 and 0.05 for alpha), with the recording means integrated out (REML likelihood), on a fine grid."""
import math, numpy as np, pandas as pd
import r2_core as R
T = R.T; D = pd.read_csv(T/'e11_sweep_estimates.csv'); PARS = ['log10_Q', 'alpha', 'log10_Rinf']
def reml(groups, t2):
    ll = 0.0
    for th, s2 in groups:
        v = s2 + t2; w = 1/v; mu = (w*th).sum()/w.sum(); ll += -0.5*(np.log(v).sum() + math.log(w.sum()) + (w*(th - mu)**2).sum())
    return ll
rows = []
for kk in [True, False]:
    d = D[D.kk_ok == kk]
    for q in PARS:
        G = [(g[q].to_numpy(), (g['s_'+q]**2).to_numpy()) for _, g in d.groupby('source_file')]
        top = 5*max(1e-6, max(np.std(th) for th, _ in G)) + 5*math.sqrt(np.median(d['s_'+q]**2))
        grid = np.linspace(0, top, 4001); ll = np.array([reml(G, t*t) for t in grid]); i = int(ll.argmax()); th = grid[i]; lmax = ll[i]
        up95 = grid[np.flatnonzero(2*(lmax - ll) <= 2.71)].max()
        two = grid[np.flatnonzero(2*(lmax - ll) <= 3.84)]
        rec = dict(kk_ok=kk, param=q, tau_hat=th, upper95_onesided=up95, ci2_low=two.min(), ci2_high=two.max(), fit_se=float(np.sqrt(np.median(d['s_'+q]**2))))
        for sc in ((0.05, 0.2) if q != 'alpha' else (0.01, 0.05)):
            post = np.exp(ll - lmax)*np.exp(-0.5*(grid/sc)**2); post /= np.trapezoid(post, grid); c = np.cumsum(post)*(grid[1]-grid[0])
            rec[f'post_median_s{sc}'] = grid[np.searchsorted(c, 0.5)]; rec[f'post_upper95_s{sc}'] = grid[np.searchsorted(c, 0.95)]
        rows.append(rec)
O = pd.DataFrame(rows); O.to_csv(T/'Table_E11b_drift_ci.csv', index=False); print(O.round(4).to_string())
