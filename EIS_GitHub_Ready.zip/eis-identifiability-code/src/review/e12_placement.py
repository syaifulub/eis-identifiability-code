"""E12: between-recording (placement) variability, reproducibility limits and per-animal analysis from existing data.
No new measurements. Uses (i) the single-frequency recordings of the dataset (tasks 2-4: static tissue recordings and
vessel punctures with the same bipolar probes and with a monopolar probe), (ii) the 100 kHz point of every sweep of the
20 frequency-scan recordings, and (iii) the R-CPE-L descriptor estimates of Sect. 3.4/3.7.

1. Every single-frequency recording is summarised by the median resistance in its most stable window (20% of readings,
   at least 15, minimum robust SD of log10 R); vessel recordings start in the surrounding tissue and end in blood, so
   each is a separate needle advance. Recordings of the same medium with the same probe, animal and frequency form a
   group; the pooled between-recording SD of log10 R (chi-square 95% CI) is compared with the within-recording SDs
   (short-term, between sweeps) and with the between-sweep drift of R_inf.
2. Transfer to R_inf: within recordings, between-sweep changes of log10 R_inf and log10 R(100 kHz) are regressed through
   the origin; the slope converts the between-placement SD of R(100 kHz) into an R_inf scale.
3. Descriptor-level between-recording SD from the recordings of the same tissue in the same animal (muscle x5, liver x2,
   vein x2), after subtracting the within-recording variance (fitting SE^2 + drift^2).
4. Repeatability and reproducibility limits r = 2.77 s_w, R = 2.77 sqrt(s_w^2 + s_b^2) (ISO 5725 form) and the fraction
   of tissue pairs (KK-consistent spectra) whose descriptor difference exceeds them.
5. Main results recomputed per animal (= subset A / subset D; animal, subset and date are confounded).
Usage: python e12_placement.py RAW_DIR"""
import sys, glob, os, math, itertools, json, numpy as np, pandas as pd
from scipy.stats import chi2
import r2_core as R
RAW = sys.argv[1]; T = R.T; LOG = math.log10

def read(p):
    txt = open(p).read().replace('\t', ';')
    rows = [l.split(';')[:8] for l in txt.splitlines() if l.count(';') >= 6]
    d = pd.DataFrame(rows, columns=['st', 'f', 'mag', 'ph', 'R', 'X', 't', 'tis'])
    for c in ['f', 'R', 'X']: d[c] = pd.to_numeric(d[c])
    return d

def stable(Rv):
    Rv = np.asarray(Rv, float); n = len(Rv); w = max(15, int(round(0.2*n)))
    if n < w: w = n
    best = None
    for i in range(0, n - w + 1):
        x = Rv[i:i+w]
        if (x <= 0).any(): continue
        lx = np.log10(x); s = 1.4826*np.median(np.abs(lx - np.median(lx)))
        if best is None or s < best[0]: best = (s, float(np.median(x)), i, w)
    return best   # (robust SD of log10 R, median R, start, window)

# ---------------- 1. single-frequency recordings
meta = []
for p in sorted(glob.glob(RAW + '/byExperimentalTask/_task[234]/**/*.txt', recursive=True)):
    fn = os.path.basename(p); m = fn.replace('.txt', '').split('_')
    stamp = m[1]; animal = 1 if stamp.startswith('2023') else 2
    probe = 'monopolar' if 'monop' in fn else m[3]
    medium = 'blood' if fn.endswith('_blood.txt') else ('surrounding' if fn.endswith('_surrounding.txt') else m[-1])
    vessel = 'vein' if '_vein_' in fn else ('artery' if '_artery_' in fn else '')
    if medium == 'surrounding': continue
    d = read(p); b = stable(d.R.to_numpy())
    if b is None: continue
    win = d.iloc[b[2]:b[2]+b[3]]; ph = float(np.degrees(np.arctan2(win.X, win.R)).median())
    meta.append(dict(source='single', file=fn, animal=animal, probe=probe, medium=medium, vessel=vessel, f_khz=int(d.f.iloc[0]),
                     n=len(d), R=b[1], sd_short=b[0], phase_deg=ph))
# 100 kHz point of the sweep recordings (yellow probe, animal 1/2)
SW = R.sweeps(RAW); sw100 = []
for s in R.spectra():
    X = SW[s['sf']]; k = int(np.argmin(np.abs(s['f'] - 1e5))); r100 = X[:, k].real; ph100 = np.degrees(np.angle(X[:, k]))
    animal = 1 if '_2023' in s['sf'] else 2
    for i, v in enumerate(r100): sw100.append(dict(file=s['sf'], sweep=i, logR100=LOG(v), phase=ph100[i], kk_ok=s['kk_ok']))
    meta.append(dict(source='sweep', file=s['sf'], animal=animal, probe='yellow', medium=s['tissue'], vessel='', f_khz=100, n=len(X),
                     R=float(np.median(r100)), sd_short=np.nan, kk_ok=s['kk_ok'], phase_deg=float(np.median(ph100))))
# 9-frequency skin recording (100 kHz block medians)
for p in glob.glob(RAW + '/byOriginalSubset/subset A/*skin*.txt'):
    d = read(p); d = d[d.f == 100].reset_index(drop=True); b = stable(d.R.to_numpy()); win = d.iloc[b[2]:b[2]+b[3]]
    meta.append(dict(source='sweep9', file=os.path.basename(p), animal=1, probe='yellow', medium='skin', vessel='', f_khz=100, n=len(d), R=b[1], sd_short=b[0],
                     phase_deg=float(np.degrees(np.arctan2(win.X, win.R)).median())))
M = pd.DataFrame(meta); M['logR'] = np.log10(M.R)
M['medium_g'] = np.where(M.medium == 'blood', 'blood_' + M.vessel, M.medium)
M.to_csv(T/'e12_recordings.csv', index=False)

def pooled(groups):
    num = sum((len(g) - 1)*np.var(g, ddof=1) for g in groups if len(g) > 1); nu = sum(len(g) - 1 for g in groups if len(g) > 1)
    if nu == 0: return np.nan, np.nan, np.nan, 0
    s = math.sqrt(num/nu); return s, s*math.sqrt(nu/chi2.ppf(.975, nu)), s*math.sqrt(nu/chi2.ppf(.025, nu)), nu
rows = []
for key, g in M.groupby(['animal', 'probe', 'medium_g', 'f_khz']):
    if len(g) < 2: continue
    s = np.std(g.logR, ddof=1)
    rows.append(dict(animal=key[0], probe=key[1], medium=key[2], f_khz=key[3], recordings=len(g), median_R_ohm=g.R.median(),
                     between_sd_log10=s, cv_pct=100*(10**s - 1), short_term_sd_log10=g.sd_short.median(), between_sd_phase_deg=np.std(g.phase_deg, ddof=1),
                     median_phase_deg=g.phase_deg.median()))
G = pd.DataFrame(rows)
sw = pd.DataFrame(sw100); within_sw = pooled([g.logR100.to_numpy() for _, g in sw[sw.kk_ok].groupby('file') if len(g) > 1])
within_sw_all = pooled([g.logR100.to_numpy() for _, g in sw.groupby('file') if len(g) > 1])
within_ph = pooled([g.phase.to_numpy() for _, g in sw[sw.kk_ok].groupby('file') if len(g) > 1])
summ = []
for lab, sel in [('blood, bipolar (same probe)', (G.medium.str.startswith('blood')) & (G.probe != 'monopolar')),
                 ('blood, monopolar', (G.medium.str.startswith('blood')) & (G.probe == 'monopolar')),
                 ('tissue, yellow bipolar 100 kHz', ~G.medium.str.startswith('blood'))]:
    keys = G[sel][['animal', 'probe', 'medium', 'f_khz']].itertuples(index=False)
    grp = [M[(M.animal == a) & (M.probe == p) & (M.medium_g == m) & (M.f_khz == f)].logR.to_numpy() for a, p, m, f in keys]
    s, lo, hi, nu = pooled(grp)
    grp_ph = [M[(M.animal == a) & (M.probe == p) & (M.medium_g == m) & (M.f_khz == f)].phase_deg.to_numpy() for a, p, m, f in G[sel][['animal', 'probe', 'medium', 'f_khz']].itertuples(index=False)]
    sph = pooled(grp_ph)
    summ.append(dict(set=lab, groups=int(sel.sum()), recordings=int(sum(len(x) for x in grp)), df=nu,
                     between_sd=s, ci_low=lo, ci_high=hi, cv_pct=100*(10**s - 1), phase_sd_deg=sph[0], phase_ci_high=sph[2]))
summ.append(dict(set='within recording, between sweeps, KK-consistent (R at 100 kHz)', groups=np.nan, recordings=int(sw[sw.kk_ok].groupby('file').size().gt(1).sum()),
                 df=within_sw[3], between_sd=within_sw[0], ci_low=within_sw[1], ci_high=within_sw[2], cv_pct=100*(10**within_sw[0] - 1), phase_sd_deg=within_ph[0], phase_ci_high=within_ph[2]))
summ.append(dict(set='within recording, between sweeps, all (R at 100 kHz)', groups=np.nan, recordings=int(sw.groupby('file').size().gt(1).sum()),
                 df=within_sw_all[3], between_sd=within_sw_all[0], ci_low=within_sw_all[1], ci_high=within_sw_all[2], cv_pct=100*(10**within_sw_all[0] - 1)))
summ.append(dict(set='within recording, short-term (stable window)', groups=np.nan, recordings=int(M.sd_short.notna().sum()), df=np.nan,
                 between_sd=float(M.sd_short.median()), ci_low=np.nan, ci_high=np.nan, cv_pct=100*(10**M.sd_short.median() - 1)))
S1 = pd.DataFrame(summ)
# probe effect: same tissue, same animal, yellow vs white bipolar (100 kHz)
pe = []
for tis in ['tendon', 'subcutaneous', 'bladder', 'intestine']:
    y = M[(M.probe == 'yellow') & (M.medium == tis) & (M.animal == 1)].logR; w = M[(M.probe == 'white') & (M.medium == tis)].logR
    if len(y) and len(w): pe.append(dict(tissue=tis, n_yellow=len(y), n_white=len(w), log10_ratio_white_yellow=float(w.mean() - y.mean())))
bl_y = M[(M.probe == 'yellow') & (M.medium == 'blood') & (M.animal == 1)].logR; bl_w = M[(M.probe == 'white') & (M.medium == 'blood')].logR
pe.append(dict(tissue='blood', n_yellow=len(bl_y), n_white=len(bl_w), log10_ratio_white_yellow=float(bl_w.mean() - bl_y.mean())))
PE = pd.DataFrame(pe)

# ---------------- 2. transfer from R(100 kHz) to R_inf (within-recording sweep changes)
E = pd.read_csv(T/'e11_sweep_estimates.csv').merge(sw.drop(columns='kk_ok').rename(columns={'file': 'source_file'}), on=['source_file', 'sweep'])
tr = {}
for kk in [True, False, None]:
    e = E if kk is None else E[E.kk_ok == kk]
    dx = e.logR100 - e.groupby('source_file').logR100.transform('mean'); dy = e.log10_Rinf - e.groupby('source_file').log10_Rinf.transform('mean')
    b = float((dx*dy).sum()/(dx*dx).sum()); r = float(np.corrcoef(dx, dy)[0, 1])
    tr['all' if kk is None else ('kk' if kk else 'nonkk')] = dict(slope=b, r=r, n=len(e))
sp = pd.DataFrame([dict(sf=s['sf'], logR100=LOG(s['Z'][np.argmin(np.abs(s['f'] - 1e5))].real)) for s in R.spectra()])
P = pd.read_csv(T/'Table_M11_physical_parameters.csv').merge(sp, left_on='source_file', right_on='sf')
tr['across_spectra'] = dict(slope=float(np.polyfit(P.logR100, np.log10(P.Rinf_ohm), 1)[0]), r=float(np.corrcoef(P.logR100, np.log10(P.Rinf_ohm))[0, 1]), n=len(P))

# ---------------- 3. descriptor-level between-recording SD (same tissue, same animal)
I = pd.read_csv(T/'e1_intervals_M11.csv'); I = I[(I.objective == 'nom') & (I.threshold == 'cal')]
I['se'] = I.width/2/1.96; I['animal'] = np.where(I.source_file.str.contains('_2023'), 1, 2)
DR = pd.read_csv(T/'Table_E11_drift.csv').set_index(['kk_ok', 'param'])
desc = []
for q in ['log10_Q', 'alpha', 'log10_Rinf']:
    d = I[I.param == q].copy(); d['w2'] = d.se**2 + [DR.loc[(k, q), 'tau_drift']**2 for k in d.kk_ok]
    for lab, sel in [('all', d.kk_ok | ~d.kk_ok), ('KK-consistent', d.kk_ok)]:
        dd = d[sel]; grp = [g for _, g in dd.groupby(['animal', 'tissue']) if len(g) > 1]
        if not grp: continue
        s, lo, hi, nu = pooled([g.estimate.to_numpy() for g in grp]); w2 = float(np.mean(np.concatenate([g.w2.to_numpy() for g in grp])))
        desc.append(dict(param=q, set=lab, groups='; '.join(f'{g.tissue.iloc[0]} x{len(g)} (animal {g.animal.iloc[0]})' for g in grp), df=nu,
                         between_recording_sd=s, ci_high=hi, within_sd=math.sqrt(w2), excess_sd=math.sqrt(max(s**2 - w2, 0)),
                         excess_sd_high=math.sqrt(max(hi**2 - w2, 0))))
D3 = pd.DataFrame(desc)

# ---------------- 4. repeatability / reproducibility limits and tissue discrimination (KK-consistent spectra)
# between-placement component for R_inf from the bipolar blood recordings transferred with the within-recording slope (KK);
# for Q and alpha from the KK-consistent replicate pair (upper 95% bound), stated as such
sb_R100 = S1.loc[0, 'between_sd']; sb_R100_hi = S1.loc[0, 'ci_high']; sw_R100 = within_sw[0]
exc_R100 = math.sqrt(max(sb_R100**2 - sw_R100**2, 0)); exc_R100_hi = math.sqrt(max(sb_R100_hi**2 - sw_R100**2, 0))
lim = []
for q in ['log10_Q', 'alpha', 'log10_Rinf']:
    s_fit = DR.loc[(True, q), 'median_fit_se']; s_dr = DR.loc[(True, q), 'tau_drift']; s_w = math.hypot(s_fit, s_dr)
    if q == 'log10_Rinf':
        k = abs(tr['kk']['slope']); s_b, s_b_hi, src = k*exc_R100, k*exc_R100_hi, 'bipolar blood recordings via R(100 kHz)'
    else:
        row = D3[(D3.param == q) & (D3.set == 'KK-consistent')]
        s_b, s_b_hi, src = (float(row.excess_sd.iloc[0]), float(row.excess_sd_high.iloc[0]), 'KK-consistent replicate pair') if len(row) else (np.nan, np.nan, 'none')
    lim.append(dict(param=q, s_fit=s_fit, s_drift=s_dr, s_within=s_w, r_limit=2.77*s_w, s_between=s_b, s_between_high=s_b_hi,
                    R_limit=2.77*math.hypot(s_w, s_b), R_limit_high=2.77*math.hypot(s_w, s_b_hi), source=src))
L = pd.DataFrame(lim).set_index('param')
K = I[I.kk_ok]; tis = K.groupby(['tissue', 'param']).estimate.mean().unstack()
disc = []
for q in ['log10_Q', 'alpha', 'log10_Rinf']:
    v = tis[q].dropna(); pairs = list(itertools.combinations(v.index, 2)); dif = np.array([abs(v[a] - v[b]) for a, b in pairs])
    disc.append(dict(param=q, tissues=len(v), pairs=len(pairs), median_abs_diff=float(np.median(dif)), pct_gt_r=100*np.mean(dif > L.loc[q, 'r_limit']),
                     pct_gt_R=100*np.mean(dif > L.loc[q, 'R_limit']), pct_gt_R_high=100*np.mean(dif > L.loc[q, 'R_limit_high'])))
DI = pd.DataFrame(disc)

# ---------------- 5. per-animal summary of the main results
an = lambda sf: 1 if '_2023' in sf else 2
E10 = pd.read_csv(T/'Table_E10_measured.csv'); E10['animal'] = E10.source_file.map(an)
VPs = pd.read_csv(T/'Table_VP_M12_success_by_spectrum.csv', index_col=0); VPs['animal'] = [1 if i.split('_')[-1].startswith('2023') else 2 for i in VPs.index]
pa = []
for a in [1, 2]:
    e = E10[E10.animal == a]; v = VPs[VPs.animal == a]; ii = I[I.animal == a]
    cl = ii[ii.kk_ok].groupby('param').closed.mean()
    pa.append(dict(animal=a, spectra=len(e), kk_consistent=int(e.kk_ok.sum()),
                   M12_success_MS_TRF=100*v['MS-TRF'].mean(), M12_success_VP_MS_TRF=100*v['VP-MS-TRF'].mean(),
                   VP_gain_pp=100*(v['VP-MS-TRF'] - v['MS-TRF']).mean(), VP_gain_positive=f"{int(((v['VP-MS-TRF'] - v['MS-TRF']) > 0).sum())}/{int(((v['VP-MS-TRF'] - v['MS-TRF']) != 0).sum())}",
                   tau_identifiable=f'{int(e.ident_obs.sum())}/{len(e)}', criterion_agreement=f'{int((e.ident_obs == e.ident_pred).sum())}/{len(e)}',
                   Gamma_median=float(e.Gamma.median()), fc_detect_median_hz=float(e.fc_detect_hz.median()), fc_detect_cal_median_hz=float(e.fc_detect_cal_hz.median()),
                   kk_closed_Q=float(cl.get('log10_Q', np.nan)), kk_closed_alpha=float(cl.get('alpha', np.nan)), kk_closed_Rinf=float(cl.get('log10_Rinf', np.nan)),
                   median_halfwidth_Q=float(ii[(ii.param == 'log10_Q') & ii.kk_ok].width.median()/2), median_halfwidth_alpha=float(ii[(ii.param == 'alpha') & ii.kk_ok].width.median()/2)))
PA = pd.DataFrame(pa)
# animal 1 vs 2 for tissues measured in both (KK-consistent): artery
both = []
for t, g in I[I.kk_ok].groupby('tissue'):
    if g.animal.nunique() < 2: continue
    for q, h in g.groupby('param'):
        a1 = h[h.animal == 1]; a2 = h[h.animal == 2]
        d = a2.estimate.mean() - a1.estimate.mean(); se = math.sqrt((a1.se**2).mean()/len(a1) + (a2.se**2).mean()/len(a2))
        both.append(dict(tissue=t, param=q, n1=len(a1), n2=len(a2), diff_2_minus_1=d, fit_se=se, R_limit=L.loc[q, 'R_limit'], R_limit_high=L.loc[q, 'R_limit_high']))
BO = pd.DataFrame(both)

# ---------------- 6. does the placement effect act as a scale factor?  Z -> k Z shifts log R_inf by +log k, log Q by -log k,
# leaves alpha and the phase unchanged; log10(R_inf Q) is invariant.
W = I.pivot_table(index=['source_file', 'tissue', 'animal', 'kk_ok'], columns='param', values='estimate').reset_index()
W['log10_RinfQ'] = W.log10_Rinf + W.log10_Q
sc = []
for lab, sel in [('all replicate groups', W.kk_ok | ~W.kk_ok), ('KK-consistent replicate groups', W.kk_ok)]:
    ww = W[sel]; grp = [g for _, g in ww.groupby(['animal', 'tissue']) if len(g) > 1]
    if not grp: continue
    out = dict(set=lab, groups='; '.join(f'{g.tissue.iloc[0]} x{len(g)}' for g in grp))
    for q in ['log10_Rinf', 'log10_Q', 'log10_RinfQ', 'alpha']: out['sd_' + q] = pooled([g[q].to_numpy() for g in grp])[0]
    dq = np.concatenate([g.log10_Q - g.log10_Q.mean() for g in grp]); dr = np.concatenate([g.log10_Rinf - g.log10_Rinf.mean() for g in grp])
    out['slope_dlogQ_on_dlogRinf'] = float((dq*dr).sum()/(dr*dr).sum()); sc.append(out)
e = E[E.kk_ok]; dq = e.log10_Q - e.groupby('source_file').log10_Q.transform('mean'); dr = e.log10_Rinf - e.groupby('source_file').log10_Rinf.transform('mean')
sc.append(dict(set='within recording, between sweeps (KK-consistent)', groups=f'{e.source_file.nunique()} recordings', slope_dlogQ_on_dlogRinf=float((dq*dr).sum()/(dr*dr).sum()),
               sd_log10_Rinf=float(dr.std()), sd_log10_Q=float(dq.std()), sd_log10_RinfQ=float((dq + dr).std()), sd_alpha=float((e.alpha - e.groupby('source_file').alpha.transform('mean')).std())))
SC = pd.DataFrame(sc)
for name, df in [('Table_E12_scale', SC), ('Table_E12_groups', G), ('Table_E12_summary', S1), ('Table_E12_probe', PE), ('Table_E12_descriptor_between', D3),
                 ('Table_E12_limits', L.reset_index()), ('Table_E12_discrimination', DI), ('Table_E12_per_animal', PA), ('Table_E12_between_animal', BO)]:
    df.to_csv(T/f'{name}.csv', index=False)
json.dump(tr, open(T/'E12_transfer.json', 'w'), indent=1)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
for name, df in [('scale', SC), ('groups', G), ('summary', S1), ('probe', PE), ('descriptor', D3), ('limits', L), ('discrimination', DI), ('per animal', PA), ('between animal', BO)]:
    print('\n==', name); print(df.round(4).to_string())
print('\ntransfer', json.dumps(tr, indent=1))
