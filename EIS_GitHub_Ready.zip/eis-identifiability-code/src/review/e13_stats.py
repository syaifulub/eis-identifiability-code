"""E13: statistical robustness without new data.
A. Cluster-aware inference. Spectra are nested in tissue-within-animal clusters (14 clusters; muscle x5, liver x2 and
   vein x2 share a cluster). For the main benchmark contrasts (per-spectrum success difference at 2,000 NFE over 25 runs),
   95% intervals from (i) resampling spectra, (ii) resampling clusters, (iii) two-stage resampling (clusters, then spectra
   within clusters) and (iv) clusters defined by tissue only (12); p-values from the exact sign-flip permutation test
   of cluster-mean differences; and a run-level linear-probability model with cluster-robust (CR1) standard errors.
   Coverage of calibrated intervals and the Spearman correlation of the detection limit with the upper f_c bound are
   given cluster-bootstrap intervals in the same way.
B. Endpoint hierarchy: four confirmatory hypotheses with Holm control
   H1 VP-MS-TRF > MS-TRF on M12 (superiority; one-sided permutation p)
   H2 ASHO-LSHADE vs L-SHADE on M12 within +-5 pp (equivalence; TOST with cluster bootstrap, p = max of the two one-sided)
   H3 ASHO-LSHADE+TRF vs L-SHADE+TRF on M12 within +-5 pp (equivalence)
   H4 calibrated > nominal coverage (empirical Sigma, pooled over Q, alpha, R_inf; sign-flip over clusters)
   All other analyses are estimation with intervals.
C. Robustness of the between-recording SDs (E12): leave-one-group-out, a MAD-based pooled SD, and exclusion of the
   largest group contribution.
D. Precision and sample size for a replicate study, from the estimated variance components.
Usage: python e13_stats.py"""
import itertools, json, math, numpy as np, pandas as pd
from scipy.stats import chi2, spearmanr, norm
import r2_core as R
T = R.T; rng = np.random.default_rng(13); B = 4000
def animal(sf): return 'A1' if '_2023' in sf else 'A2'
def clusters(df, how):
    return (df.tissue + '|' + df.source_file.map(animal)) if how == 'tissue_animal' else df.tissue

def boot_ci(per_spec, how, stat=np.mean, two_stage=False):
    """per_spec: DataFrame with columns value, cluster. Returns 95% percentile interval."""
    if how == 'spectrum':
        v = per_spec.value.to_numpy(); bs = [stat(rng.choice(v, len(v))) for _ in range(B)]
    else:
        g = {c: x.value.to_numpy() for c, x in per_spec.groupby('cluster')}; keys = list(g)
        bs = []
        for _ in range(B):
            pick = rng.choice(keys, len(keys)); vals = []
            for k in pick:
                x = g[k]; vals.append(rng.choice(x, len(x)) if two_stage else x)
            bs.append(stat(np.concatenate(vals)))
    return np.quantile(bs, [.025, .975])

def signflip(per_spec, alternative='greater'):
    m = per_spec.groupby('cluster').value.mean().to_numpy(); obs = m.mean(); n = len(m)
    if n <= 16:
        signs = np.array(list(itertools.product([-1, 1], repeat=n)))
    else:
        signs = rng.choice([-1, 1], size=(200000, n))
    null = (signs*m).mean(1)
    if alternative == 'greater': return float(np.mean(null >= obs - 1e-12))
    return float(np.mean(np.abs(null) >= abs(obs) - 1e-12))

def cr1(runs, xcol, ycol, ccol):
    """Linear probability model y ~ 1 + x, cluster-robust CR1 SE for the x coefficient."""
    X = np.column_stack([np.ones(len(runs)), runs[xcol].to_numpy(float)]); y = runs[ycol].to_numpy(float)
    XtXi = np.linalg.inv(X.T @ X); b = XtXi @ X.T @ y; e = y - X @ b; G = runs[ccol].to_numpy()
    meat = np.zeros((2, 2)); cl = np.unique(G)
    for c in cl:
        idx = G == c; u = X[idx].T @ e[idx]; meat += np.outer(u, u)
    n, k, g = len(y), 2, len(cl); V = XtXi @ meat @ XtXi*(g/(g - 1))*((n - 1)/(n - k))
    return float(b[1]), float(math.sqrt(V[1, 1])), g

# ---------------- A1/B: benchmark contrasts
CONTR = [('M12_DoubleColeL', 'VP-MS-TRF', 'MS-TRF', 'sup'), ('M12_DoubleColeL', 'VP-L-SHADE+TRF', 'L-SHADE+TRF', 'sup'),
         ('M10_ColeL', 'VP-L-SHADE', 'L-SHADE', 'sup'), ('M12_DoubleColeL', 'VP-L-SHADE', 'L-SHADE', 'sup'),
         ('M12_DoubleColeL', 'ASHO-LSHADE', 'L-SHADE', 'eq'), ('M12_DoubleColeL', 'ASHO-LSHADE+TRF', 'L-SHADE+TRF', 'eq'),
         ('M11_RCPEL', 'ASHO-LSHADE', 'L-SHADE', 'eq'), ('M10_ColeL', 'ASHO-LSHADE', 'L-SHADE', 'eq')]
rows = []; P = {}
for m, a, b, kind in CONTR:
    d = pd.read_csv(T/f'vp_merged_{m}.csv'); d = d[d.algorithm.isin([a, b])].copy(); d['y'] = d.succ_2000.astype(float)
    s = d.pivot_table(index=['source_file', 'tissue'], columns='algorithm', values='y', aggfunc='mean').reset_index()
    s['value'] = 100*(s[a] - s[b])
    out = dict(model=m.split('_')[0], contrast=f'{a} - {b}', kind=kind, spectra=len(s), estimate_pp=s.value.mean())
    for how, lab, two in [('spectrum', 'ci_spectrum', False), ('tissue_animal', 'ci_cluster', False), ('tissue_animal', 'ci_two_stage', True), ('tissue', 'ci_tissue', False)]:
        ps = s.assign(cluster=clusters(s, how)) if how != 'spectrum' else s
        lo, hi = boot_ci(ps, how, two_stage=two); out[lab] = f'{lo:.1f} to {hi:.1f}'; out[lab + '_lo'] = lo; out[lab + '_hi'] = hi
    ps = s.assign(cluster=clusters(s, 'tissue_animal')); out['clusters'] = ps.cluster.nunique()
    if kind == 'sup':
        out['p_signflip'] = signflip(ps, 'greater')
    else:   # TOST at +-5 pp using the two-stage cluster bootstrap distribution
        g = {c: x.value.to_numpy() for c, x in ps.groupby('cluster')}; keys = list(g); bs = []
        for _ in range(B):
            pick = rng.choice(keys, len(keys)); bs.append(np.concatenate([rng.choice(g[k], len(g[k])) for k in pick]).mean())
        bs = np.array(bs); p_lo = float(np.mean(bs <= -5)); p_hi = float(np.mean(bs >= 5)); out['p_TOST'] = max(p_lo, p_hi)
        out['ci90_two_stage'] = f'{np.quantile(bs, .05):.1f} to {np.quantile(bs, .95):.1f}'
    d['cluster'] = d.tissue + '|' + d.source_file.map(animal); d['x'] = (d.algorithm == a).astype(float)
    bcoef, se, g = cr1(d, 'x', 'y', 'cluster'); out['lpm_pp'] = 100*bcoef; out['lpm_ci'] = f'{100*(bcoef - 1.96*se):.1f} to {100*(bcoef + 1.96*se):.1f}'
    rows.append(out)
A1 = pd.DataFrame(rows)

# ---------------- A2: coverage with cluster bootstrap (12 KK-consistent spectra)
cov_rows = []; cov_spec = {}
for m in ['M11']:
    d = pd.read_csv(T/f'e1_coverage_runs_{m}.csv'); kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct
    tis = pd.read_csv(T/'Table_subset_mapping.csv').set_index('source_file').tissue
    d['nom'] = d.lr_nom <= 3.84; d['cal'] = d.lr_nom <= d.c_nom
    for cond in ['emp', 'rho_hi', 'ar1']:
        for q in ['log10_Q', 'alpha', 'log10_Rinf']:
            x = d[(d.cond == cond) & (d.param == q)]
            s = x.groupby('source_file')[['nom', 'cal']].mean().reset_index(); s['tissue'] = s.source_file.map(tis)
            r = dict(condition=cond, param=q, spectra=len(s), nominal=100*s.nom.mean(), calibrated=100*s.cal.mean())
            for lab, col in [('nominal', 'nom'), ('calibrated', 'cal')]:
                ps = s.assign(value=100*s[col], cluster=clusters(s, 'tissue_animal'))
                lo, hi = boot_ci(ps, 'cluster', two_stage=True); r[lab + '_ci_two_stage'] = f'{lo:.1f} to {hi:.1f}'
            cov_rows.append(r)
            if cond == 'emp': cov_spec[q] = s
A2 = pd.DataFrame(cov_rows)
# H4: calibrated minus nominal coverage, averaged over the three descriptors per spectrum, sign-flip over clusters
cs = pd.concat([v.assign(param=k) for k, v in cov_spec.items()]).groupby(['source_file', 'tissue'])[['nom', 'cal']].mean().reset_index()
cs['value'] = 100*(cs.cal - cs.nom); cs['cluster'] = clusters(cs, 'tissue_animal')
p_H4 = signflip(cs, 'greater'); H4_est = cs.value.mean(); H4_ci = boot_ci(cs, 'cluster', two_stage=True)

# ---------------- A3: Spearman detection limit vs f_c upper bound; measured Gamma
E = pd.read_csv(T/'Table_E10_measured.csv'); E['cluster'] = clusters(E, 'tissue_animal')
def sp(df): return spearmanr(df.fc_detect_hz, df.fc_ci_high_hz).statistic
g = {c: x for c, x in E.groupby('cluster')}; keys = list(g); bs_s, bs_g = [], []
for _ in range(B):
    pick = rng.choice(keys, len(keys)); df = pd.concat([g[k] for k in pick])
    if df.fc_detect_hz.nunique() > 2: bs_s.append(sp(df))
    bs_g.append(np.median(df.Gamma))
A3 = pd.DataFrame([dict(quantity='Spearman(detection limit, upper f_c bound)', estimate=sp(E), ci=f'{np.nanquantile(bs_s, .025):.2f} to {np.nanquantile(bs_s, .975):.2f}'),
                   dict(quantity='median Gamma (all spectra)', estimate=float(np.median(E.Gamma)), ci=f'{np.quantile(bs_g, .025):.1f} to {np.quantile(bs_g, .975):.1f}')])

# ---------------- B: Holm over the four confirmatory hypotheses
def get(c, m='M12'): return A1[(A1.contrast == c) & (A1.model == m)].iloc[0]
H = pd.DataFrame([dict(H='H1', hypothesis='VP-MS-TRF > MS-TRF, M12 success', estimate=f"{get('VP-MS-TRF - MS-TRF').estimate_pp:+.1f} pp", interval=get('VP-MS-TRF - MS-TRF').ci_two_stage, p=get('VP-MS-TRF - MS-TRF').p_signflip, test='exact sign-flip over clusters (one-sided)'),
                  dict(H='H2', hypothesis='ASHO-LSHADE equivalent to L-SHADE (+-5 pp), M12', estimate=f"{get('ASHO-LSHADE - L-SHADE').estimate_pp:+.1f} pp", interval=get('ASHO-LSHADE - L-SHADE').ci90_two_stage + ' (90%)', p=get('ASHO-LSHADE - L-SHADE').p_TOST, test='TOST, two-stage cluster bootstrap'),
                  dict(H='H3', hypothesis='ASHO-LSHADE+TRF equivalent to L-SHADE+TRF (+-5 pp), M12', estimate=f"{get('ASHO-LSHADE+TRF - L-SHADE+TRF').estimate_pp:+.1f} pp", interval=get('ASHO-LSHADE+TRF - L-SHADE+TRF').ci90_two_stage + ' (90%)', p=get('ASHO-LSHADE+TRF - L-SHADE+TRF').p_TOST, test='TOST, two-stage cluster bootstrap'),
                  dict(H='H4', hypothesis='calibrated > nominal coverage (empirical Sigma)', estimate=f'{H4_est:+.1f} pp', interval=f'{H4_ci[0]:.1f} to {H4_ci[1]:.1f}', p=p_H4, test='exact sign-flip over clusters (one-sided)')])
o = np.argsort(H.p.to_numpy()); adj = np.empty(4); run = 0
for rank, i in enumerate(o): run = max(run, min(1, (4 - rank)*H.p.iloc[i])); adj[i] = run
H['p_holm'] = adj; H['rejected_at_0.05'] = H.p_holm < 0.05

# ---------------- C: robustness of the between-recording SDs
M = pd.read_csv(T/'e12_recordings.csv')
def groups_of(sel):
    out = {}
    for k, g in M[sel].groupby(['animal', 'probe', 'medium_g', 'f_khz']):
        if len(g) > 1: out[k] = g.logR.to_numpy()
    return out
def pooled(gs):
    nu = sum(len(x) - 1 for x in gs); return math.sqrt(sum((len(x) - 1)*np.var(x, ddof=1) for x in gs)/nu), nu
def mad_pooled(gs):   # pooled scaled MAD about group medians, with a small-sample consistency factor per group size
    dev = np.concatenate([np.abs(x - np.median(x)) for x in gs]); n = np.concatenate([[len(x)]*len(x) for x in gs])
    k = np.where(n == 2, 1/0.6745*1.0, 1.4826)   # for pairs |x - median| = |diff|/2; scaled so E = sigma approx
    return float(np.median(dev*k*np.sqrt(n/(n - 1))))
sw = pd.read_csv(T/'Table_E12_summary.csv'); s_within = float(sw[sw.set.str.contains('KK-consistent')].between_sd.iloc[0])
crow = []
for lab, sel in [('blood, bipolar', (M.medium == 'blood') & (M.probe != 'monopolar')), ('tissue, scan probe', (M.medium != 'blood') & (M.probe == 'yellow')),
                 ('all same-probe groups', M.medium.notna())]:
    G = groups_of(sel); s, nu = pooled(list(G.values())); loo = []
    for k in G:
        rest = [v for kk, v in G.items() if kk != k]
        if sum(len(v) - 1 for v in rest) > 0: loo.append((k, pooled(rest)[0]))
    smin = min(loo, key=lambda t: t[1]); smax = max(loo, key=lambda t: t[1])
    crow.append(dict(set=lab, groups=len(G), df=nu, pooled_sd=s, ratio_to_within=s/s_within, loo_min=smin[1], loo_min_dropped='/'.join(map(str, smin[0])),
                     loo_max=smax[1], loo_ratio_range=f'{smin[1]/s_within:.1f} to {smax[1]/s_within:.1f}', mad_pooled=mad_pooled(list(G.values())),
                     mad_ratio=mad_pooled(list(G.values()))/s_within))
C = pd.DataFrame(crow)

# ---------------- D: precision and sample size for a replicate study
L = pd.read_csv(T/'Table_E12_limits.csv').set_index('param'); DI = pd.read_csv(T/'Table_E12_discrimination.csv').set_index('param')
I = pd.read_csv(T/'e1_intervals_M11.csv'); I = I[(I.objective == 'nom') & (I.threshold == 'cal') & I.kk_ok]
tm = I.groupby(['tissue', 'param']).estimate.mean().unstack()
drow = []
for nu in [1, 2, 5, 10, 20, 30, 50, 100]:
    drow.append(dict(df=nu, sd_ci_low_factor=math.sqrt(nu/chi2.ppf(.975, nu)), sd_ci_high_factor=math.sqrt(nu/chi2.ppf(.025, nu))))
D1 = pd.DataFrame(drow)
need = next(r.df for r in D1.itertuples() if r.sd_ci_high_factor <= 1.5)
drow2 = []; sw_R, sb_R = L.loc['log10_Rinf', 's_within'], L.loc['log10_Rinf', 's_between']
dif = np.array([abs(tm.log10_Rinf[a] - tm.log10_Rinf[b]) for a, b in itertools.combinations(tm.log10_Rinf.dropna().index, 2)])
for n in [1, 2, 3, 4, 6, 8]:
    lim = 2.77*math.sqrt((sw_R**2 + sb_R**2)/n)
    drow2.append(dict(placements_per_tissue=n, R_limit_mean=lim, pct_pairs_exceeding=100*np.mean(dif > lim)))
D2 = pd.DataFrame(drow2)

for name, df in [('Table_E13_contrasts', A1), ('Table_E13_coverage', A2), ('Table_E13_corr', A3), ('Table_E13_hypotheses', H), ('Table_E13_robust_between', C),
                 ('Table_E13_precision_df', D1), ('Table_E13_placements', D2)]:
    df.to_csv(T/f'{name}.csv', index=False)
json.dump(dict(df_for_upper_factor_1p5=int(need), H4_estimate=H4_est, H4_ci=list(H4_ci), s_within_R100=s_within), open(T/'E13_misc.json', 'w'), indent=1)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
for name, df in [('contrasts', A1.drop(columns=[c for c in A1.columns if c.endswith('_lo') or c.endswith('_hi')])), ('coverage', A2), ('corr', A3), ('hypotheses', H),
                 ('robust between', C), ('precision', D1), ('placements', D2)]:
    print('\n==', name); print(df.round(4).to_string())
print('df needed for upper CI factor <= 1.5:', need)
