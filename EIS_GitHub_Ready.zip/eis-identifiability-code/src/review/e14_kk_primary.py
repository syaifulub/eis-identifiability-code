"""E14: reviewer round 3.
(a) Physical/model-selection analyses with the 12 KK-consistent spectra as the primary set and all 20 as robustness:
    11-model screening (AICc/BIC wins, ranks), M10 vs M11 (AICc nominal/GLS on three bands, bootstrap LR, leave-one-
    frequency-out), high-frequency-correction sensitivity, M11 descriptors, sign of the fitted delay.
(b) Error model estimated from the sweeps of KK-consistent recordings only (residual-based, as in E1) and its effect on
    calibration: critical values c* recomputed under Sigma_KK and coverage under Sigma_KK of intervals calibrated with
    Sigma_KK and with the published Sigma (all 51 sweeps), 12 KK-consistent spectra x 100 replicates.
(c) Diagnosis of the closed-form width in the weak-identifiability regime (Table S30): share of closed profiles by r.
Usage: python e14_kk_primary.py RAW_DIR"""
import sys, json, math, time, numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.stats import wilcoxon
import r2_core as R
T = R.T; raw = sys.argv[1]
kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct < 3
# ---------------- (a) model selection and physical summaries
E = pd.read_csv(T/'ecm_all_models.csv'); E['kk'] = E.source_file.map(kk)
scr = []
for lab, d in [('KK-consistent (12)', E[E.kk]), ('all (20)', E)]:
    d = d.copy(); d['rA'] = d.groupby('source_file').AICc.rank(); d['rB'] = d.groupby('source_file').BIC.rank()
    for m, g in d.groupby('model'):
        scr.append(dict(set=lab, model=m, k=int(g.k.iloc[0]), median_NRMSE=g.NRMSE.median(), mean_AICc_rank=g.rA.mean(), AICc_wins=int((g.rA == 1).sum()),
                        BIC_wins=int((g.rB == 1).sum())))
SCR = pd.DataFrame(scr).sort_values(['set', 'mean_AICc_rank'])
M = pd.read_csv(T/'e3_model_selection_runs.csv')
ms = []
for lab, d in [('KK-consistent (12)', M[M.kk_ok]), ('all (20)', M)]:
    r = dict(set=lab, spectra=len(d))
    for obj in ['nom', 'gls']:
        for band in ['10-100', '10-80', '20-100']: r[f'M11_pref_AICc_{obj}_{band}'] = int((d[f'dAICc_{obj}_{band}'] > 0).sum())
        r[f'bootLR_reject_{obj}'] = int((d[f'p_boot_{obj}'] < 0.05).sum()); r[f'median_p_boot_{obj}'] = d[f'p_boot_{obj}'].median()
    for part in ['int', 'end']:
        a, b = d[f'lofo_{part}_M10'], d[f'lofo_{part}_M11']; r[f'lofo_{part}_M11_better'] = int((b < a).sum()); r[f'lofo_{part}_p'] = wilcoxon(b, a).pvalue
    r['median_dAICc_nom'] = d['dAICc_nom_10-100'].median(); r['median_dAICc_gls'] = d['dAICc_gls_10-100'].median()
    ms.append(r)
MS = pd.DataFrame(ms)
H = pd.read_csv(T/'e2_hf_runs.csv'); hf = []
for lab, d in [('KK-consistent (12)', H[H.kk_ok]), ('all (20)', H)]:
    for t, g in d.groupby('treatment'):
        hf.append(dict(set=lab, treatment=t, model=g.model.iloc[0], NRMSE=g.NRMSE.median(), abs_d_log10_Rinf=g.d_log10_Rinf.abs().median(),
                       abs_d_log10_Q=g.d_log10_Q.abs().median(), abs_d_alpha=g.d_alpha.abs().median(), extra_median=g.extra.median(),
                       extra_q25=g.extra.quantile(.25), extra_q75=g.extra.quantile(.75)))
HF = pd.DataFrame(hf)
P = pd.read_csv(T/'Table_M11_physical_parameters.csv'); P['kk'] = P.source_file.map(kk); de = []
for lab, d in [('KK-consistent (12)', P[P.kk]), ('all (20)', P)]:
    de.append(dict(set=lab, Rinf_ohm=d.Rinf_ohm.median(), Q=d.Q.median(), alpha=d.alpha.median(), L_mH=1e3*d.L_H.median(), NRMSE=d.NRMSE.median(),
                   Rinf_range=f'{d.Rinf_ohm.min():.0f}-{d.Rinf_ohm.max():.0f}', alpha_range=f'{d.alpha.min():.2f}-{d.alpha.max():.2f}'))
DE = pd.DataFrame(de)

# ---------------- (b) error model from KK-consistent recordings only
SP = {s['sf']: s for s in R.spectra()}; SW = R.sweeps(raw)
res_all, kk_of = [], []
for k, s in SP.items():
    for z in SW[k]:
        F = R.fit('rcpe_l', s['f'], z); res_all.append(R.VP('rcpe_l', s['f'], z).residual(F['eta'])); kk_of.append(s['kk_ok'])
res_all = np.array(res_all); kk_of = np.array(kk_of)
def fit_psi(S, df):
    def nll(u):
        C = R.sigma_struct([math.exp(u[0]), u[1], math.tanh(u[2]), math.tanh(u[3]), math.exp(u[4])]); sgn, ld = np.linalg.slogdet(C)
        return 0.5*df*(ld + np.trace(np.linalg.solve(C, S))) if sgn > 0 else 1e12
    best = None
    for st in [[math.log(0.01), 0, 0.0, 0, 0], [math.log(0.02), 0.5, 0.8, 0.3, 0], [math.log(0.005), -0.5, -0.5, -0.3, 0.3]]:
        r = minimize(nll, st, method='Nelder-Mead', options=dict(maxiter=20000, xatol=1e-7, fatol=1e-10))
        if best is None or r.fun < best.fun: best = r
    u = best.x; return np.array([math.exp(u[0]), u[1], math.tanh(u[2]), math.tanh(u[3]), math.exp(u[4])])
def S_of(idx): Rm = res_all[idx]; return Rm.T @ Rm/len(idx)
psi_all = fit_psi(S_of(np.arange(len(res_all))), len(res_all)); psi_kk = fit_psi(S_of(np.flatnonzero(kk_of)), int(kk_of.sum()))
psi_pub = np.array(json.load(open(T/'E1_psi.json'))['psi'])
EMK = pd.DataFrame(dict(parameter=['sigma0', 'gamma', 'rho_f', 'rho_ReIm', 'ratio_Im_Re'], published_all_51=psi_pub, refit_all_51=psi_all, kk_only=psi_kk))
EMK.loc[len(EMK)] = ['sweeps', len(res_all), len(res_all), int(kk_of.sum())]
S_kk = R.sigma_struct(psi_kk); S_pub = R.sigma_struct(psi_pub)
def scaled(S, rss, p=4): return S*(rss/(np.trace(S)*(1 - p/S.shape[0])))
pars = ['log10_Q', 'alpha', 'log10_Rinf']
def lr_nom(f, z, tv):
    rmin = R.fit('rcpe_l', f, z)['rss']; return {pn: R.lr_at('rcpe_l', f, z, pn, tv[pn], None, rmin) for pn in pars}
cst = pd.read_csv(T/'e1_cstar_M11.csv'); cst = cst[cst.objective == 'nom'].set_index(['source_file', 'param']).c_star
cov = []
for si, (k, s) in enumerate(SP.items()):
    if not s['kk_ok']: continue
    t0 = time.time(); F = R.fit('rcpe_l', s['f'], s['Z']); p = F['params']; zt = R.predict('rcpe_l', p, s['f'])
    tv = {'log10_Q': math.log10(p['Q']), 'alpha': p['alpha'], 'log10_Rinf': math.log10(p['Rinf'])}
    Lc = np.linalg.cholesky(scaled(S_kk, F['rss'])); rng = np.random.default_rng(14000 + si)
    boot = [lr_nom(s['f'], R.noise_draw(rng, Lc, zt), tv) for _ in range(200)]
    c_kk = {pn: float(np.quantile([b[pn] for b in boot], .95)) for pn in pars}
    for r in range(100):
        lr = lr_nom(s['f'], R.noise_draw(rng, Lc, zt), tv)
        for pn in pars:
            cov.append(dict(source_file=k, tissue=s['tissue'], rep=r, param=pn, lr=lr[pn], c_kk=c_kk[pn], c_pub=cst[(k, pn)]))
    print(time.strftime('%H:%M:%S'), si, s['tissue'], f'{time.time() - t0:.0f}s', flush=True)
CV = pd.DataFrame(cov); CV.to_csv(T/'e14_coverage_kkSigma.csv', index=False)
COV = CV.groupby('param').apply(lambda g: pd.Series(dict(nominal=100*(g.lr <= 3.84).mean(), calibrated_with_Sigma_KK=100*(g.lr <= g.c_kk).mean(),
        calibrated_with_published_Sigma=100*(g.lr <= g.c_pub).mean(), median_c_kk=g.groupby('source_file').c_kk.first().median(),
        median_c_pub=g.groupby('source_file').c_pub.first().median())), include_groups=False).reset_index()

# ---------------- (c) weak-identifiability diagnosis
B = pd.read_csv(T/'e10b_refined.csv'); B['rbin'] = pd.cut(B.rmax, [0, .1, .3, .6, 1, 100], labels=['<0.1', '0.1-0.3', '0.3-0.6', '0.6-1', '>1'])
WK = B.groupby('rbin', observed=True).apply(lambda h: pd.Series(dict(spectra=len(h), pct_closed=100*h.closed.mean(),
        median_W_asym_all=h.W_asym.median(), median_W_wald_all=h.W_wald.median(), pct_pred_nonident=100*(h.W_asym >= 1).mean(),
        pct_obs_nonident=100*(~h.ident_obs.astype(bool)).mean(), agreement=100*((h.W_asym < 1) == h.ident_obs.astype(bool)).mean())), include_groups=False).reset_index()

for name, df in [('Table_E14_screening', SCR), ('Table_E14_model_selection', MS), ('Table_E14_hf', HF), ('Table_E14_descriptors', DE),
                 ('Table_E14_error_model_kk', EMK), ('Table_E14_coverage_kk', COV), ('Table_E14_weak_ident', WK)]:
    df.to_csv(T/f'{name}.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40)
for name, df in [('screening', SCR[SCR.mean_AICc_rank < 6]), ('model selection', MS.T), ('hf', HF), ('descriptors', DE), ('error model', EMK), ('coverage', COV), ('weak', WK)]:
    print('\n==', name); print(df.round(4).to_string())
