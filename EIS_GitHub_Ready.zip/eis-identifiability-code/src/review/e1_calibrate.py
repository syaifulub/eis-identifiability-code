"""E1 steps 3-4: bootstrap-calibrated and GLS profile-likelihood intervals, measured intervals and coverage validation.
Usage: python e1_calibrate.py M11|M10|DB   (M11: calibration + validation of log10 Q, alpha, log10 Rinf;
       M10: calibration + measured intervals for log10 tau, log10 dR and tau coverage; DB: reduced double bootstrap, M11)
Noise models are all scaled per spectrum so that the expected RSS equals the observed RSS of the published fit."""
import sys, json, math, time, pickle, numpy as np, pandas as pd
import r2_core as R
MODE = sys.argv[1]; T = R.T; CACHE = T.parent/'cache_e1'; CACHE.mkdir(exist_ok=True)
psi = np.array(json.load(open(T/'E1_psi.json'))['psi']); S_emp = R.sigma_struct(psi); W_gls = R.whitener(S_emp)
SP = R.spectra(); THR = 3.84; B = 200; RV = 100

def scaled(S, rss, p):          # scale covariance so that E[RSS] = observed RSS (relative residual space)
    return S*(rss/(np.trace(S)*(1 - p/S.shape[0])))
def cond_cov(name):
    if name in ('emp', 'mis'): return S_emp
    if name == 'rho_lo': q = psi.copy(); q[2] = max(q[2]-0.2, -0.95); return R.sigma_struct(q)
    if name == 'rho_hi': q = psi.copy(); q[2] = min(q[2]+0.2, 0.95); return R.sigma_struct(q)
    if name == 'white': return np.eye(20)
    if name == 'ar1': return R.sigma_struct([1.0, 0.0, 0.6, 0.0, 1.0])

def lr_pair(model, f, z, params_truth, pars):
    """LR at the true values under the independent (nominal) and GLS objectives."""
    out = {}
    for tag, W in (('nom', None), ('gls', W_gls)):
        rmin = R.fit(model, f, z, W)['rss']
        for pn in pars: out[(tag, pn)] = R.lr_at(model, f, z, pn, params_truth[pn], W, rmin)
    return out

def truths(model, F):
    p = F['params']
    if model == 'rcpe_l': return {'log10_Q': math.log10(p['Q']), 'alpha': p['alpha'], 'log10_Rinf': math.log10(p['Rinf'])}
    return {'log10_tau': p['log10_tau'], 'log10_dR': math.log10(p['dR'])}

def calibrate(model, s, pars, zt, tv, rss, seed, nb=B, Sshape=None):
    Sc = scaled(S_emp if Sshape is None else Sshape, rss, 4 if model == 'rcpe_l' else 5); Lc = np.linalg.cholesky(Sc); rng = np.random.default_rng(seed); L = []
    for b in range(nb): L.append(lr_pair(model, s['f'], R.noise_draw(rng, Lc, zt), tv, pars))
    return {k: float(np.quantile([d[k] for d in L], 0.95)) for k in L[0]}, L

if MODE == 'M11':
    pars = ['log10_Q', 'alpha', 'log10_Rinf']; cal_rows, cov_rows, int_rows = [], [], []
    for si, s in enumerate(SP):
        cp = CACHE/f'm11_{si}.pkl'
        if cp.exists(): a, b_, c = pickle.load(open(cp, 'rb')); cal_rows += a; cov_rows += b_; int_rows += c; continue
        t0 = time.time(); F = R.fit('rcpe_l', s['f'], s['Z']); tv = truths('rcpe_l', F); zt = R.predict('rcpe_l', F['params'], s['f'])
        cstar, _ = calibrate('rcpe_l', s, pars, zt, tv, F['rss'], 1000+si)
        a = [dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], model='M11', objective=k[0], param=k[1], c_star=v) for k, v in cstar.items()]
        # measured intervals: nominal and GLS profile curves with chi2 and calibrated thresholds
        c = []
        for tag, W in (('nom', None), ('gls', W_gls)):
            for pn in pars:
                g, lr, est = R.profile_curve('rcpe_l', s['f'], s['Z'], pn, W)
                for thr_name, thr in (('chi2', THR), ('cal', cstar[(tag, pn)])):
                    lo, hi, wd, cl = R.ci_from_curve(g, lr, thr)
                    c.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], model='M11', objective=tag, param=pn, threshold=thr_name,
                                  thr=thr, estimate=est, ci_low=lo, ci_high=hi, width=wd, closed=cl))
        b_ = []
        if s['kk_ok']:   # coverage validation on independent draws
            rng = np.random.default_rng(5000+si)
            for cond in ['emp', 'rho_lo', 'rho_hi', 'white', 'ar1', 'mis']:
                Lc = np.linalg.cholesky(scaled(cond_cov(cond), F['rss'], 4)); p = F['params']
                for r in range(RV):
                    if cond == 'mis':
                        w = 2*np.pi*s['f']; fc = 10**rng.uniform(np.log10(200), np.log10(3000)); tau = 1/(2*np.pi*fc); a10 = min(max(p['alpha'], 0.5), 0.95)
                        dR = tau**a10/p['Q']; z0 = p['Rinf'] + dR/(1 + (1j*w*tau)**a10) + 1j*w*p['L']
                        tvv = {'log10_Q': math.log10(p['Q']), 'alpha': a10, 'log10_Rinf': math.log10(p['Rinf'])}
                    else: z0, tvv = zt, tv
                    lr = lr_pair('rcpe_l', s['f'], R.noise_draw(rng, Lc, z0), tvv, pars)
                    for pn in pars:
                        b_.append(dict(source_file=s['sf'], cond=cond, rep=r, param=pn, lr_nom=lr[('nom', pn)], lr_gls=lr[('gls', pn)],
                                       c_nom=cstar[('nom', pn)], c_gls=cstar[('gls', pn)]))
        pickle.dump((a, b_, c), open(cp, 'wb')); cal_rows += a; cov_rows += b_; int_rows += c
        print(time.strftime('%H:%M:%S'), 'M11', si, s['tissue'], f'{time.time()-t0:.0f}s', flush=True)
    pd.DataFrame(cal_rows).to_csv(T/'e1_cstar_M11.csv', index=False); pd.DataFrame(int_rows).to_csv(T/'e1_intervals_M11.csv', index=False)
    CV = pd.DataFrame(cov_rows); CV.to_csv(T/'e1_coverage_runs_M11.csv', index=False)

if MODE == 'M10':
    pars = ['log10_tau', 'log10_dR']; cal_rows, int_rows, cov_rows = [], [], []
    for si, s in enumerate(SP):
        cp = CACHE/f'm10_{si}.pkl'
        if cp.exists(): a, c, b_ = pickle.load(open(cp, 'rb')); cal_rows += a; int_rows += c; cov_rows += b_; continue
        t0 = time.time(); F = R.fit('cole_l', s['f'], s['Z']); tv = truths('cole_l', F); zt = R.predict('cole_l', F['params'], s['f'])
        cstar, _ = calibrate('cole_l', s, pars, zt, tv, F['rss'], 2000+si, nb=100)
        a = [dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], model='M10', objective=k[0], param=k[1], c_star=v) for k, v in cstar.items()]
        c = []
        for tag, W in (('nom', None), ('gls', W_gls)):
            for pn in pars:
                g, lr, est = R.profile_curve('cole_l', s['f'], s['Z'], pn, W)
                for thr_name, thr in (('chi2', THR), ('cal', cstar[(tag, pn)])):
                    lo, hi, wd, cl = R.ci_from_curve(g, lr, thr)
                    c.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], model='M10', objective=tag, param=pn, threshold=thr_name,
                                  thr=thr, estimate=est, ci_low=lo, ci_high=hi, width=wd, closed=cl))
        b_ = []
        if s['kk_ok']:   # tau coverage: Cole truth with f_c below the band, calibrated at that truth, emp noise
            rng = np.random.default_rng(6000+si); p = R.fit('rcpe_l', s['f'], s['Z'])['params']; w = 2*np.pi*s['f']
            fc = 10**rng.uniform(np.log10(200), np.log10(3000)); tau = 1/(2*np.pi*fc); a10 = min(max(p['alpha'], 0.5), 0.95); dR = tau**a10/p['Q']
            z0 = p['Rinf'] + dR/(1 + (1j*w*tau)**a10) + 1j*w*p['L']; tvv = {'log10_tau': math.log10(tau), 'log10_dR': math.log10(dR)}
            cst, _ = calibrate('cole_l', s, ['log10_tau'], z0, tvv, F['rss'], 7000+si, nb=100)
            Lc = np.linalg.cholesky(scaled(S_emp, F['rss'], 5))
            for r in range(50):
                lr = lr_pair('cole_l', s['f'], R.noise_draw(rng, Lc, z0), tvv, ['log10_tau'])
                b_.append(dict(source_file=s['sf'], rep=r, param='log10_tau', lr_nom=lr[('nom', 'log10_tau')], lr_gls=lr[('gls', 'log10_tau')],
                               c_nom=cst[('nom', 'log10_tau')], c_gls=cst[('gls', 'log10_tau')]))
        pickle.dump((a, c, b_), open(cp, 'wb')); cal_rows += a; int_rows += c; cov_rows += b_
        print(time.strftime('%H:%M:%S'), 'M10', si, s['tissue'], f'{time.time()-t0:.0f}s', flush=True)
    pd.DataFrame(cal_rows).to_csv(T/'e1_cstar_M10.csv', index=False); pd.DataFrame(int_rows).to_csv(T/'e1_intervals_M10.csv', index=False)
    pd.DataFrame(cov_rows).to_csv(T/'e1_coverage_runs_M10.csv', index=False)

if MODE == 'DB':   # reduced double bootstrap: recalibrate at each replicate's own estimate (plug-in effect), emp noise, M11
    pars = ['log10_Q', 'alpha']; rows = []
    for si, s in enumerate(SP):
        if not s['kk_ok']: continue
        cp = CACHE/f'db_{si}.pkl'
        if cp.exists(): rows += pickle.load(open(cp, 'rb')); continue
        t0 = time.time(); F = R.fit('rcpe_l', s['f'], s['Z']); tv = truths('rcpe_l', F); zt = R.predict('rcpe_l', F['params'], s['f'])
        Lc = np.linalg.cholesky(scaled(S_emp, F['rss'], 4)); rng = np.random.default_rng(8000+si); out = []
        for r in range(25):
            z = R.noise_draw(rng, Lc, zt); lr = lr_pair('rcpe_l', s['f'], z, tv, pars)
            Fs = R.fit('rcpe_l', s['f'], z); cs, _ = calibrate('rcpe_l', dict(f=s['f']), pars, R.predict('rcpe_l', Fs['params'], s['f']),
                                                                 truths('rcpe_l', Fs), Fs['rss'], 9000+100*si+r, nb=80)
            for pn in pars: out.append(dict(source_file=s['sf'], rep=r, param=pn, lr_nom=lr[('nom', pn)], lr_gls=lr[('gls', pn)], c_nom=cs[('nom', pn)], c_gls=cs[('gls', pn)]))
        pickle.dump(out, open(cp, 'wb')); rows += out; print(time.strftime('%H:%M:%S'), 'DB', si, f'{time.time()-t0:.0f}s', flush=True)
    pd.DataFrame(rows).to_csv(T/'e1_coverage_runs_DB.csv', index=False)
