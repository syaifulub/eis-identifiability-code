"""E1 steps 1-2: empirical error model from the 51 complete sweeps.

(a) Sweep-to-sweep deviations within a recording (12 recordings with >= 2 sweeps) are decomposed into the part
    absorbed by refitting R-CPE-L (in-model: descriptor variability) and the part left as residual (out-of-model).
(b) The residual covariance used for calibration is estimated from per-sweep M11 residuals (all 51 sweeps, all 20
    recordings) with a 5-parameter structured model (scale, frequency trend, AR(1) frequency correlation, Re-Im
    correlation, Im/Re scale ratio). Because fitted residuals are projections, r_s = P_s e_s with P_s = I - H_s (H_s the
    hat matrix of the linearized fit), the likelihood is evaluated in the 16-dimensional residual space of each sweep:
    U_s^T r_s ~ N(0, U_s^T Sigma U_s), U_s an orthonormal basis of range(P_s) (exact for a locally linear model).
    The naive estimate that ignores the projection is reported for comparison. Ledoit-Wolf shrinkage as a check;
    bootstrap over recordings.
(c) Between-sweep variability of the M11 descriptors (log10 Rinf, log10 Q, alpha) is tabulated per recording.
Usage: python e1_error_model.py RAW_DIR"""
import sys, math, json, numpy as np, pandas as pd
from scipy.optimize import minimize
from sklearn.covariance import LedoitWolf
import r2_core as R
raw = sys.argv[1]; rng = np.random.default_rng(7)
SP = {s['sf']: s for s in R.spectra()}; SW = R.sweeps(raw); N = 10

rows, resid, rec_of = [], [], []
for k, s in SP.items():
    X = SW[k]; zbar = X.mean(0)
    for i, z in enumerate(X):
        F = R.fit('rcpe_l', s['f'], z); vp = R.VP('rcpe_l', s['f'], z); r = vp.residual(F['eta'])
        sc = np.maximum(np.abs(z), 1.0); dev = (z - zbar)/sc; dev = np.r_[dev.real, dev.imag]
        rows.append(dict(source_file=k, tissue=s['tissue'], kk_ok=s['kk_ok'], sweep=i, n_sweeps=len(X), rss=F['rss'],
                         dev_energy=float(dev @ dev) if len(X) > 1 else np.nan, log10_Rinf=math.log10(F['params']['Rinf']),
                         log10_Q=math.log10(F['params']['Q']), alpha=F['params']['alpha'], L_mH=1e3*F['params']['L']))
        resid.append(r); rec_of.append(k)
SWF = pd.DataFrame(rows); SWF.to_csv(R.T/'e1_sweep_fits.csv', index=False); resid = np.array(resid); rec_of = np.array(rec_of)

def fit_psi(S, df, starts=None):
    def nll(u):
        psi = [math.exp(u[0]), u[1], math.tanh(u[2]), math.tanh(u[3]), math.exp(u[4])]
        C = R.sigma_struct(psi); sgn, ld = np.linalg.slogdet(C)
        return 0.5*df*(ld + np.trace(np.linalg.solve(C, S))) if sgn > 0 else 1e12
    best = None
    for st in (starts or [[math.log(0.01), 0, 0.0, 0, 0], [math.log(0.02), 0.5, 0.8, 0.3, 0], [math.log(0.005), -0.5, -0.5, -0.3, 0.3]]):
        r = minimize(nll, st, method='Nelder-Mead', options=dict(maxiter=4000 if starts else 20000, xatol=1e-7, fatol=1e-10))
        if best is None or r.fun < best.fun: best = r
    u = best.x; return np.array([math.exp(u[0]), u[1], math.tanh(u[2]), math.tanh(u[3]), math.exp(u[4])])

P_LIN = 4   # fitted parameters of M11 (alpha + 3 linear)
def jac_basis(s, z, F):
    """orthonormal basis of the residual space (complement of the fitted-parameter Jacobian range)"""
    vp = R.VP('rcpe_l', s['f'], z); eta = F['eta']; c, _ = vp.coef(eta)
    A = vp._sys(eta)[0]; h = 1e-6; Ap = vp._sys(eta + h)[0]; da = (Ap - A) @ c/h
    sp = vp.sp; free = [j for j in range(3) if c[j] > sp['llo'][j]*(1+1e-9) and c[j] < sp['lhi'][j]*(1-1e-9)]
    J = np.column_stack([da] + [A[:, j] for j in free]) if 0.3+1e-9 < eta[0] < 1-1e-9 else A[:, free]
    Qf, _ = np.linalg.qr(J, mode='complete'); return Qf[:, J.shape[1]:]
Us = []
for k, s in SP.items():
    for z in SW[k]: Us.append(jac_basis(s, z, R.fit('rcpe_l', s['f'], z)))
Zs = [U.T @ r for U, r in zip(Us, resid)]
def unpack(u): return np.array([math.exp(u[0]), u[1], math.tanh(u[2]), math.tanh(u[3]), math.exp(u[4])])
def fit_proj(idx, starts=None, maxiter=20000):
    def nll(u):
        C = R.sigma_struct(unpack(u)); t = 0.0
        for i in idx:
            M = Us[i].T @ C @ Us[i]; sgn, ld = np.linalg.slogdet(M)
            if sgn <= 0: return 1e12
            t += ld + Zs[i] @ np.linalg.solve(M, Zs[i])
        return 0.5*t
    best = None
    for st in (starts or [[math.log(0.02), 0, 0.0, 0, 0], [math.log(0.05), 0.5, 0.8, 0.3, 0], [math.log(0.01), -0.5, -0.5, -0.3, 0.3]]):
        r = minimize(nll, st, method='Nelder-Mead', options=dict(maxiter=maxiter, xatol=1e-7, fatol=1e-10))
        if best is None or r.fun < best.fun: best = r
    return unpack(best.x)
def pooled(idx): Rm = resid[idx]; return Rm.T @ Rm/len(idx)     # sample covariance of residual vectors
allidx = np.arange(len(resid)); S = pooled(allidx)
psi_naive = fit_psi(S, len(resid)); psi = fit_proj(allidx)
print('psi naive', psi_naive, 'psi projected', psi, flush=True)
sd = np.sqrt(np.diag(S)); Cr = S/np.outer(sd, sd)
lw = LedoitWolf().fit(resid); Clw = lw.covariance_/np.outer(np.sqrt(np.diag(lw.covariance_)), np.sqrt(np.diag(lw.covariance_)))
recs = np.unique(rec_of); boots = []
u0 = [math.log(psi[0]), psi[1], math.atanh(psi[2]), math.atanh(psi[3]), math.log(psi[4])]
for b in range(100):
    kb = rng.choice(recs, len(recs), replace=True); idx = np.concatenate([np.flatnonzero(rec_of == k) for k in kb])
    boots.append(fit_proj(idx, starts=[u0], maxiter=2500))
    if b % 20 == 0: print('boot', b, flush=True)
boots = np.array(boots); ci = np.quantile(boots, [0.025, 0.975], axis=0)
nb = []; un = [math.log(psi_naive[0]), psi_naive[1], math.atanh(psi_naive[2]), math.atanh(psi_naive[3]), math.log(psi_naive[4])]
for b in range(200):
    kb = rng.choice(recs, len(recs), replace=True); idx = np.concatenate([np.flatnonzero(rec_of == k) for k in kb])
    nb.append(fit_psi(pooled(idx), len(idx), starts=[un]))
nci = np.quantile(np.array(nb), [0.025, 0.975], axis=0)
names = ['sigma0', 'gamma', 'rho_f', 'rho_ReIm', 'ratio_Im_Re']
EM = pd.DataFrame(dict(parameter=names, estimate=psi, ci_low=ci[0], ci_high=ci[1], naive_estimate=psi_naive, naive_ci_low=nci[0], naive_ci_high=nci[1]))
extra = dict(sweeps_used=len(resid), recordings=len(recs), residual_df=len(resid)*(2*N - P_LIN),
             sample_lag1_corr_Re=np.mean([Cr[k, k+1] for k in range(N-1)]), sample_lag1_corr_Im=np.mean([Cr[N+k, N+k+1] for k in range(N-1)]),
             sample_ReIm_corr=np.mean([Cr[k, N+k] for k in range(N)]), LW_shrinkage=lw.shrinkage_,
             LW_lag1_corr_Re=np.mean([Clw[k, k+1] for k in range(N-1)]), LW_lag1_corr_Im=np.mean([Clw[N+k, N+k+1] for k in range(N-1)]))
for k, v in extra.items(): EM.loc[len(EM)] = [k, v, np.nan, np.nan, np.nan, np.nan, np.nan]
EM.to_csv(R.T/'Table_E1_error_model.csv', index=False); np.save(R.T/'E1_psi_boot.npy', boots)
json.dump(dict(psi=list(map(float, psi_naive))), open(R.T/'E1_psi.json', 'w')); json.dump(dict(psi=list(map(float, psi))), open(R.T/'E1_psi_projected.json', 'w'))   # residual-based model is used for calibration
print(EM.round(4).to_string(), flush=True)

# (a) in-model vs out-of-model share of sweep-to-sweep deviation energy
m = SWF[SWF.n_sweeps > 1]
share = m.groupby('source_file').apply(lambda g: g.rss.mean()/g.dev_energy.mean(), include_groups=False)
# (c) between-sweep descriptor SD per recording
V = m.groupby(['source_file', 'tissue', 'kk_ok']).agg(n_sweeps=('sweep', 'size'), sd_log10_Rinf=('log10_Rinf', 'std'), sd_log10_Q=('log10_Q', 'std'),
        sd_alpha=('alpha', 'std'), sd_L_mH=('L_mH', 'std')).reset_index()
V['residual_share_of_deviation'] = V.source_file.map(share); V.to_csv(R.T/'Table_E1_between_sweep.csv', index=False)
print(V.drop(columns='source_file').round(4).to_string())
print('median residual share of sweep deviation energy:', share.median(), share.quantile([.25, .75]).tolist())
