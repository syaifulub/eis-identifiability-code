"""E1b: deterministic (noise-free) bias of the R-CPE-L descriptors when the truth is a Cole dispersion with f_c below the band.
For each KK-consistent spectrum, the Cole truth shares Rinf, L and the high-frequency asymptote Q = tau^alpha/dR with the fitted
R-CPE-L; f_c is varied on a grid. Bias = fitted - asymptotic value."""
import math, numpy as np, pandas as pd
import r2_core as R
rows = []
for s in R.spectra():
    if not s['kk_ok']: continue
    p = R.fit('rcpe_l', s['f'], s['Z'])['params']; w = 2*np.pi*s['f']; a = min(max(p['alpha'], 0.5), 0.95)
    for fc in [10, 30, 100, 300, 1000, 3000]:
        tau = 1/(2*np.pi*fc); dR = tau**a/p['Q']; z = p['Rinf'] + dR/(1 + (1j*w*tau)**a) + 1j*w*p['L']
        q = R.fit('rcpe_l', s['f'], z)['params']
        rows.append(dict(source_file=s['sf'], fc_hz=fc, fmin_over_fc=1e4/fc, bias_log10_Q=math.log10(q['Q']) - math.log10(p['Q']),
                         bias_alpha=q['alpha'] - a, bias_log10_Rinf=math.log10(q['Rinf']) - math.log10(p['Rinf'])))
D = pd.DataFrame(rows); D.to_csv(R.T/'e1b_bias_runs.csv', index=False)
S = D.groupby(['fc_hz', 'fmin_over_fc'])[['bias_log10_Q', 'bias_alpha', 'bias_log10_Rinf']].median().reset_index()
S.to_csv(R.T/'Table_E1b_bias.csv', index=False); print(S.round(4).to_string())
