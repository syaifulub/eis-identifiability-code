"""E2: sensitivity of the R-CPE descriptors (Rinf, Q, alpha) to the treatment of the high-frequency correction.
T0 R-CPE + series L (published); T1 R-CPE without correction, 10-80 kHz; T1b R-CPE + L, 10-80 kHz;
T2 R-CPE x exp(-j w t_d) (pure delay = phase error linear in frequency); T3 R-CPE x exp(j phi0) (constant phase offset);
T4 R-CPE + K (j w)^nu (generalised high-frequency CPE term; nu = 1 is the inductance)."""
import math, numpy as np, pandas as pd
import r2_core as R
TR = [('T0', 'rcpe_l', None), ('T1', 'rcpe', 80e3), ('T1b', 'rcpe_l', 80e3), ('T2', 'rcpe_delay', None), ('T3', 'rcpe_phase', None), ('T4', 'rcpe_hfcpe', None)]
rows = []
for s in R.spectra():
    for name, model, fmax in TR:
        m = np.ones(len(s['f']), bool) if fmax is None else s['f'] <= fmax; f, Z = s['f'][m], s['Z'][m]
        F = R.fit(model, f, Z); p = F['params']; n = F['n']; k = F['k']
        aicc = n*math.log(F['rss']/n) + 2*k + 2*k*(k+1)/(n-k-1)
        sp = R.spec_of(model); at_b = [nm for nm, v, lo, hi in zip(sp['nl'], F['eta'], sp['lo'], sp['hi']) if abs(v-lo) < 1e-6*(hi-lo) or abs(v-hi) < 1e-6*(hi-lo)]
        rows.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], treatment=name, model=model, band_kHz=f'{f.min()/1e3:g}-{f.max()/1e3:g}',
                         NRMSE=math.sqrt(F['rss']/len(f)), AICc_fullband=aicc if fmax is None else np.nan, log10_Rinf=math.log10(p['Rinf']),
                         log10_Q=math.log10(p['Q']), alpha=p['alpha'], extra=p.get('td_us', p.get('phi0', p.get('nu', p.get('L', np.nan)))),
                         K=p.get('K', np.nan), nl_at_bound=';'.join(at_b)))
D = pd.DataFrame(rows); base = D[D.treatment == 'T0'].set_index('source_file')
for c in ['log10_Rinf', 'log10_Q', 'alpha']: D['d_'+c] = D[c] - D.source_file.map(base[c])
D.to_csv(R.T/'e2_hf_runs.csv', index=False)
q = lambda x: f"{np.median(x):.3f} [{np.quantile(x, .25):.3f}, {np.quantile(x, .75):.3f}]"
S = D.groupby('treatment').agg(NRMSE=('NRMSE', q), abs_d_log10_Rinf=('d_log10_Rinf', lambda x: q(x.abs())), abs_d_log10_Q=('d_log10_Q', lambda x: q(x.abs())),
        abs_d_alpha=('d_alpha', lambda x: q(x.abs())), extra=('extra', q), at_bound=('nl_at_bound', lambda x: int((x != '').sum()))).reset_index()
best = D[D.AICc_fullband.notna()].loc[lambda d: d.groupby('source_file').AICc_fullband.idxmin()].treatment.value_counts()
S['AICc_best_count'] = S.treatment.map(best).fillna(0).astype(int)
S.to_csv(R.T/'Table_E2_hf_treatments.csv', index=False); print(S.to_string())
for kk in [True, False]:
    print('KK ok' if kk else 'KK inconsistent'); print(D[D.kk_ok == kk].groupby('treatment')[['d_log10_Q', 'd_alpha', 'd_log10_Rinf']].apply(lambda g: g.abs().median()).round(4).to_string())
