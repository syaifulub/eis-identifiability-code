"""E3: uncertainty-aware comparison of R-CPE-L (M11) and Cole+L (M10).
AICc under the independent and GLS (empirical covariance) objectives; leave-one-frequency-out split into interior
(20-90 kHz, interpolation) and endpoint (10, 100 kHz, extrapolation) errors; parametric-bootstrap LR test with M11 as
the null (boundary of M10), B = 100 draws from the fitted M11 with empirical noise; frequency-range sensitivity."""
import json, math, time, pickle, numpy as np, pandas as pd
from scipy.stats import wilcoxon
import r2_core as R
T = R.T; psi = np.array(json.load(open(T/'E1_psi.json'))['psi']); S_emp = R.sigma_struct(psi)
CACHE = T.parent/'cache_e3'; CACHE.mkdir(exist_ok=True)

def sub_W(mask):
    m2 = np.r_[mask, mask]; return R.whitener(S_emp[np.ix_(m2, m2)])
def aicc(F):
    n, k = F['n'], F['k']; return n*math.log(F['rss']/n) + 2*k + 2*k*(k+1)/(n-k-1)
def lofo(model, f, Z):
    e = []
    for k in range(len(f)):
        m = np.ones(len(f), bool); m[k] = False; F = R.fit(model, f[m], Z[m]); zp = R.predict(model, F['params'], f[k:k+1])[0]
        e.append(abs(zp - Z[k])**2/abs(Z[k])**2)
    return np.array(e)

rows = []
for si, s in enumerate(R.spectra()):
    cp = CACHE/f'e3_{si}.pkl'
    if cp.exists(): rows.append(pickle.load(open(cp, 'rb'))); continue
    t0 = time.time(); f, Z = s['f'], s['Z']; rec = dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'])
    for band, m in [('10-100', f > 0), ('10-80', f <= 80e3), ('20-100', f >= 20e3)]:
        W = sub_W(m)
        for tag, Wt in (('nom', None), ('gls', W)):
            a, b = R.fit('cole_l', f[m], Z[m], Wt), R.fit('rcpe_l', f[m], Z[m], Wt); rec[f'dAICc_{tag}_{band}'] = aicc(a) - aicc(b)
    e10, e11 = lofo('cole_l', f, Z), lofo('rcpe_l', f, Z); inner = (f > 10e3) & (f < 100e3)
    rec.update(lofo_int_M10=math.sqrt(e10[inner].mean()), lofo_int_M11=math.sqrt(e11[inner].mean()),
               lofo_end_M10=math.sqrt(e10[~inner].mean()), lofo_end_M11=math.sqrt(e11[~inner].mean()))
    # parametric bootstrap LR test, null = M11 (GLS and nominal objectives)
    W = R.whitener(S_emp); rng = np.random.default_rng(3000+si)
    for tag, Wt in (('nom', None), ('gls', W)):
        F11, F10 = R.fit('rcpe_l', f, Z, Wt), R.fit('cole_l', f, Z, Wt); lam = 20*math.log(F11['rss']/min(F10['rss'], F11['rss']))
        zt = R.predict('rcpe_l', F11['params'], f); F11n = R.fit('rcpe_l', f, Z)
        Sc = S_emp*(F11n['rss']/(np.trace(S_emp)*(1-4/20))); Lc = np.linalg.cholesky(Sc); lb = []
        for b in range(100):
            z = R.noise_draw(rng, Lc, zt); r11, r10 = R.fit('rcpe_l', f, z, Wt)['rss'], R.fit('cole_l', f, z, Wt)['rss']
            lb.append(20*math.log(r11/min(r10, r11)))
        rec[f'LR_obs_{tag}'] = lam; rec[f'p_boot_{tag}'] = (1 + sum(x >= lam for x in lb))/(1 + len(lb)); rec[f'LR_boot95_{tag}'] = float(np.quantile(lb, .95))
    pickle.dump(rec, open(cp, 'wb')); rows.append(rec); print(time.strftime('%H:%M:%S'), si, s['tissue'], f'{time.time()-t0:.0f}s', flush=True)

D = pd.DataFrame(rows); D.to_csv(T/'e3_model_selection_runs.csv', index=False)
summ = {}
for tag in ['nom', 'gls']:
    for band in ['10-100', '10-80', '20-100']: summ[f'M11_pref_AICc_{tag}_{band}'] = int((D[f'dAICc_{tag}_{band}'] > 0).sum())
    summ[f'bootLR_reject_M11_{tag}'] = int((D[f'p_boot_{tag}'] < 0.05).sum()); summ[f'median_p_boot_{tag}'] = D[f'p_boot_{tag}'].median()
for part in ['int', 'end']:
    a, b = D[f'lofo_{part}_M10'], D[f'lofo_{part}_M11']
    summ[f'lofo_{part}_M11_better'] = int((b < a).sum()); summ[f'lofo_{part}_median_M10'] = a.median(); summ[f'lofo_{part}_median_M11'] = b.median()
    summ[f'lofo_{part}_wilcoxon_p'] = wilcoxon(b, a).pvalue
S = pd.Series(summ); S.to_csv(T/'Table_E3_model_selection.csv'); print(S.round(4).to_string())
