"""E4: sensitivity of the practical-identifiability classification to the precision threshold and to the M11 search bounds.
Uses the measured intervals from E1 (nominal and calibrated thresholds, independent and GLS objectives).
Bound perturbation (independent objective): alpha lower bound 0.30 -> 0.20; 1/Q bounds [1, 1e12] -> [1e-2, 1e14]."""
import math, numpy as np, pandas as pd
import r2_core as R
T = R.T
I = pd.concat([pd.read_csv(T/'e1_intervals_M11.csv'), pd.read_csv(T/'e1_intervals_M10.csv')])
rows = []
for (lab_log, lab_a) in [(0.5, 0.1), (1.0, 0.2), (1.5, 0.3)]:
    lim = I.param.map(lambda p: lab_a if p == 'alpha' else lab_log); I['id'] = I.closed & (I.width < lim)
    for (m, p, o, t), g in I.groupby(['model', 'param', 'objective', 'threshold']):
        rows.append(dict(log_threshold_dec=lab_log, alpha_threshold=lab_a, model=m, param=p, objective=o, interval=t,
                         ident_all=int(g.id.sum()), ident_kk_ok=int(g[g.kk_ok].id.sum()), n_kk_ok=int(g.kk_ok.sum())))
S = pd.DataFrame(rows); S.to_csv(T/'Table_E4_threshold_sensitivity.csv', index=False)
print(S[(S.objective == 'nom')].pivot_table(index=['model', 'param', 'interval'], columns='log_threshold_dec', values=['ident_all', 'ident_kk_ok']).to_string())
print(S[(S.objective == 'gls')].pivot_table(index=['model', 'param', 'interval'], columns='log_threshold_dec', values=['ident_all', 'ident_kk_ok']).to_string())

# bound perturbation for the M11 descriptors
cst = pd.read_csv(T/'e1_cstar_M11.csv'); cst = cst[cst.objective == 'nom'].set_index(['source_file', 'param']).c_star
nl, lo, hi, lin, llo, lhi, B = R.MODELS['rcpe_l']; R.MODELS['rcpe_l'] = (nl, [0.20], hi, lin, [1e-3, 1e-2, 1e-9], [1e7, 1e14, 1.0], B)
rows = []
for s in R.spectra():
    for pn in ['log10_Q', 'alpha']:
        g, lr, est = R.profile_curve('rcpe_l', s['f'], s['Z'], pn)
        for tn, thr in (('chi2', 3.84), ('cal', cst[(s['sf'], pn)])):
            a, b, wd, cl = R.ci_from_curve(g, lr, thr)
            rows.append(dict(source_file=s['sf'], kk_ok=s['kk_ok'], param=pn, interval=tn, width=wd, closed=cl, ident=bool(cl and wd < (0.2 if pn == 'alpha' else 1.0)), estimate=est))
B2 = pd.DataFrame(rows); B2.to_csv(T/'e4_bounds_runs.csv', index=False)
BS = B2.groupby(['param', 'interval']).agg(ident_all=('ident', 'sum'), ident_kk_ok=('ident', lambda x: int(x[B2.loc[x.index, 'kk_ok']].sum())), median_width=('width', 'median')).reset_index()
BS.to_csv(T/'Table_E4_bounds.csv', index=False); print(BS.to_string())
