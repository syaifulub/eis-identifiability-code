"""E5: frequency-grid design with range and number of frequencies separated.
Truth: Cole+L with tissue-like parameters (as band_design.py) and f_c drawn from three classes.
Fitted model: Cole+L (bounded VarPro, global). Practical identifiability of log10 tau: 95% profile interval (chi2 3.84)
closed and narrower than 1 decade; sensitivity with the median calibrated critical value of log10 tau (6.38, Table S15). Designs (f_max = 100 kHz):
  base   : equal-N log grids, N = 10 and 20, white 2.5% noise
  linear : N = 20 linear grid
  corr   : N = 20 log grid, AR(1)-correlated noise (rho = 0.5 between adjacent frequencies)
  ep10/ep50 : N = 20 log grid, series electrode-polarization CPE (nu = 0.6) with |Z_EP(1 kHz)| = 10% / 50% of |Z_tissue(1 kHz)|,
              not included in the fitted model
  mis    : N = 20 log grid, second (high-frequency) Cole dispersion in the truth, single Cole fitted
Usage: python e5_band_factorial.py [n_per_cell]"""
import sys, math, time, pickle, numpy as np, pandas as pd
import r2_core as R
T = R.T; NS = int(sys.argv[1]) if len(sys.argv) > 1 else 20; CACHE = T.parent/'cache_e5'; CACHE.mkdir(exist_ok=True)
FMIN = [10e3, 3e3, 1e3, 300.0]; FC = {'low': (100, 1000), 'mid': (1000, 10000), 'near': (10000, 30000)}
THR_CAL = 6.38
DESIGNS = [('base', 10), ('base', 20), ('linear', 20), ('corr', 20), ('ep10', 20), ('ep50', 20), ('mis', 20)]

def truth(i, fc_rng):
    rng = np.random.default_rng(424242 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(*np.log10(fc_rng)); tau = 1/(2*np.pi*fc); dR = rng.uniform(1, 3)*Rinf
    return dict(Rinf=Rinf, dR=dR, tau=tau, alpha=a, L=L, fc=fc, nu_ep=0.6, fc2=10**rng.uniform(np.log10(3e4), np.log10(3e5))), rng

def zcole(p, w): return p['Rinf'] + p['dR']/(1 + (1j*w*p['tau'])**p['alpha']) + 1j*w*p['L']

rows = []
for di, (design, N) in enumerate(DESIGNS):
    for fcn, fcr in FC.items():
        cp = CACHE/f'v2_{design}_{N}_{fcn}_{NS}.pkl'
        if cp.exists(): rows += pickle.load(open(cp, 'rb')); continue
        t0 = time.time(); out = []
        for i in range(NS):
            p, rng = truth(i, fcr); nseed = rng.integers(1 << 30)
            for fmin in FMIN:
                f = np.linspace(fmin, 1e5, N) if design == 'linear' else np.logspace(np.log10(fmin), 5, N); w = 2*np.pi*f
                z0 = zcole(p, w)
                if design.startswith('ep'):
                    frac = 0.1 if design == 'ep10' else 0.5; w1 = 2*np.pi*1e3; K = frac*abs(zcole(p, np.array([w1]))[0])*w1**p['nu_ep']
                    z0 = z0 + K*(1j*w)**(-p['nu_ep'])
                if design == 'mis': z0 = z0 + 0.2*p['dR']/(1 + 1j*w/(2*np.pi*p['fc2']))**0.8
                nr = np.random.default_rng(nseed); e = nr.standard_normal((2, N))
                if design == 'corr':
                    for k in range(1, N): e[:, k] = 0.5*e[:, k-1] + math.sqrt(0.75)*e[:, k]
                z = z0 + 0.025*np.abs(z0)*(e[0] + 1j*e[1])/math.sqrt(2)
                g, lr, est = R.profile_curve('cole_l', f, z, 'log10_tau', n_grid=33); lo, hi, wd, cl = R.ci_from_curve(g, lr, 3.84)
                lo2, hi2, wd2, cl2 = R.ci_from_curve(g, lr, THR_CAL)
                F = R.fit('cole_l', f, z)
                out.append(dict(design=design, N=N, fc_class=fcn, spectrum=i, fmin_hz=fmin, fc_true=p['fc'], ratio_fmin_fc=fmin/p['fc'],
                                tau_width=wd, tau_closed=cl, tau_ident=bool(cl and wd < 1.0), tau_ident_cal=bool(cl2 and wd2 < 1.0), tau_abserr=abs(est - math.log10(p['tau'])),
                                dR_abserr=abs(math.log10(F['params']['dR']) - math.log10(p['dR']))))
        pickle.dump(out, open(cp, 'wb')); rows += out
        print(time.strftime('%H:%M:%S'), design, N, fcn, f'{time.time()-t0:.0f}s', flush=True)
D = pd.DataFrame(rows); D.to_csv(T/'e5_band_runs.csv', index=False)
S = D.groupby(['design', 'N', 'fc_class', 'fmin_hz']).agg(n=('spectrum', 'size'), tau_ident_pct=('tau_ident', lambda x: 100*x.mean()), tau_ident_cal_pct=('tau_ident_cal', lambda x: 100*x.mean()),
        median_tau_width=('tau_width', 'median'), median_tau_abserr=('tau_abserr', 'median'), median_dR_abserr=('dR_abserr', 'median')).reset_index()
S.to_csv(T/'Table_E5_band_factorial.csv', index=False)
P = S.pivot_table(index=['design', 'N', 'fc_class'], columns='fmin_hz', values='tau_ident_pct').iloc[:, ::-1]
print(P.round(0).to_string())
D['ratio_bin'] = pd.cut(D.ratio_fmin_fc, [0, 0.3, 1, 3, 10, 1e4], labels=['<0.3', '0.3-1', '1-3', '3-10', '>10'])
Q = D.groupby(['design', 'N', 'ratio_bin'], observed=True).tau_ident.mean().mul(100).unstack(); Q.to_csv(T/'Table_E5_ratio.csv'); print(Q.round(0).to_string())
Q2 = D.groupby(['design', 'N', 'ratio_bin'], observed=True).tau_ident_cal.mean().mul(100).unstack(); Q2.to_csv(T/'Table_E5_ratio_cal.csv'); print(Q2.round(0).to_string())
