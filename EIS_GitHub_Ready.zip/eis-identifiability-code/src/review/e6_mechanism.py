"""E6: mechanism of the VarPro gain.
VPinit-MS-TRF: full-parameter multistart TRF in which each start draws the nonlinear parameters exactly as VP-MS-TRF does
and sets the linear coefficients to their bounded-LS optimum c*(eta0); the search then proceeds in the full space.
Same spectra, seeds (first 10 runs of the main benchmark), 2,000 NFE (the start-up solve counts as one evaluation) and
0.1% success rule. Conditioning: singular-value condition number of the full and reduced residual Jacobians at the
best-known solutions (finite differences on the log10 parameterisation)."""
import sys, math, time, pickle, numpy as np, pandas as pd
from pathlib import Path
SRC = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(SRC))
from scipy.optimize import least_squares
import eis_core as E, vp_core as V
from vp_common import load_spectra
T = SRC.parent/'results'/'tables'; CACHE = T.parent/'cache_e6'; CACHE.mkdir(exist_ok=True); RUNS = 10; BUD = 2000; CPS = (200, 500, 1000, 2000)

def vpinit_ms_trf(model, w, z, seed):
    vp = V.VarPro(model, w, z); _, lo, hi = E.MODELS[model]; f = E.make_objective(model, w, z); Tr = E.Tracker(f, BUD, CPS)
    rng = np.random.default_rng(seed)
    def res(x):
        if Tr.nfe >= BUD: raise E._Budget
        Tr(x); return E.residual(model, x, w, z)
    while Tr.nfe < BUD:
        eta0 = rng.uniform(vp.sp['lo'], vp.sp['hi']); Tr.nfe += 1; x0 = np.clip(vp.full_params(eta0), lo, hi)
        try: least_squares(res, x0, bounds=(lo, hi), jac='2-point', max_nfev=10000)
        except E._Budget: break
    return Tr.best

def jac_cond(fun, x, lo, hi, h=1e-6):
    x = np.asarray(x, float); r0 = fun(x); J = []
    for k in range(len(x)):
        d = h*max(1.0, abs(x[k])); xp = x.copy(); xp[k] = min(x[k]+d, hi[k]) if x[k]+d <= hi[k] else x[k]-d
        J.append((fun(xp) - r0)/(xp[k]-x[k]))
    s = np.linalg.svd(np.array(J).T, compute_uv=False); return float(s[0]/s[-1])

rows, crow = [], []
for model in ['M10_ColeL', 'M12_DoubleColeL']:
    M = pd.read_csv(T/f'vp_merged_{model}.csv'); ref = M.groupby('source_file').ref.first()
    for s in load_spectra():
        cp = CACHE/f'{model}_{s["si"]}.pkl'
        if cp.exists(): a, c = pickle.load(open(cp, 'rb')); rows += a; crow += c; continue
        t0 = time.time(); a = []
        seeds = [20261101 + s['si']*1000 + r for r in range(RUNS)]   # seed rule of the main benchmark (run index r)
        for r, sd in enumerate(seeds):
            fb = vpinit_ms_trf(model, s['w'], s['z'], int(sd)); nr = math.sqrt(fb)
            a.append(dict(model=model, source_file=s['sf'], run=r+1, seed=int(sd), algorithm='VPinit-MS-TRF', NRMSE=nr, success=(nr - ref[s['sf']])/ref[s['sf']] <= 1e-3))
        # conditioning at the best-known solution
        b = M[M.source_file == s['sf']].sort_values('NRMSE').iloc[0]; vp = V.VarPro(model, s['w'], s['z']); _, lo, hi = E.MODELS[model]
        names = {'M10_ColeL': ['logRinf', 'logdR', 'logtau', 'alpha', 'logL'],
                 'M12_DoubleColeL': ['logRinf', 'logdR1', 'logtau1', 'logdR2', 'logtau2', 'alpha1', 'alpha2', 'logL']}[model]
        x = np.array([b[n] for n in names]); x = np.clip(x, lo, hi)
        nlx = [x[2], x[3]] if model == 'M10_ColeL' else [x[2], x[4], x[5], x[6]]
        c = [dict(model=model, source_file=s['sf'], cond_full=jac_cond(lambda u: E.residual(model, u, s['w'], s['z']), x, lo, hi),
                  cond_reduced=jac_cond(vp.res, np.array(nlx), vp.sp['lo'], vp.sp['hi']))]
        pickle.dump((a, c), open(cp, 'wb')); rows += a; crow += c; print(time.strftime('%H:%M:%S'), model, s['si'], f'{time.time()-t0:.0f}s', flush=True)
D = pd.DataFrame(rows); D.to_csv(T/'e6_vpinit_runs.csv', index=False); Cn = pd.DataFrame(crow); Cn.to_csv(T/'e6_conditioning.csv', index=False)
out = []
for model in ['M10_ColeL', 'M12_DoubleColeL']:
    M = pd.read_csv(T/f'vp_merged_{model}.csv'); key = D[D.model == model][['source_file', 'run']]
    Mm = M.merge(key, on=['source_file', 'run'])
    r = dict(model=model, runs=len(key), **{a: 100*Mm[Mm.algorithm == a].success.mean() for a in ['MS-TRF', 'VP-MS-TRF']},
             **{'VPinit-MS-TRF': 100*D[D.model == model].success.mean()})
    c = Cn[Cn.model == model]; r.update(median_cond_full=c.cond_full.median(), median_cond_reduced=c.cond_reduced.median()); out.append(r)
O = pd.DataFrame(out); O.to_csv(T/'Table_E6_mechanism.csv', index=False); print(O.to_string())
