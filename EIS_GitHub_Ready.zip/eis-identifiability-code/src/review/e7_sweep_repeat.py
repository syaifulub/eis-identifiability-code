"""E7: sweep-level repeatability. M10 and M11 are refitted (global VarPro) to every complete sweep; the between-sweep SD
within a recording is compared with the reading-level resampling SD reported previously (Table_repeatability)."""
import sys, math, numpy as np, pandas as pd
import r2_core as R
SW = R.sweeps(sys.argv[1]); rows = []
for s in R.spectra():
    for i, z in enumerate(SW[s['sf']]):
        a = R.fit('cole_l', s['f'], z)['params']; b = R.fit('rcpe_l', s['f'], z)['params']
        rows.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], sweep=i, n_sweeps=len(SW[s['sf']]),
                         M10_log10_tau=a['log10_tau'], M10_log10_dR=math.log10(a['dR']), M10_log10_Rinf=math.log10(a['Rinf']), M10_alpha=a['alpha'],
                         M11_log10_Q=math.log10(b['Q']), M11_alpha=b['alpha'], M11_log10_Rinf=math.log10(b['Rinf'])))
D = pd.DataFrame(rows); D.to_csv(R.T/'e7_sweep_params.csv', index=False)
cols = [c for c in D.columns if c.startswith('M1')]
m = D[D.n_sweeps > 1]
sd = m.groupby(['source_file', 'kk_ok'])[cols].std().reset_index()
out = []
for c in cols:
    for kk in [True, False]:
        x = sd[sd.kk_ok == kk][c]; out.append(dict(param=c, kk_ok=kk, recordings=len(x), median_between_sweep_sd=x.median(), max_sd=x.max()))
# ICC (one-way, unbalanced) over KK-consistent multi-sweep recordings
for c in cols:
    g = m[m.kk_ok].groupby('source_file')[c]; k = g.size(); n = k.sum(); a = len(k); gm = m[m.kk_ok][c].mean()
    msb = (k*(g.mean()-gm)**2).sum()/(a-1); msw = ((m[m.kk_ok][c] - g.transform('mean'))**2).sum()/(n-a); k0 = (n - (k**2).sum()/n)/(a-1)
    out.append(dict(param=c, kk_ok='ICC', recordings=a, median_between_sweep_sd=(msb-msw)/(msb+(k0-1)*msw), max_sd=np.nan))
O = pd.DataFrame(out); O.to_csv(R.T/'Table_E7_sweep_repeatability.csv', index=False); print(O.round(4).to_string())
