"""E8: checks of the error model that do not rely on residuals alone.
(a) Scenario check. Residuals are projections of the errors, so a smooth error component lying in the model tangent
    space is invisible in them; the projection-corrected likelihood is weakly identified (rho_f 0.93, 95% CI 0.06-1.00).
    For each KK-consistent spectrum, errors are simulated under the residual-based covariance and under the
    projection-corrected covariance, both scaled so that the expected residual sum of squares, tr(P Sigma P), equals the
    observed RSS. Reported: implied SD of the fitted descriptors and coverage of the calibrated intervals. The implied SD
    is compared with the observed between-sweep SD of the same recording, which also contains drift and is therefore
    an upper bound for noise-induced variability.
(b) Cross-sweep predictive check. For every recording with >= 2 sweeps, each sweep is fitted and profiled (nominal and
    calibrated thresholds, residual-based covariance, B = 100). For every pair of sweeps, |theta_i - theta_j| is compared
    with sqrt(h_i^2 + h_j^2), h = interval half-width; with calibrated intervals and no drift this should hold in about
    95% of pairs. Usage: python e8_errcheck.py RAW_DIR"""
import sys, json, math, itertools, time, numpy as np, pandas as pd
import r2_core as R
T = R.T; SW = R.sweeps(sys.argv[1]); SP = R.spectra()
S_naive = R.sigma_struct(json.load(open(T/'E1_psi.json'))['psi']); S_proj = R.sigma_struct(json.load(open(T/'E1_psi_projected.json'))['psi'])
cst = pd.read_csv(T/'e1_cstar_M11.csv'); cst = cst[cst.objective == 'nom'].set_index(['source_file', 'param']).c_star
PARS = ['log10_Q', 'alpha', 'log10_Rinf']

def projector(f, Z, F):
    vp = R.VP('rcpe_l', f, Z); eta = F['eta']; c, _ = vp.coef(eta); A = vp._sys(eta)[0]; h = 1e-6
    da = (vp._sys(eta + h)[0] - A) @ c/h; sp = vp.sp
    free = [j for j in range(3) if sp['llo'][j]*(1+1e-9) < c[j] < sp['lhi'][j]*(1-1e-9)]
    J = np.column_stack(([da] if 0.3+1e-9 < eta[0] < 1-1e-9 else []) + [A[:, j] for j in free])
    return np.eye(20) - J @ np.linalg.pinv(J)
def truth(F):
    p = F['params']; return {'log10_Q': math.log10(p['Q']), 'alpha': p['alpha'], 'log10_Rinf': math.log10(p['Rinf'])}

# (a) scenario check
ev = pd.read_csv(T/'e1_sweep_fits.csv'); obs_sd = ev[ev.n_sweeps > 1].groupby('source_file')[['log10_Q', 'alpha', 'log10_Rinf']].std()
rows = []
for si, s in enumerate(SP):
    if not s['kk_ok']: continue
    F = R.fit('rcpe_l', s['f'], s['Z']); zt = R.predict('rcpe_l', F['params'], s['f']); tv = truth(F); P = projector(s['f'], s['Z'], F)
    for name, S in (('residual-based', S_naive), ('projection-corrected', S_proj)):
        Sc = S*F['rss']/np.trace(P @ S @ P); Lc = np.linalg.cholesky(Sc); rng = np.random.default_rng(100+si); est = {p: [] for p in PARS}; cov = {p: [] for p in PARS}
        for r in range(100):
            z = R.noise_draw(rng, Lc, zt); Fs = R.fit('rcpe_l', s['f'], z); e = truth(Fs)
            for p in PARS:
                est[p].append(e[p]); cov[p].append(R.lr_at('rcpe_l', s['f'], z, p, tv[p], None, Fs['rss']) <= cst[(s['sf'], p)])
        rec = dict(source_file=s['sf'], tissue=s['tissue'], scenario=name)
        for p in PARS:
            rec[f'sd_{p}'] = float(np.std(est[p], ddof=1)); rec[f'cov_{p}'] = 100*float(np.mean(cov[p]))
            rec[f'obs_sweep_sd_{p}'] = float(obs_sd.loc[s['sf'], p]) if s['sf'] in obs_sd.index else np.nan
        rows.append(rec)
    print(time.strftime('%H:%M:%S'), 'a', si, flush=True)
A = pd.DataFrame(rows); A.to_csv(T/'e8_scenario_runs.csv', index=False)
SA = A.groupby('scenario')[[c for c in A.columns if c.startswith(('sd_', 'cov_'))]].median()
m = A.dropna(subset=['obs_sweep_sd_log10_Q'])
SA['recordings_with_sweeps'] = m.groupby('scenario').size()
for p in PARS: SA[f'implied_gt_observed_{p}'] = m.groupby('scenario').apply(lambda g: int((g[f'sd_{p}'] > g[f'obs_sweep_sd_{p}']).sum()), include_groups=False)
SA.to_csv(T/'Table_E8_scenario.csv'); print(SA.round(3).T.to_string())

# (b) cross-sweep predictive check
rows = []
for si, s in enumerate(SP):
    X = SW[s['sf']]
    if len(X) < 2: continue
    per = []
    for i, z in enumerate(X):
        F = R.fit('rcpe_l', s['f'], z); zt = R.predict('rcpe_l', F['params'], s['f']); tv = truth(F)
        Lc = np.linalg.cholesky(S_naive*F['rss']/(np.trace(S_naive)*(1 - 4/20))); rng = np.random.default_rng(7000+100*si+i); L = {p: [] for p in PARS}
        for b in range(100):
            zz = R.noise_draw(rng, Lc, zt); rm = R.fit('rcpe_l', s['f'], zz)['rss']
            for p in PARS: L[p].append(R.lr_at('rcpe_l', s['f'], zz, p, tv[p], None, rm))
        rec = dict(sweep=i)
        for p in PARS:
            g, lr, est = R.profile_curve('rcpe_l', s['f'], z, p); rec[p] = est
            for tn, thr in (('nom', 3.84), ('cal', float(np.quantile(L[p], .95)))):
                lo, hi, w, cl = R.ci_from_curve(g, lr, thr); rec[f'h_{tn}_{p}'] = w/2
        per.append(rec)
    for a, b in itertools.combinations(per, 2):
        r = dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], i=a['sweep'], j=b['sweep'])
        for p in PARS:
            d = abs(a[p] - b[p]); r[f'diff_{p}'] = d
            for tn in ('nom', 'cal'): r[f'ok_{tn}_{p}'] = bool(d <= math.hypot(a[f'h_{tn}_{p}'], b[f'h_{tn}_{p}']))
        rows.append(r)
    print(time.strftime('%H:%M:%S'), 'b', si, len(X), flush=True)
Bx = pd.DataFrame(rows); Bx.to_csv(T/'e8_cross_sweep_pairs.csv', index=False)
out = []
for kk in [True, False]:
    g = Bx[Bx.kk_ok == kk]; r = dict(kk_ok=kk, recordings=g.source_file.nunique(), pairs=len(g))
    for p in PARS:
        for tn in ('nom', 'cal'): r[f'{tn}_{p}_pct'] = 100*g[f'ok_{tn}_{p}'].mean()
    out.append(r)
SB = pd.DataFrame(out); SB.to_csv(T/'Table_E8_cross_sweep.csv', index=False); print(SB.round(1).T.to_string())
