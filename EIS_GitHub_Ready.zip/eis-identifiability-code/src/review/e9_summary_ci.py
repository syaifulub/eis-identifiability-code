"""E9: confidence intervals for summary statistics.
(a) Sweep-level ICC (one-way, unbalanced) with 95% percentile intervals from 2,000 resamples of recordings.
(b) Coverage with cluster bootstrap intervals (resampling spectra, 2,000 replicates), which account for the
    dependence of replicates generated from the same spectrum."""
import numpy as np, pandas as pd
import r2_core as R
T = R.T; rng = np.random.default_rng(11)
D = pd.read_csv(T/'e7_sweep_params.csv'); m = D[(D.n_sweeps > 1) & D.kk_ok]
def icc(df, c):
    g = df.groupby('grp')[c]; k = g.size(); n = k.sum(); a = len(k)
    if a < 3: return np.nan
    gm = df[c].mean(); msb = (k*(g.mean()-gm)**2).sum()/(a-1); msw = ((df[c]-g.transform('mean'))**2).sum()/(n-a); k0 = (n-(k**2).sum()/n)/(a-1)
    return (msb-msw)/(msb+(k0-1)*msw)
recs = m.source_file.unique(); rows = []
for c in [x for x in D.columns if x.startswith('M1')]:
    base = icc(m.assign(grp=m.source_file), c); bs = []
    for b in range(2000):
        pick = rng.choice(recs, len(recs), replace=True)
        bb = pd.concat([m[m.source_file == r].assign(grp=f'{r}_{i}') for i, r in enumerate(pick)])
        v = icc(bb, c)
        if np.isfinite(v): bs.append(v)
    rows.append(dict(param=c, recordings=len(recs), ICC=base, ci_low=np.quantile(bs, .025), ci_high=np.quantile(bs, .975)))
I = pd.DataFrame(rows); I.to_csv(T/'Table_E9_icc_ci.csv', index=False); print(I.round(3).to_string())
C = pd.read_csv(T/'e1_coverage_runs_M11.csv')
C['nominal'] = C.lr_nom <= 3.84; C['calibrated'] = C.lr_nom <= C.c_nom; C['GLS'] = C.lr_gls <= 3.84; C['GLS_cal'] = C.lr_gls <= C.c_gls
rows = []
for (cond, p), g in C.groupby(['cond', 'param']):
    per = g.groupby('source_file')[['nominal', 'calibrated', 'GLS', 'GLS_cal']].mean(); sf = per.index.values; r = dict(cond=cond, param=p)
    for mth in per.columns:
        bs = [per.loc[rng.choice(sf, len(sf), replace=True), mth].mean() for _ in range(2000)]
        r[mth] = 100*per[mth].mean(); r[mth+'_lo'] = 100*np.quantile(bs, .025); r[mth+'_hi'] = 100*np.quantile(bs, .975)
    rows.append(r)
CV = pd.DataFrame(rows); CV.to_csv(T/'Table_E9_coverage_clusterCI.csv', index=False)
print(CV[CV.cond.isin(['emp'])].round(1).to_string())
