"""Tables S32-S36 (between-recording variability, probe effect, descriptor replicates and scale test, reproducibility
limits and tissue discrimination, per-animal results) from the outputs of e12_placement.py."""
import sys, json, numpy as np, pandas as pd
import r2_core as R
T = R.T; out = sys.argv[1] if len(sys.argv) > 1 else 'supp_e12.tex'
G = pd.read_csv(T/'Table_E12_groups.csv'); S = pd.read_csv(T/'Table_E12_summary.csv'); PE = pd.read_csv(T/'Table_E12_probe.csv')
D = pd.read_csv(T/'Table_E12_descriptor_between.csv'); SC = pd.read_csv(T/'Table_E12_scale.csv'); L = pd.read_csv(T/'Table_E12_limits.csv').set_index('param')
DI = pd.read_csv(T/'Table_E12_discrimination.csv').set_index('param'); PA = pd.read_csv(T/'Table_E12_per_animal.csv'); BO = pd.read_csv(T/'Table_E12_between_animal.csv')
tr = json.load(open(T/'E12_transfer.json'))
PN = {'log10_Q': r'$\log_{10}Q$', 'alpha': r'$\alpha$', 'log10_Rinf': r'$\log_{10}R_{\infty}$', 'log10_RinfQ': r'$\log_{10}(R_{\infty}Q)$'}
MED = lambda m: m.replace('blood_', 'blood (').replace('artery', 'artery)').replace('vein', 'vein)') if m.startswith('blood') else m
def tab(cap, spec, head, rows):
    return ("\\begin{table}[H]\n\\centering\n\\caption{" + cap + "}\n\\footnotesize\n\\setlength{\\tabcolsep}{4pt}\n\\begin{tabular}{" + spec + "}\n\\toprule\n"
            + head + " \\\\\n\\midrule\n" + " \\\\\n".join(rows) + " \\\\\n\\bottomrule\n\\end{tabular}\n\\end{table}\n")
# S32 groups
r32 = []
for g in G.sort_values(['animal', 'probe', 'medium']).itertuples():
    med = MED(g.medium).replace('vein)', 'vein)') if g.medium.startswith('blood') else (g.medium + ' (scans)' if g.medium == 'vein' else g.medium)
    r32.append(f"{g.animal} & {g.probe} & {med} & {g.f_khz} & {g.recordings} & {g.median_R_ohm:.0f} & {g.between_sd_log10:.3f} & {g.cv_pct:.0f} & "
               + (f"{g.short_term_sd_log10:.4f}" if np.isfinite(g.short_term_sd_log10) else '--') + f" & {g.between_sd_phase_deg:.1f}")
r32.append('\\midrule\n\\multicolumn{10}{l}{\\emph{Pooled}}')
for s in S.itertuples():
    ci = f"[{s.ci_low:.3f}, {s.ci_high:.3f}]" if np.isfinite(s.ci_low) else ''
    ph = f"{s.phase_sd_deg:.1f}" if np.isfinite(s.phase_sd_deg) else '--'
    df = f"{int(s.df)}" if np.isfinite(s.df) else '--'
    r32.append(f"\\multicolumn{{4}}{{l}}{{{s.set}}} & {s.recordings} (df {df}) & & {s.between_sd:.3f} {ci} & {(f'{s.cv_pct:.1f}' if s.cv_pct < 1 else f'{s.cv_pct:.0f}')} & & {ph}")
t32 = tab(r"Between-recording variability of the resistance and phase angle in recordings of the same medium with the same probe, animal and frequency (most stable window of each single-frequency recording; median over sweeps of the 100~kHz point of the frequency scans). Vessel recordings begin in the surrounding tissue and end in blood (separate needle advances); whether static repeat recordings involved re-insertion at a new site is not documented. SD: standard deviation of the recording medians; CV $=10^{\mathrm{SD}}-1$; short-term SD: median robust SD of $\log_{10}R$ within the stable window. Pooled: degrees-of-freedom-weighted SD with $\chi^2$ 95\% interval.",
          'cllcccccccc'[:10], r"Animal & Probe & Medium & kHz & $n$ & \makecell{Median\\$R$ ($\Omega$)} & \makecell{SD\\$\log_{10}R$} & \makecell{CV\\(\%)} & \makecell{Short-term\\SD} & \makecell{SD phase\\($^{\circ}$)}", r32)
# S33 probe
r33 = [f"{p.tissue} & {p.n_yellow} & {p.n_white} & {p.log10_ratio_white_yellow:+.2f} & {100*(10**p.log10_ratio_white_yellow - 1):+.0f}" for p in PE.itertuples()]
t33 = tab(r"Probe effect: mean $\log_{10}R$ at 100~kHz with the second bipolar probe (white) minus that with the scan probe (yellow), first animal. Differences in blood, tendon and subcutaneous tissue exceed the between-recording SD (Table~S32), so absolute impedance descriptors are probe-specific.",
          'lcccc', r"Medium & $n$ yellow & $n$ white & $\Delta\log_{10}R$ & Difference (\%)", r33)
# S34 descriptors + scale test
r34 = []
for d in D.itertuples():
    r34.append(f"{PN[d.param]} & {d.set} & {d.df} & {d.between_recording_sd:.3f} & {d.within_sd:.3f} & {d.excess_sd:.3f} & {d.excess_sd_high:.2f}")
t34a = tab(r"Descriptor-level between-recording SD from recordings of the same tissue in the same animal (all: liver $\times$2 and muscle $\times$5, first animal; vein $\times$2, second animal; KK-consistent: the vein pair only). Within-recording SD: root mean of fitting variance (calibrated half-width/1.96) plus drift variance (Table~S28). Excess: $\sqrt{\max(\mathrm{SD}^2-\mathrm{within}^2,0)}$; upper bound from the $\chi^2$ 95\% upper limit of the SD. In the pooled set the within-recording variance of the KK-inconsistent recordings exceeds the between-recording variance, so no excess is estimable; with one degree of freedom the KK-consistent bound is uninformative.",
           'llccccc', r"Parameter & Set & df & \makecell{Between-recording\\SD} & \makecell{Within-recording\\SD} & Excess & \makecell{Excess, upper\\95\% bound}", r34)
r34b = []
for s in SC.itertuples():
    r34b.append(f"{s.set} & {s.sd_log10_Rinf:.3f} & {s.sd_log10_Q:.3f} & {s.sd_log10_RinfQ:.3f} & {s.sd_alpha:.3f} & {s.slope_dlogQ_on_dlogRinf:+.2f}")
t34b = tab(r"Scale test. A pure scale change of the impedance ($Z\to kZ$, e.g.\ a change of cell constant) shifts $\log_{10}R_{\infty}$ and $\log_{10}Q$ by equal and opposite amounts (slope $-1$), leaves $\alpha$ and the phase unchanged and cancels in $\log_{10}(R_{\infty}Q)$. Slope: regression of within-group deviations of $\log_{10}Q$ on those of $\log_{10}R_{\infty}$. Only the pooled set, dominated by KK-inconsistent muscle recordings, behaves partly like a scale change; the KK-consistent replicate pair and the between-sweep changes do not, consistent with the phase changes in Table~S32. Transfer slope from $\log_{10}R(100~\mathrm{kHz})$ to $\log_{10}R_{\infty}$ within KK-consistent recordings: " + f"{tr['kk']['slope']:.2f} ($r={tr['kk']['r']:.2f}$, {tr['kk']['n']} sweeps).",
           'lccccc', r"Set & \makecell{SD\\$\log_{10}R_{\infty}$} & \makecell{SD\\$\log_{10}Q$} & \makecell{SD\\$\log_{10}(R_{\infty}Q)$} & \makecell{SD\\$\alpha$} & Slope", r34b)
# S35 limits & discrimination
r35 = []
for q in ['log10_Rinf', 'log10_Q', 'alpha']:
    l = L.loc[q]; d = DI.loc[q]
    src = 'blood recordings' if q == 'log10_Rinf' else 'one replicate pair'
    r35.append(f"{PN[q]} & {l.s_within:.3f} & {l.r_limit:.3f} & {l.s_between:.3f} ({l.s_between_high:.2f}) & {l.R_limit:.2f} ({l.R_limit_high:.2f}) & {src} & {d.median_abs_diff:.3f} & {d.pct_gt_r:.0f} & {d.pct_gt_R:.0f} ({d.pct_gt_R_high:.0f})")
t35 = tab(r"Repeatability and reproducibility limits (ISO 5725 form, $r=2.77\,s_w$, $R=2.77\sqrt{s_w^2+s_b^2}$) and tissue discrimination. $s_w$: within-recording SD (fitting and drift, KK-consistent recordings); $s_b$: between-recording component (upper 95\% bound in parentheses), for $R_{\infty}$ from the bipolar blood recordings transferred with the slope of Table~S35, for $Q$ and $\alpha$ from the single KK-consistent replicate pair (point estimates only indicative; bounds uninformative). Discrimination: absolute differences between tissue means of the 10 tissues with KK-consistent spectra (45 pairs) and the percentage of pairs exceeding $r$ and $R$.",
          'lccccl cccc'.replace(' ', ''), r"Parameter & $s_w$ & $r$ & $s_b$ & $R$ & Source of $s_b$ & \makecell{Median\\$|\Delta|$} & \makecell{$>r$\\(\%)} & \makecell{$>R$\\(\%)}", r35)
# S36 per animal
pa = PA.set_index('animal')
items = [('Spectra (KK-consistent)', lambda a: f"{int(pa.loc[a, 'spectra'])} ({int(pa.loc[a, 'kk_consistent'])})"),
         ('M12 success, MS-TRF / VP-MS-TRF (\\%)', lambda a: f"{pa.loc[a, 'M12_success_MS_TRF']:.0f} / {pa.loc[a, 'M12_success_VP_MS_TRF']:.0f}"),
         ('Spectra with VP gain / spectra that differ', lambda a: pa.loc[a, 'VP_gain_positive']),
         ('$\\log_{10}\\tau$ practically identifiable', lambda a: pa.loc[a, 'tau_identifiable']),
         ('Band criterion agrees with profile likelihood', lambda a: pa.loc[a, 'criterion_agreement']),
         ('Median $\\Gamma$', lambda a: f"{pa.loc[a, 'Gamma_median']:.1f}"),
         ('Median detection limit, nominal / calibrated (kHz)', lambda a: f"{pa.loc[a, 'fc_detect_median_hz']/1e3:.1f} / {pa.loc[a, 'fc_detect_cal_median_hz']/1e3:.1f}"),
         ('Closed calibrated intervals $Q$, $\\alpha$, $R_{\\infty}$ (KK, \\%)', lambda a: f"{100*pa.loc[a, 'kk_closed_Q']:.0f}, {100*pa.loc[a, 'kk_closed_alpha']:.0f}, {100*pa.loc[a, 'kk_closed_Rinf']:.0f}"),
         ('Median calibrated half-width $\\log_{10}Q$ / $\\alpha$ (KK)', lambda a: f"{pa.loc[a, 'median_halfwidth_Q']:.2f} / {pa.loc[a, 'median_halfwidth_alpha']:.3f}")]
r36 = [f"{lab} & {fn(1)} & {fn(2)}" for lab, fn in items]
r36.append('\\midrule\n\\multicolumn{3}{l}{\\emph{Artery, one KK-consistent scan per animal: second minus first animal}}')
for b in BO.itertuples():
    r36.append(f"{PN[b.param]}: difference (fitting SE) & \\multicolumn{{2}}{{c}}{{{b.diff_2_minus_1:+.3f} ({b.fit_se:.3f}); $r$ = {L.loc[b.param, 'r_limit']:.3f}}}")
t36 = tab(r"Main results recomputed per animal (animal, recording subset and date are confounded: first animal = subset A, second = subset D). The detection limit is the per-spectrum median and differs from the pooled value in the main text.",
          'lcc', r"Quantity & First animal & Second animal", r36)
open(out, 'w').write('\n'.join([t32, t33, t34a, t34b, t35, t36]))
print('written', out)
