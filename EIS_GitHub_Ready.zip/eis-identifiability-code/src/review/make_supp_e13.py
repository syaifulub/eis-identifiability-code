"""Tables S38-S40 (cluster-aware inference and confirmatory hypotheses; robustness of the between-recording estimates;
precision and sample size) from the outputs of e13_stats.py."""
import sys, json, pandas as pd
import r2_core as R
T = R.T; out = sys.argv[1] if len(sys.argv) > 1 else 'supp_e13.tex'
A = pd.read_csv(T/'Table_E13_contrasts.csv'); H = pd.read_csv(T/'Table_E13_hypotheses.csv'); C = pd.read_csv(T/'Table_E13_coverage.csv')
K = pd.read_csv(T/'Table_E13_corr.csv'); RB = pd.read_csv(T/'Table_E13_robust_between.csv'); D1 = pd.read_csv(T/'Table_E13_precision_df.csv')
D2 = pd.read_csv(T/'Table_E13_placements.csv'); misc = json.load(open(T/'E13_misc.json'))
PN = {'log10_Q': r'$\log_{10}Q$', 'alpha': r'$\alpha$', 'log10_Rinf': r'$\log_{10}R_{\infty}$'}
CN = {'emp': 'empirical $\\Sigma$', 'rho_hi': '$\\rho_f+0.2$', 'ar1': 'AR(1)'}
def tab(cap, spec, head, rows):
    return ("\\begin{table}[H]\n\\centering\n\\caption{" + cap + "}\n\\footnotesize\n\\setlength{\\tabcolsep}{3.5pt}\n\\begin{tabular}{" + spec + "}\n\\toprule\n"
            + head + " \\\\\n\\midrule\n" + " \\\\\n".join(rows) + " \\\\\n\\bottomrule\n\\end{tabular}\n\\end{table}\n")
fp = lambda p: '$<10^{-4}$' if p < 1e-4 else (f'{p:.4f}' if p < 0.01 else f'{p:.3f}')
r = []
for h in H.itertuples():
    r.append(f"{h.H} & {h.hypothesis.replace('+-', '$\\pm$').replace('Sigma', '$\\Sigma$')} & {h.estimate} & {h.interval.replace('%', r'\%')} & {fp(h.p)} & {fp(h.p_holm)} & {'yes' if h._8 else 'no'}")
r.append('\\midrule\n\\multicolumn{7}{l}{\\emph{All contrasts: per-spectrum success difference (pp), 95\\% intervals by resampling unit}}')
r.append('Model & Contrast & Estimate & Spectra & Clusters (14) & Two-stage & Cluster-robust LPM')
for a in A.itertuples():
    r.append(f"{a.model} & {a.contrast} & {a.estimate_pp:+.1f} & {a.ci_spectrum} & {a.ci_cluster} & {a.ci_two_stage} & {a.lpm_ci}")
t38 = tab(r"Cluster-aware inference for the benchmark. Upper block: the four confirmatory hypotheses with Holm-adjusted p-values (H1, H4: exact one-sided sign-flip permutation of the means of the 14 tissue-within-animal clusters; H2, H3: two one-sided tests at $\pm5$ percentage points with the two-stage cluster bootstrap, 90\% interval shown; H4 averages $\log_{10}Q$, $\alpha$ and $\log_{10}R_{\infty}$ under the empirical covariance). Lower block: 95\% intervals of all benchmark contrasts at 2,000 NFE when resampling spectra, clusters, or clusters and then spectra within clusters, and from a run-level linear probability model with cluster-robust (CR1) standard errors. Clustering by tissue only (12 clusters) gave similar intervals (results files).",
          'lp{4.2cm}ccccc', r"H & Hypothesis & Estimate & Interval & $p$ & $p_{\mathrm{Holm}}$ & Supported", r)
t38 = t38.replace('{lp{4.2cm}ccccc}', '{llccccc}').replace('H & Hypothesis', 'H & Hypothesis')
# fix the column header of the lower block (7 columns)
r39 = []
for c in C.itertuples():
    r39.append(f"{CN[c.condition]} & {PN[c.param]} & {c.nominal:.1f} ({c.nominal_ci_two_stage}) & {c.calibrated:.1f} ({c.calibrated_ci_two_stage})")
r39.append('\\midrule\n' + f"\\multicolumn{{2}}{{l}}{{Spearman, detection limit vs upper $f_c$ bound}} & \\multicolumn{{2}}{{l}}{{{K.estimate[0]:.2f} ({K.ci[0]})}}")
r39.append(f"\\multicolumn{{2}}{{l}}{{Median $\\Gamma$, measured spectra}} & \\multicolumn{{2}}{{l}}{{{K.estimate[1]:.1f} ({K.ci[1]})}}")
t39a = tab(r"Coverage (\%) of nominal and calibrated 95\% profile intervals (12 KK-consistent spectra $\times$ 100 replicates) and measured-spectrum statistics, with two-stage cluster-bootstrap 95\% intervals (clusters: tissue within animal).",
           'llcc', r"Condition & Parameter & Nominal & Calibrated", r39)
r39b = []
for b in RB.itertuples():
    r39b.append(f"{b.set} & {b.groups} & {b.df} & {b.pooled_sd:.3f} & {b.ratio_to_within:.1f} & {b.loo_min:.3f}--{b.loo_max:.3f} & {b.loo_ratio_range.replace(' to ', '--')} & {b.mad_pooled:.3f} & {b.mad_ratio:.1f}")
t39b = tab(r"Robustness of the between-recording SD of $\log_{10}R$ (Table~S32): classical pooled SD, range when one group is left out, and a pooled median-absolute-deviation (MAD) estimate; ratios are relative to the between-sweep SD within KK-consistent recordings (" + f"{misc['s_within_R100']:.3f}" + r" decade). Between-recording variability exceeds within-recording variability in every analysis, but its size depends on a few discordant recordings; on the $R_{\infty}$ scale the reproducibility limit is 0.37 decade with the classical and 0.15 decade with the MAD estimate.",
           'lcccccccc', r"Set & Groups & df & SD & Ratio & \makecell{SD, leave one\\group out} & Ratio & \makecell{MAD\\SD} & Ratio", r39b)
r40 = [f"{d.df} & {d.sd_ci_low_factor:.2f} & {d.sd_ci_high_factor:.2f}" for d in D1.itertuples()]
t40a = tab(r"Precision of an estimated standard deviation: 95\% $\chi^2$ interval as a multiple of the estimate, by degrees of freedom. An upper limit within 1.5 times the estimate requires about " + f"{misc['df_for_upper_factor_1p5']}" + r" degrees of freedom, for example ten tissues with three placements each; the present KK-consistent replicate data for $Q$ and $\alpha$ have one.",
           'ccc', r"df & Lower factor & Upper factor", r40)
r40b = [f"{d.placements_per_tissue} & {d.R_limit_mean:.3f} & {d.pct_pairs_exceeding:.0f}" for d in D2.itertuples()]
t40b = tab(r"Planning a replicate study: reproducibility limit of tissue means of $\log_{10}R_{\infty}$ when $n$ placements per tissue are averaged, $2.77\sqrt{(s_w^2+s_b^2)/n}$ with the classical estimates of Table~S36, and the percentage of the 45 observed tissue pairs (KK-consistent spectra) whose difference exceeds it.",
           'ccc', r"Placements per tissue $n$ & Limit (decade) & Pairs exceeding (\%)", r40b)
open(out, 'w').write('\n'.join([t38, t39b, t40b, t39a, t40a])); print('written', out)
