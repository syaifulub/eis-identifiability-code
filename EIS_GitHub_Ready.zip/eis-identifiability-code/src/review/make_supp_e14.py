"""Tables S45-S47 (KK-consistent primary physical analysis; error model from KK-consistent recordings and calibration
sensitivity; closed-form criterion in the weak-identifiability regime) from the outputs of e14_kk_primary.py."""
import sys, pandas as pd
import r2_core as R
T = R.T; out = sys.argv[1] if len(sys.argv) > 1 else 'supp_e14.tex'
SCR = pd.read_csv(T/'Table_E14_screening.csv'); MS = pd.read_csv(T/'Table_E14_model_selection.csv').set_index('set'); HF = pd.read_csv(T/'Table_E14_hf.csv')
DE = pd.read_csv(T/'Table_E14_descriptors.csv').set_index('set'); EM = pd.read_csv(T/'Table_E14_error_model_kk.csv'); COV = pd.read_csv(T/'Table_E14_coverage_kk.csv')
WK = pd.read_csv(T/'Table_E14_weak_ident.csv')
K, A = 'KK-consistent (12)', 'all (20)'
def tab(cap, spec, head, rows):
    return ("\\begin{table}[H]\n\\centering\n\\caption{" + cap + "}\n\\footnotesize\n\\setlength{\\tabcolsep}{4pt}\n\\begin{tabular}{" + spec + "}\n\\toprule\n"
            + head + " \\\\\n\\midrule\n" + " \\\\\n".join(rows) + " \\\\\n\\bottomrule\n\\end{tabular}\n\\end{table}\n")
NM = {'M11_RCPEL': 'M11 R--CPE--L', 'M10_ColeL': 'M10 Cole+L', 'M2_FrickeMorse': 'M2 Fricke--Morse', 'M6_FrickeCPE': 'M6 Fricke--CPE', 'M4_RandlesCPE': 'M4 Randles--CPE'}
r = ['\\multicolumn{5}{l}{\\emph{(a) Screening, five best models}} & \\multicolumn{3}{l}{}']
k5 = SCR[SCR.set == K].sort_values('mean_AICc_rank').head(5)
for x in k5.itertuples():
    y = SCR[(SCR.set == A) & (SCR.model == x.model)].iloc[0]
    r.append(f"{NM.get(x.model, x.model)} & {x.k} & {x.median_NRMSE:.4f} & {x.AICc_wins} / {x.BIC_wins} & {x.mean_AICc_rank:.2f} & {y.median_NRMSE:.4f} & {y.AICc_wins} / {y.BIC_wins} & {y.mean_AICc_rank:.2f}")
r.append('\\midrule\n\\multicolumn{8}{l}{\\emph{(b) M10 versus M11 (number of spectra; KK-consistent / all)}}')
mk, ma = MS.loc[K], MS.loc[A]
for lab, col in [('M11 preferred, AICc, independent, 10--100 kHz', 'M11_pref_AICc_nom_10-100'), ('M11 preferred, AICc, independent, 10--80 / 20--100 kHz', None),
                 ('M11 preferred, AICc, GLS, 10--100 kHz', 'M11_pref_AICc_gls_10-100'), ('Bootstrap LR rejects M11 ($p<0.05$), independent / GLS', 'boot'),
                 ('Median $\\Delta$AICc (M10 $-$ M11), independent / GLS', 'dA'), ('LOFO interior: M11 better (Wilcoxon $p$)', 'lofo_int'), ('LOFO band edges: M11 better (Wilcoxon $p$)', 'lofo_end')]:
    if col is None: v = lambda m: f"{int(m['M11_pref_AICc_nom_10-80'])} / {int(m['M11_pref_AICc_nom_20-100'])}"
    elif col == 'boot': v = lambda m: f"{int(m['bootLR_reject_nom'])} / {int(m['bootLR_reject_gls'])}"
    elif col == 'dA': v = lambda m: f"{float(m['median_dAICc_nom']):.2f} / {float(m['median_dAICc_gls']):.2f}"
    elif col.startswith('lofo'): v = lambda m, c=col: f"{int(m[c + '_M11_better'])} ({float(m[c + '_p']):.2f})"
    else: v = lambda m, c=col: f"{int(m[c])}"
    r.append(f"\\multicolumn{{4}}{{l}}{{{lab}}} & \\multicolumn{{2}}{{c}}{{{v(mk)}}} & \\multicolumn{{2}}{{c}}{{{v(ma)}}}")
r.append('\\midrule\n\\multicolumn{8}{l}{\\emph{(c) M11 descriptors, median (KK-consistent / all)}}')
dk, da = DE.loc[K], DE.loc[A]
r.append(f"\\multicolumn{{4}}{{l}}{{$R_\\infty$ ($\\Omega$); $Q$ (S\\,s$^\\alpha$); $\\alpha$; $L$ (mH)}} & \\multicolumn{{4}}{{l}}{{{dk.Rinf_ohm:.0f} / {da.Rinf_ohm:.0f}; 7.4 / 7.1 $\\times10^{{-8}}$; {dk.alpha:.2f} / {da.alpha:.2f}; {dk.L_mH:.2f} / {da.L_mH:.2f}}}")
t45 = tab(r"Circuit representation with the 12 KK-consistent spectra as the primary set and all 20 spectra as a robustness analysis. (a) Weighted-AICc screening: median NRMSE, AICc/BIC wins and mean AICc rank. (b) M10 versus M11. (c) Descriptors. In the KK-consistent spectra, M10 predicted the band-edge frequencies better than M11 in 10 of 12 spectra (Wilcoxon $p=0.05$), a hint that the Cole model extrapolates slightly better although it does not fit the band better.",
          'lccccccc', r"Model & $k$ & \multicolumn{3}{c}{KK-consistent (12): NRMSE, AICc/BIC wins, rank} & \multicolumn{3}{c}{All (20)}", r)
TN = {'T0': 'T0 series $L$', 'T1': 'T1 none, 10--80 kHz', 'T1b': 'T1b $L$, 10--80 kHz', 'T2': 'T2 linear phase', 'T3': 'T3 phase offset', 'T4': 'T4 $K(j\\omega)^\\nu$'}
rh = []
for t in ['T0', 'T1', 'T1b', 'T2', 'T3', 'T4']:
    a = HF[(HF.set == K) & (HF.treatment == t)].iloc[0]; b = HF[(HF.set == A) & (HF.treatment == t)].iloc[0]
    ex = '--' if pd.isna(a.extra_median) else f"{a.extra_median:.3g}"
    rh.append(f"{TN[t]} & {a.NRMSE:.3f} & {a.abs_d_log10_Rinf:.3f} & {a.abs_d_log10_Q:.3f} & {a.abs_d_alpha:.3f} & {ex} & {b.abs_d_log10_Q:.3f} & {b.abs_d_alpha:.3f}")
t45b = tab(r"High-frequency-correction sensitivity in the 12 KK-consistent spectra: median NRMSE and median absolute change of the M11 descriptors relative to T0; extra parameter: $L$ (H), $t_d$ ($\mu$s), $\varphi_0$ (rad) or $\nu$. Last two columns: all 20 spectra.",
           'lccccccc', r"Treatment & NRMSE & $|\Delta\log_{10}R_\infty|$ & $|\Delta\log_{10}Q|$ & $|\Delta\alpha|$ & Extra & \multicolumn{2}{c}{All 20: $|\Delta\log_{10}Q|$, $|\Delta\alpha|$}", rh)
re_ = []
for x in EM.itertuples():
    if x.parameter == 'sweeps': re_.append(f"Sweeps (recordings) & 51 (20) & 27 (12)"); continue
    re_.append(f"{ {'sigma0': '$\\sigma_0$', 'gamma': '$\\gamma$', 'rho_f': '$\\rho_f$', 'rho_ReIm': '$\\rho_{\\mathrm{RI}}$', 'ratio_Im_Re': '$\\kappa$'}[x.parameter]} & {x.published_all_51:.3f} & {x.kk_only:.3f}")
t46a = tab(r"Residual-based error model estimated from all 51 sweeps (published; used for calibration in the main text) and from the 27 sweeps of the KK-consistent recordings only. The KK-only model is close to independent errors with a larger imaginary component; the correlated structure of the published model comes mainly from KK-inconsistent recordings. $\sigma_0$ is immaterial for calibration because the covariance is rescaled to the observed RSS of each spectrum.",
            'lcc', r"Parameter & All 51 sweeps & KK-consistent only", re_)
PN = {'log10_Q': r'$\log_{10}Q$', 'alpha': r'$\alpha$', 'log10_Rinf': r'$\log_{10}R_{\infty}$'}
rc = ['\\multicolumn{6}{l}{\\emph{(a) Errors drawn from the KK-only model}}'] + [f"{PN[x.param]} & {x.nominal:.1f} & {x.calibrated_with_Sigma_KK:.1f} & {x.calibrated_with_published_Sigma:.1f} & {x.median_c_kk:.2f} & {x.median_c_pub:.2f}" for x in COV.itertuples()]
cv = pd.read_csv(T/'e1_coverage_runs_M11.csv'); cv = cv[cv.cond == 'emp']; ck = pd.read_csv(T/'e14_coverage_kkSigma.csv').groupby(['source_file', 'param']).c_kk.first()
cv['c_kk'] = [ck[(a, b)] for a, b in zip(cv.source_file, cv.param)]
rc.append('\\midrule\n\\multicolumn{6}{l}{\\emph{(b) Errors drawn from the published model (all 51 sweeps)}}')
for q in ['alpha', 'log10_Q', 'log10_Rinf']:
    g = cv[cv.param == q]; rc.append(f"{PN[q]} & {100*(g.lr_nom <= 3.84).mean():.1f} & {100*(g.lr_nom <= g.c_kk).mean():.1f} & {100*(g.lr_nom <= g.c_nom).mean():.1f} & & ")
t46b = tab(r"Coverage (\%) of nominal intervals, of intervals calibrated with the KK-only error model and of the published calibrated intervals (critical values from the model estimated from all 51 sweeps); 12 KK-consistent spectra $\times$ 100 replicates. (a) Errors drawn from the KK-only model: nominal intervals are nearly adequate and the published calibration is conservative. (b) The reverse case: errors from the published model. The choice is asymmetric: intervals calibrated with the published model stay at or above the nominal level under either error structure (93--99\%), whereas intervals calibrated with the KK-only model under-cover when the errors are correlated (78--89\%). The size of the nominal under-coverage reported in the main text is conditional on the error model.",
            'lccccc', r"Parameter & Nominal & \makecell{Calibrated,\\KK-only $\Sigma$} & \makecell{Calibrated,\\published $\Sigma$} & \makecell{Median $c^*$\\KK-only} & \makecell{Median $c^*$\\published}", rc)
rw = [f"{x.rbin} & {int(x.spectra)} & {x.pct_closed:.0f} & {x.median_W_asym_all:.2f} & {x.median_W_wald_all:.2f} & {x.pct_pred_nonident:.0f} & {x.pct_obs_nonident:.0f} & {x.agreement:.0f}" for x in WK.itertuples()]
t47 = tab(r"Closed-form criterion by $r=(f_{\min}/f_c)^{-\alpha}$ for all band-design spectra (white noise, correlated noise and linear grid), complementing Table~S30, which is restricted to closed profiles. For $r<0.1$ only 7\% of profiles closed; in that regime the predicted first-order and exact linearized (Wald) widths are many decades and correctly classify $\log_{10}\tau$ as not practically identifiable (agreement 97\%), whereas the few profiles that happened to close are much narrower than any local (Fisher) approximation, because the likelihood is far from quadratic and the closed profiles are a selected subset. The width ratios of Table~S30 for $r<0.1$ therefore reflect non-local profiles, not a failure of the expansion (whose refined form equals the Wald width). Classification errors concentrate in the transition range $r=0.3$--0.6.",
          'lccccccc', r"$r$ & Spectra & \makecell{Closed\\(\%)} & \makecell{Median first-\\order width} & \makecell{Median Wald\\width} & \makecell{Predicted not\\ident. (\%)} & \makecell{Profile not\\ident. (\%)} & \makecell{Agreement\\(\%)}", rw)
open(out, 'w').write('\n'.join([t45, t45b, t46a, t46b, t47])); print('written', out)
