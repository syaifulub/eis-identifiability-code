"""Table S30: accuracy of the first-order and refined closed-form widths (E10b)."""
import sys, pandas as pd
import r2_core as R
S = pd.read_csv(R.T/'Table_E10b_refined.csv'); B = pd.read_csv(R.T/'e10b_refined.csv')
lab = {'<0.1': '$<0.1$', '0.1-0.3': '0.1--0.3', '0.3-0.6': '0.3--0.6', '0.6-1': '0.6--1', '>1': '$>1$ ($f_c$ in band)'}
rows = '\n'.join(f"{lab[r.rbin]} & {int(r.n)} & {r.asym:.2f} & {r.refined:.2f} & {r.eta_only:.2f} \\\\" for r in S.itertuples())
ag = lambda c: 100*((B[c] < 1) == B.ident_obs).mean()
cpl = (B.W_ref/B.W_eta_only).median()
open(sys.argv[1], 'w').write(r"""\begin{table}[H]\centering
\caption{Accuracy of the closed-form width of the $\log_{10}\tau$ interval by $r=(f_{\min}/f_c)^{-\alpha}$, the bound on the relative size of the neglected terms of Eq.~(7): median ratio of predicted to profile-likelihood width (band-design spectra with closed profiles, white or correlated noise). First order: Eq.~(8). Refined: exact derivative $-wu/(1+u)^2$ and delta method for $\log\tau=(\log Q-\log\eta)/\alpha$ including the covariances with $Q$ and $\alpha$ (identical to the exact linearized width). Without coupling: refined derivative, $\eta$ variance only. Coupling with $Q$ and $\alpha$ widened the interval by a median factor of """ + f"{cpl:.2f}" + r"""; classification agreement with profile likelihood: first order """ + f"{ag('W_asym'):.1f}" + r"""\%, refined """ + f"{ag('W_ref'):.1f}" + r"""\%.}
\small
\begin{tabular}{lcccc}\toprule
$r$ & n & First order & Refined & Without coupling \\\midrule
""" + rows + r"""
\bottomrule\end{tabular}\end{table}
""")
print('ok')
