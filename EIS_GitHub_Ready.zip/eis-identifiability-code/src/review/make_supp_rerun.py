"""Tables S29 (same-environment timing) and S31 (rerun of the Table 2 benchmark in the same environment)."""
import sys, numpy as np, pandas as pd
import r2_core as R
T = R.T; RR = T.parent/'rerun_same_env'
A = pd.read_csv(T/'Table_VP_fair_timing_allruns.csv').set_index('model'); N = pd.read_csv(T/'Table_VP_fair_timing_25runs.csv').set_index(['model', 'algorithm'])
f = lambda x: 'n.r.' if not np.isfinite(x) else (f'{x:.1f}' if x < 100 else f'{x:.0f}')
rows = []
for m, lab in [('M11_RCPEL', 'M11'), ('M10_ColeL', 'M10'), ('M12_DoubleColeL', 'M12')]:
    a = A.loc[m]
    rows.append(f"{lab} & MS-TRF & {a.ms_success:.1f} & {N.loc[(m, 'MS-TRF'), 'median_nfe_to_hit']:.0f} & {f(a.ms_median_all)} ({f(a.ms_q1)}--{f(a.ms_q3)}) & \\multirow{{2}}{{*}}{{{a.vp_faster_pct:.1f}}} \\\\")
    rows.append(f" & VP-MS-TRF & {a.vp_success:.1f} & {N.loc[(m, 'VP-MS-TRF'), 'median_nfe_to_hit']:.0f} & {f(a.vp_median_all)} ({f(a.vp_q1)}--{f(a.vp_q3)}) & \\\\")
    if lab != 'M12': rows.append('\\midrule')
t29 = r"""\begin{table}[H]
\centering
\caption{Time to solution of MS-TRF and VP-MS-TRF (20 spectra $\times$ 25 runs per model), measured in the same environment as the benchmark rerun of Table~S31 (single-threaded Python~3.13, NumPy~2.5, SciPy~1.18, one core of an Intel Xeon at 2.1~GHz). Time to solution: wall-clock time until the NRMSE first came within 0.1\% of the best-known value; unsuccessful runs were counted as infinite. n.r.: not reached within 2,000 NFE. $^{a}$Among successful runs.}
\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{llcccc}
\toprule
Model & Algorithm & \makecell{Success\\(\%)} & \makecell{Median NFE to\\solution$^{a}$} & \makecell{Median time to\\solution, ms (IQR)} & \makecell{VP faster in\\paired runs (\%)} \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
"""
ALG = ['HO', 'L-SHADE', 'ASHO-LSHADE', 'MS-TRF', 'L-SHADE+TRF', 'ASHO-LSHADE+TRF', 'VP-L-SHADE', 'VP-ASHO-LSHADE', 'VP-MS-TRF', 'VP-L-SHADE+TRF', 'VP-Screen+TRF']
cols = {}; maxd = 0
for m in ['M11_RCPEL', 'M10_ColeL', 'M12_DoubleColeL']:
    o = pd.read_csv(T/f'vp_merged_{m}.csv').groupby('algorithm')[['succ_500', 'succ_2000']].mean().mul(100); n = pd.read_csv(RR/f'success_{m}.csv').set_index('algorithm').loc[o.index]
    cols[m] = (o, n); maxd = max(maxd, float((o.succ_2000 - n.s2000).abs().max()), float((o.succ_500 - n.s500).abs().max()))
rows = []
for a in ALG:
    r = [a]
    for m in ['M11_RCPEL', 'M10_ColeL', 'M12_DoubleColeL']:
        o, n = cols[m]; r += [f'{o.loc[a, "succ_2000"]:.1f}', f'{n.loc[a, "s2000"]:.1f}']
    rows.append(' & '.join(r) + ' \\\\')
t31 = r"""\begin{table}[H]
\centering
\caption{Reproducibility of the benchmark across computing environments: success rate (\%) at 2,000 NFE in the original benchmark (Table~2 of the main text) and in a complete rerun with the same seeds in the timing environment of Table~S29. Maximum absolute difference over all algorithms, models and checkpoints (500 and 2,000 NFE): """ + f'{maxd:.1f}' + r""" percentage points; no run found a value below the best-known reference. Differences arise from floating-point behaviour of different processors and library versions.}
\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lcccccc}
\toprule
 & \multicolumn{2}{c}{M11} & \multicolumn{2}{c}{M10} & \multicolumn{2}{c}{M12} \\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}
Algorithm & Original & Rerun & Original & Rerun & Original & Rerun \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
"""
fig = open(sys.argv[1]).read(); fig = fig[:fig.index('\\begin{table}')]
open(sys.argv[1], 'w').write(fig + t29); open(sys.argv[2], 'w').write(t31); print('max diff', maxd)
print(sum((pd.read_csv(RR/f'runs_{m}.csv').eval('(NRMSE-ref)/ref') < -1e-6).sum() for m in ['M11_RCPEL', 'M10_ColeL', 'M12_DoubleColeL']), 'new minima')
