"""Writes supp_round2.tex (Figs S13-S14, Tables S14-S22) from the result tables."""
import sys, json, numpy as np, pandas as pd
import r2_core as R
T = R.T; out = []
def tab(cap, cols, rows, align=None, size='\\small'):
    a = align or 'l' + 'c'*(len(cols)-1)
    s = ['\\begin{table}[H]\\centering', f'\\caption{{{cap}}}', size, f'\\begin{{tabular}}{{{a}}}\\toprule', ' & '.join(cols) + ' \\\\\\midrule']
    s += [' & '.join(str(x) for x in r) + ' \\\\' for r in rows]; s.append('\\bottomrule\\end{tabular}\\end{table}\n'); out.append('\n'.join(s))
f2 = lambda x, d=2: f'{x:.{d}f}'
out.append('\\begin{figure}[H]\\centering\\includegraphics[width=\\textwidth]{figures/Fig17_feature_stability.png}\n\\caption{Stability of fitted parameters as features for ranking the 12 KK-consistent spectra across 40 reading-level resamples. (a) Spearman correlation between rankings from different resamples (bar: median; tick: 5th percentile). (b) Share of spectrum pairs ordered identically in at least 95\\% of resamples. Red: non-identifiable Cole parameters; blue: identifiable parameters. Reading-level resampling understates within-recording variability (Table~S20).}\\end{figure}\n')
out.append('\\begin{figure}[H]\\centering\\includegraphics[width=\\textwidth]{figures/Fig08_profile_likelihood.png}\n\\caption{Nominal profile likelihood-ratio curves for all 20 spectra (one line per spectrum; dashed line: $\\chi^2_1$ threshold 3.84). Calibrated thresholds were 1.8--2 times larger (Table~S15). Flat profiles for $\\log_{10}\\tau$ and $\\log_{10}\\Delta R$ in M10 indicate practical non-identifiability.}\\end{figure}\n')
# S14 error model
E = pd.read_csv(T/'Table_E1_error_model.csv').set_index('parameter')
B = pd.read_csv(T/'Table_E1_between_sweep.csv'); naive = json.load(open(T/'E1_psi.json'))['psi']
nm = {'sigma0': '$\\sigma_0$ (relative scale, real part)', 'gamma': '$\\gamma$ (frequency trend)', 'rho_f': '$\\rho_f$ (adjacent-frequency correlation)',
      'rho_ReIm': '$\\rho_{\\mathrm{RI}}$ (real--imaginary correlation)', 'ratio_Im_Re': '$\\kappa$ (imaginary/real scale)'}
rows = []
for i, k in enumerate(nm):
    rows.append([nm[k], f'{naive[i]:.3f}', f'{E.loc[k,"naive_ci_low"]:.3f} to {E.loc[k,"naive_ci_high"]:.3f}', f'{E.loc[k,"estimate"]:.3f}', f'{E.loc[k,"ci_low"]:.3f} to {E.loc[k,"ci_high"]:.3f}'])
sh = B.residual_share_of_deviation
rows += [['Sweeps / recordings / residual df', f"{int(E.loc['sweeps_used','estimate'])} / {int(E.loc['recordings','estimate'])} / {int(E.loc['residual_df','estimate'])}", '', '', ''],
         ['Sample lag-1 correlation, real / imaginary', f"{E.loc['sample_lag1_corr_Re','estimate']:.2f} / {E.loc['sample_lag1_corr_Im','estimate']:.2f}", '', '', ''],
         ['Ledoit--Wolf shrinkage intensity', f"{E.loc['LW_shrinkage','estimate']:.2f}", '', '', ''],
         ['Share of sweep-to-sweep deviation left as residual$^{a}$', f'{sh.median():.2f}', f'IQR {sh.quantile(.25):.2f}--{sh.quantile(.75):.2f}', '', '']]
tab('Empirical error model (Eq.~(5) of the main text) estimated from the R--CPE--L residuals of the 51 complete sweeps; 95\\% intervals from resampling recordings. Residual-based: residual vectors treated as errors (used for calibration). Projection-corrected: likelihood evaluated in the 16-dimensional residual space of each sweep, which accounts for the projection of errors by the fit; it is weakly identified, because a smooth error component that lies in the model tangent space is absorbed by the parameters and leaves no trace in the residuals (Table~S24). $^{a}$Mean RSS of the sweep fits divided by the mean squared deviation of sweeps from the recording mean (12 recordings with $\\geq2$ sweeps).',
    ['Quantity', '\\makecell{Residual-based\\\\estimate}', '95\\% interval', '\\makecell{Projection-\\\\corrected}', '95\\% interval'], rows, 'lcccc', '\\footnotesize')
# S15 coverage
C = pd.read_csv(T/'Table_E1_coverage.csv'); cn = {'emp': 'Empirical $\\Sigma$', 'rho_lo': '$\\rho_f-0.2$', 'rho_hi': '$\\rho_f+0.2$', 'white': 'White', 'ar1': 'AR(1), $\\rho=0.6$'}
Cv = pd.read_csv(T/'e1_coverage_runs_M11.csv'); mis = Cv[Cv.cond == 'mis']
rows = []
for c, cl in list(cn.items()) + [('mis', 'Misspecified (Cole truth)')]:
    for p, pl in [('log10_Q', '$\\log_{10}Q$'), ('alpha', '$\\alpha$'), ('log10_Rinf', '$\\log_{10}R_\\infty$')]:
        if c == 'mis':
            d = mis[mis.param == p]; v = [100*(d.lr_nom <= 3.84).mean(), 100*(d.lr_nom <= d.c_nom).mean(), 100*(d.lr_gls <= 3.84).mean(), 100*(d.lr_gls <= d.c_gls).mean()]
        else:
            d = C[(C.cond == c) & (C.param == p)].set_index('method').coverage; v = [d['Nominal $\\chi^2$'], d['Calibrated'], d['GLS $\\chi^2$'], d['GLS calibrated']]
        rows.append([cl if p == 'log10_Q' else '', pl] + [f'{x:.1f}' for x in v])
DB = pd.read_csv(T/'e1_coverage_runs_DB.csv'); M10 = pd.read_csv(T/'e1_coverage_runs_M10.csv')
for p, pl in [('log10_Q', '$\\log_{10}Q$'), ('alpha', '$\\alpha$')]:
    d = DB[DB.param == p]; rows.append(['Double bootstrap$^{a}$' if p == 'log10_Q' else '', pl, f'{100*(d.lr_nom<=3.84).mean():.1f}', f'{100*(d.lr_nom<=d.c_nom).mean():.1f}', f'{100*(d.lr_gls<=3.84).mean():.1f}', f'{100*(d.lr_gls<=d.c_gls).mean():.1f}'])
rows.append(['M10, Cole truth$^{b}$', '$\\log_{10}\\tau$', f'{100*(M10.lr_nom<=3.84).mean():.1f}', f'{100*(M10.lr_nom<=M10.c_nom).mean():.1f}', f'{100*(M10.lr_gls<=3.84).mean():.1f}', f'{100*(M10.lr_gls<=M10.c_gls).mean():.1f}'])
cs = pd.concat([pd.read_csv(T/'e1_cstar_M11.csv'), pd.read_csv(T/'e1_cstar_M10.csv')]).groupby(['objective', 'param']).c_star.median()
tab('Coverage (\\%) of 95\\% profile-likelihood intervals for the R--CPE--L descriptors (12 KK-consistent spectra $\\times$ 100 replicates per condition; cluster-bootstrap 95\\% intervals over spectra for the empirical-$\\Sigma$ rows: nominal 78.8--86.0, calibrated 90.9--95.5, GLS 89.3--93.7, GLS calibrated 90.5--96.4). Nominal: $\\chi^2_1$ threshold 3.84; calibrated: parametric-bootstrap critical value (200 replicates) under the empirical $\\Sigma$; GLS: generalized least squares with the empirical $\\Sigma$. Misspecified: Cole data with $f_c$ 200~Hz--3~kHz sharing the M11 high-frequency asymptote. $^{a}$Critical values recomputed at each replicate\'s own estimate (25 replicates $\\times$ 80 inner replicates per spectrum). $^{b}$Cole truth with $f_c$ below the band, empirical $\\Sigma$, 50 replicates per spectrum. ' +
    f"Median critical values: independent likelihood {cs[('nom','log10_Q')]:.1f} ($\\log_{{10}}Q$), {cs[('nom','alpha')]:.1f} ($\\alpha$), {cs[('nom','log10_Rinf')]:.1f} ($\\log_{{10}}R_\\infty$), {cs[('nom','log10_tau')]:.1f} ($\\log_{{10}}\\tau$), {cs[('nom','log10_dR')]:.1f} ($\\log_{{10}}\\Delta R$); GLS {cs[('gls','log10_Q')]:.1f}, {cs[('gls','alpha')]:.1f}, {cs[('gls','log10_Rinf')]:.1f}, {cs[('gls','log10_tau')]:.1f}, {cs[('gls','log10_dR')]:.1f}.",
    ['Condition', 'Parameter', 'Nominal', 'Calibrated', 'GLS', 'GLS calibrated'], rows, 'llcccc', '\\footnotesize')
# S16 measured intervals: procedures x thresholds + bounds
I = pd.concat([pd.read_csv(T/'e1_intervals_M11.csv'), pd.read_csv(T/'e1_intervals_M10.csv')]); rows = []
pl = {'log10_tau': 'M10 $\\log_{10}\\tau$', 'log10_dR': 'M10 $\\log_{10}\\Delta R$', 'log10_Rinf': 'M11 $\\log_{10}R_\\infty$', 'log10_Q': 'M11 $\\log_{10}Q$', 'alpha': 'M11 $\\alpha$'}
for p in pl:
    for o, t, lab in [('nom', 'chi2', 'Nominal'), ('nom', 'cal', 'Calibrated'), ('gls', 'chi2', 'GLS'), ('gls', 'cal', 'GLS calibrated')]:
        g = I[(I.param == p) & (I.objective == o) & (I.threshold == t)]; r = [pl[p] if lab == 'Nominal' else '', lab, int(g.closed.sum())]
        for lg, la in [(0.5, 0.1), (1.0, 0.2), (1.5, 0.3)]:
            lim = la if p == 'alpha' else lg; idd = g.closed & (g.width < lim); r.append(f'{int(idd.sum())} / {int(idd[g.kk_ok].sum())}')
        r.append(f'{g.width.median():.3f}'); rows.append(r)
Bd = pd.read_csv(T/'Table_E4_bounds.csv')
for p in ['log10_Q', 'alpha']:
    for t, lab in [('chi2', 'Nominal'), ('cal', 'Calibrated')]:
        b = Bd[(Bd.param == p) & (Bd.interval == t)].iloc[0]
        rows.append([pl[p] + ', wider bounds$^{a}$' if t == 'chi2' else '', lab, '', '', f'{int(b.ident_all)} / {int(b.ident_kk_ok)}', '', f'{b.median_width:.3f}'])
tab('Measured 95\\% profile intervals (20 spectra) by procedure: number closed within the bounds, number practically identifiable (all / 12 KK-consistent) at width thresholds of 0.5, 1.0 and 1.5 decades for $\\log_{10}$ parameters (0.1, 0.2 and 0.3 for $\\alpha$), and median width. $^{a}$$\\alpha\\in[0.2,1]$ and $1/Q\\in[10^{-2},10^{14}]$ (default $[0.3,1]$ and $[1,10^{12}]$), 1.0-decade threshold.',
    ['Parameter', 'Procedure', 'Closed', '0.5 (0.1)', '1.0 (0.2)', '1.5 (0.3)', 'Median width'], rows, 'llccccc', '\\footnotesize')
# S17 bias
Bi = pd.read_csv(T/'Table_E1b_bias.csv')
tab('Bias of the R--CPE--L descriptors when the data are a noise-free Cole dispersion sharing the same high-frequency asymptote (12 KK-consistent spectra; median over spectra). Bias = fitted value minus asymptotic value.',
    ['$f_c$ (Hz)', '$f_{\\min}/f_c$', '$\\log_{10}Q$', '$\\alpha$', '$\\log_{10}R_\\infty$'],
    [[int(r.fc_hz), f'{r.fmin_over_fc:.0f}', f'{r.bias_log10_Q:.3f}', f'{r.bias_alpha:.3f}', f'{r.bias_log10_Rinf:.3f}'] for r in Bi.itertuples()], 'ccccc')
# S18 HF treatments
H = pd.read_csv(T/'Table_E2_hf_treatments.csv').set_index('treatment')
lab = {'T0': 'Series $L$ (published), 10--100~kHz', 'T1': 'No correction, 10--80~kHz', 'T1b': 'Series $L$, 10--80~kHz', 'T2': 'Pure delay $e^{-j\\omega t_d}$',
       'T3': 'Constant phase offset $e^{j\\varphi_0}$', 'T4': 'Generalized term $K(j\\omega)^{\\nu}$'}
ex = {'T0': '$L$ (mH)', 'T1': '', 'T1b': '$L$ (mH)', 'T2': '$t_d$ ($\\mu$s)', 'T3': '$\\varphi_0$ (rad)', 'T4': '$\\nu$'}
D2 = pd.read_csv(T/'e2_hf_runs.csv'); rows = []
for k in lab:
    d = D2[D2.treatment == k]; q = lambda x, dd=3: f'{np.median(x):.{dd}f} [{np.quantile(x,.25):.{dd}f}, {np.quantile(x,.75):.{dd}f}]'
    e = d.extra*1e3 if k in ('T0', 'T1b') else d.extra
    rows.append([lab[k], q(d.NRMSE), q(d.d_log10_Q.abs()), q(d.d_alpha.abs()), q(d.d_log10_Rinf.abs()), (ex[k] + ' ' + q(e, 2)) if ex[k] else '--', int(H.loc[k, 'AICc_best_count']) if k not in ('T1', 'T1b') else '--'])
tab('Sensitivity of the R--CPE--L descriptors to the treatment of the high-frequency correction (20 spectra; median [interquartile range]). $\\Delta$: absolute difference from the published fit. AICc best: number of spectra in which the treatment had the lowest AICc among full-band treatments.',
    ['Treatment', 'NRMSE', '$|\\Delta\\log_{10}Q|$', '$|\\Delta\\alpha|$', '$|\\Delta\\log_{10}R_\\infty|$', 'Correction parameter', 'AICc best'], rows, 'p{2.6cm}cccccc', '\\scriptsize\\setlength{\\tabcolsep}{3pt}')
# S19 model selection
M = pd.read_csv(T/'Table_E3_model_selection.csv', index_col=0).iloc[:, 0]
rows = [['AICc, independent likelihood: 10--100 / 10--80 / 20--100~kHz', f"{int(M['M11_pref_AICc_nom_10-100'])} / {int(M['M11_pref_AICc_nom_10-80'])} / {int(M['M11_pref_AICc_nom_20-100'])}"],
        ['AICc, GLS likelihood: 10--100 / 10--80 / 20--100~kHz', f"{int(M['M11_pref_AICc_gls_10-100'])} / {int(M['M11_pref_AICc_gls_10-80'])} / {int(M['M11_pref_AICc_gls_20-100'])}"],
        ['Bootstrap LR test rejects M11 ($p<0.05$): independent / GLS', f"{int(M['bootLR_reject_M11_nom'])} / {int(M['bootLR_reject_M11_gls'])} (median $p$ {M['median_p_boot_nom']:.2f} / {M['median_p_boot_gls']:.2f})"],
        ['LOFO, interior 20--90~kHz: M11 better; medians M11 vs M10', f"{int(M['lofo_int_M11_better'])}; {M['lofo_int_median_M11']:.4f} vs {M['lofo_int_median_M10']:.4f} ($p={M['lofo_int_wilcoxon_p']:.2f}$)"],
        ['LOFO, band edges 10 and 100~kHz: M11 better; medians M11 vs M10', f"{int(M['lofo_end_M11_better'])}; {M['lofo_end_median_M11']:.4f} vs {M['lofo_end_median_M10']:.4f} ($p={M['lofo_end_wilcoxon_p']:.2f}$)"]]
tab('Uncertainty-aware comparison of M11 (R--CPE--L) and M10 (Cole+L) (number of spectra out of 20 preferring M11 unless stated). Bootstrap LR: 100 parametric-bootstrap replicates from the fitted M11 with the empirical $\\Sigma$. LOFO: leave-one-frequency-out relative prediction error; $p$: Wilcoxon signed-rank test.',
    ['Criterion', 'Result'], rows, 'p{8.2cm}l')
# S20 sweep repeatability
S7 = pd.read_csv(T/'Table_E7_sweep_repeatability.csv'); rr = pd.read_csv(T/'Table_repeatability_KKconsistent.csv')
rmap = {'M10_log10_tau': ('M10_ColeL', 'logtau'), 'M10_log10_dR': ('M10_ColeL', 'logdR'), 'M10_log10_Rinf': ('M10_ColeL', 'logRinf'), 'M10_alpha': ('M10_ColeL', 'alpha'),
        'M11_log10_Q': ('M11_RCPEL', 'logQ'), 'M11_alpha': ('M11_RCPEL', 'alpha'), 'M11_log10_Rinf': ('M11_RCPEL', 'logRinf')}
plab = {'M10_log10_tau': 'M10 $\\log_{10}\\tau$', 'M10_log10_dR': 'M10 $\\log_{10}\\Delta R$', 'M10_log10_Rinf': 'M10 $\\log_{10}R_\\infty$', 'M10_alpha': 'M10 $\\alpha$',
        'M11_log10_Q': 'M11 $\\log_{10}Q$', 'M11_alpha': 'M11 $\\alpha$', 'M11_log10_Rinf': 'M11 $\\log_{10}R_\\infty$'}
rows = []
for p in plab:
    a = S7[(S7.param == p) & (S7.kk_ok == 'True')].median_between_sweep_sd.iloc[0]; b = S7[(S7.param == p) & (S7.kk_ok == 'False')].median_between_sweep_sd.iloc[0]
    ic = pd.read_csv(T/'Table_E9_icc_ci.csv').set_index('param').loc[p]; m, n = rmap[p]; q = rr[(rr.model == m) & (rr.parameter == n)].iloc[0]
    rows.append([plab[p], f'{a:.3f}', f'{b:.3f}', f'{ic.ICC:.2f} [{ic.ci_low:.2f}, {ic.ci_high:.2f}]', f'{q.median_within_SD:.3f}', f'{q.ICC:.2f}'])
tab('Sweep-level repeatability (complete sweeps refitted by global VarPro; six KK-consistent and six KK-inconsistent recordings with $\\geq2$ sweeps) compared with the earlier reading-level resampling (12 KK-consistent spectra, 40 resamples). SD: median within-recording standard deviation; ICC: one-way intraclass correlation over the KK-consistent recordings with 95\\% interval from 2,000 resamples of recordings; with six recordings the sweep ICCs are imprecise.',
    ['Parameter', '\\makecell{Sweep SD\\\\KK-consistent}', '\\makecell{Sweep SD\\\\KK-inconsistent}', '\\makecell{Sweep ICC\\\\{[}95\\% CI{]}}', '\\makecell{Reading-level\\\\SD}', '\\makecell{Reading-level\\\\ICC}'], rows, 'lccccc', '\\footnotesize')
# S21 band factorial
F = pd.read_csv(T/'Table_E5_band_factorial.csv'); dl = {'base': 'Log grid, white', 'linear': 'Linear grid, white', 'corr': 'Log grid, correlated', 'ep10': 'Electrode pol. 10\\%', 'ep50': 'Electrode pol. 50\\%', 'mis': 'Model mismatch'}
rows = []
for (d, N), g in F.groupby(['design', 'N'], sort=False):
    for fc, fl in [('near', '10--30'), ('mid', '1--10'), ('low', '0.1--1')]:
        h = g[g.fc_class == fc].set_index('fmin_hz').tau_ident_pct
        rows.append([f'{dl[d]}, $N={N}$' if fc == 'near' else '', fl] + [f'{h[x]:.0f}' for x in [10000.0, 3000.0, 1000.0, 300.0]])
tab('Frequency-band design: percentage of synthetic spectra (20 per cell; 2.5\\% noise) in which $\\log_{10}\\tau$ was practically identifiable (nominal 95\\% profile interval closed and narrower than one decade), by design, $f_c$ class and lower band limit ($f_{\\max}=100$~kHz; $N$ frequencies at every $f_{\\min}$).',
    ['Design', '$f_c$ (kHz)', '10~kHz', '3~kHz', '1~kHz', '300~Hz'], rows, 'llcccc', '\\footnotesize')
Rn = pd.read_csv(T/'Table_E5_ratio.csv'); Rc = pd.read_csv(T/'Table_E5_ratio_cal.csv'); bins = ['<0.3', '0.3-1', '1-3', '3-10', '>10']; rows = []
for (rn, rc) in zip(Rn.itertuples(index=False), Rc.itertuples(index=False)):
    dn = rn._asdict(); dc = rc._asdict(); keys = list(dn.keys())
    rows.append([f"{dl[dn['design']]}, $N={dn['N']}$"] + [f"{dn[k]:.0f} / {dc[k]:.0f}" for k in keys[2:]])
tab('Practical identifiability of $\\log_{10}\\tau$ (\\%) by $f_{\\min}/f_c$, pooled over $f_c$ classes, with the nominal threshold (3.84) / the median calibrated critical value of $\\log_{10}\\tau$ (6.38; Table~S15).',
    ['Design'] + ['$<0.3$', '0.3--1', '1--3', '3--10', '$>10$'], rows, 'lccccc', '\\footnotesize')
# S22 mechanism
Mm = pd.read_csv(T/'Table_E6_mechanism.csv')
rows = [[('M10' if 'M10' in r.model else 'M12'), int(r.runs), f'{r._3:.0f}', f'{r._4:.0f}', f'{r._5:.0f}', f'{r.median_cond_full:.0f}', f'{r.median_cond_reduced:.0f}'] for r in Mm.itertuples()]
tab('Mechanism of the VarPro gain: success (\\%) at 2,000 NFE in the same runs (20 spectra $\\times$ 10 seeds) for full-parameter MS-TRF, VP-MS-TRF and VPinit-MS-TRF (full-parameter TRF started from VarPro-optimal linear coefficients), and median condition number of the full and reduced residual Jacobians at the best-known solutions.',
    ['Model', 'Runs', 'MS-TRF', 'VP-MS-TRF', 'VPinit-MS-TRF', '$\\kappa$ full', '$\\kappa$ reduced'], rows, 'lcccccc')
SA = pd.read_csv(T/'Table_E8_scenario.csv').set_index('scenario'); SB = pd.read_csv(T/'Table_E8_cross_sweep.csv')
obs = pd.read_csv(T/'e8_scenario_runs.csv').dropna(subset=['obs_sweep_sd_log10_Q']).groupby('scenario')[['obs_sweep_sd_log10_Q', 'obs_sweep_sd_alpha', 'obs_sweep_sd_log10_Rinf']].median().iloc[0]
rows = []
for sc, lab in [('residual-based', 'Residual-based (used)'), ('projection-corrected', 'Projection-corrected')]:
    r = SA.loc[sc]; rows.append([lab] + [f"{r['sd_'+p]:.3f} ({int(r['implied_gt_observed_'+p])}/6)" for p in ['log10_Q', 'alpha', 'log10_Rinf']] + [f"{r['cov_'+p]:.0f}" for p in ['log10_Q', 'alpha', 'log10_Rinf']])
rows.append(['Observed between-sweep SD$^{a}$'] + [f"{obs['obs_sweep_sd_'+p]:.3f}" for p in ['log10_Q', 'alpha', 'log10_Rinf']] + ['', '', ''])
for r in SB.itertuples():
    rows.append([f"Cross-sweep agreement$^{{b}}$, {'KK-consistent' if r.kk_ok else 'KK-inconsistent'} ({r.pairs} pairs)"] + [f"{getattr(r, 'nom_'+p+'_pct'):.0f} / {getattr(r, 'cal_'+p+'_pct'):.0f}" for p in ['log10_Q', 'alpha', 'log10_Rinf']] + ['', '', ''])
tab('Checks of the error model that do not rely on residuals alone (KK-consistent spectra unless stated). Upper rows: errors simulated under each covariance, scaled so that the expected residual sum of squares equals the observed one (100 replicates per spectrum): median implied SD of the fitted descriptor (number of the six recordings with repeated sweeps in which it exceeds the observed between-sweep SD) and coverage (\\%) of the calibrated intervals. $^{a}$Median over the six recordings; includes drift and is therefore an upper bound for noise-induced variability. $^{b}$Percentage of pairs of sweeps of the same recording whose estimates differ by less than $\\sqrt{h_i^2+h_j^2}$, $h$ the interval half-width, with nominal / calibrated intervals; about 95\\% is expected for calibrated intervals without drift.',
    ['', '$\\log_{10}Q$', '$\\alpha$', '$\\log_{10}R_\\infty$', '\\makecell{Cov.\\\\$\\log_{10}Q$}', '\\makecell{Cov.\\\\$\\alpha$}', '\\makecell{Cov.\\\\$\\log_{10}R_\\infty$}'], rows, 'p{4.6cm}cccccc', '\\scriptsize')

# S15 figure: f_c coverage (moved from main text)
out.append('\\begin{figure}[H]\\centering\\includegraphics[width=0.85\\textwidth]{figures/Fig09_fc_band_coverage.png}\n\\caption{M10 estimates of the characteristic frequency $f_c$ with nominal 95\\% profile-likelihood intervals relative to the measured band (shaded). Intervals extending to the left edge reach the search bound and are unbounded.}\\end{figure}\n')
# S25 asymptotic criterion: synthetic validation and bias
SA = pd.read_csv(T/'Table_E10_synthetic.csv'); dn = {'base': 'Log grid, white', 'linear': 'Linear grid, white', 'corr': 'Correlated noise', 'ep10': 'Electrode pol. 10\\%', 'ep50': 'Electrode pol. 50\\%', 'mis': 'Model mismatch'}
rows = [[dn[r.design], int(r.n), f'{r.agree_asym_pct:.1f}', f'{r.agree_wald_pct:.1f}', f'{r.false_ident_pct:.1f}', f'{r.missed_ident_pct:.1f}', f'{r.spearman_asym_prof:.2f}', f'{r.median_ratio_asym_prof:.2f}'] for r in SA.itertuples()]
A10 = pd.read_csv(T/'e10_synthetic.csv'); g = A10[A10.design.isin(['base', 'linear']) & A10.closed].copy()
g['bin'] = pd.cut(g.ratio, [0, 1, 3, 10, 1e4], labels=['$<1$', '1--3', '3--10', '$>10$'])
bb = g.groupby('bin', observed=True).apply(lambda h: (len(h), float(np.median(h.W_asym/h.W_prof)), float(np.median(h.W_wald/h.W_prof))), include_groups=False)
note = '; '.join(f'{k}: {v[1]:.2f} / {v[2]:.2f} (n = {v[0]})' for k, v in bb.items())
gm = A10[A10.design == 'base'].groupby('fmin_hz').Gamma.median()
tab('Validation of Eqs.~(8)--(9) on the band-design spectra (practical identifiability of $\\log_{10}\\tau$: closed profile interval narrower than one decade). Agreement: percentage of spectrum--band combinations classified identically by the closed-form width (Eq.~(8)) or the exact linearized (Wald) width and by profile likelihood; false/missed: predicted identifiable but not observed / the reverse. Spearman and ratio: closed profiles only. Median ratio of predicted (Eq.~(8) / Wald) to profile width by $f_{\\min}/f_c$, white-noise designs: ' + note + '. Median $\\Gamma$ (white log grid) for $f_{\\min}$ of 10, 3, 1 and 0.3~kHz: ' + ', '.join(f'{gm[x]:.1f}' for x in [10000.0, 3000.0, 1000.0, 300.0]) + '.',
    ['Design', 'n', '\\makecell{Agreement\\\\Eq.~(8) (\\%)}', '\\makecell{Agreement\\\\Wald (\\%)}', '\\makecell{False\\\\(\\%)}', '\\makecell{Missed\\\\(\\%)}', 'Spearman', '\\makecell{Median\\\\ratio}'], rows, 'lccccccc', '\\footnotesize')
Bz = pd.read_csv(T/'Table_E10_bias.csv')
rows = [[f'{r.fmin_over_fc:.0f}', f'{r.bias_logQ_num:.3f}', f'{r.bias_logQ_formula:.3f}', f'{r.bias_alpha_num:.3f}', f'{r.bias_alpha_formula:.3f}'] for r in Bz.itertuples()]
Bc = pd.read_csv(T/'e10_bias.csv')
tab(f'Bias of the R--CPE--L descriptors fitted to Cole spectra: numerical refits (Table~S17) and Eq.~(10) (median over the 12 KK-consistent spectra). Median coefficients: $b_Q={Bc.bQ.median():.2f}$ decades and $b_\\alpha={Bc.balpha.median():.2f}$ per unit $(f_{{\\min}}/f_c)^{{-\\alpha}}$.',
    ['$f_{\\min}/f_c$', '$\\log_{10}Q$ refit', '$\\log_{10}Q$ Eq.~(10)', '$\\alpha$ refit', '$\\alpha$ Eq.~(10)'], rows, 'ccccc')
# S26 measured criterion
Mm = pd.read_csv(T/'Table_E10_measured.csv')
fm = lambda x: f'{x:.0f}' if x < 1e5 else '$>10^5$'
rows = [[r.tissue + ('' if r.kk_ok else '$^{\\dagger}$'), f'{r.sigma:.3f}', f'{r.alpha:.2f}', f'{r.Gamma:.2f}', fm(r.fc_detect_hz), fm(r.fc_detect_cal_hz), fm(r.fc_hat_hz), fm(r.fc_ci_high_hz), f'{min(r.W_asym_at_fchat, 999):.2f}', f'{r.W_prof:.2f}', ('yes' if r.ident_pred else 'no') + ' / ' + ('yes' if r.ident_obs else 'no')] for r in Mm.itertuples()]
tab('Closed-form band criterion applied to the 20 measured spectra. $\\sigma$: residual SD per stacked relative component (Cole+L); $\\Gamma$: Eq.~(9) with $W^*=1$ decade; detection limit $f_{\\min}/\\Gamma$ (Hz) with $z=1.96$ and with the calibrated critical value; $\\hat f_c$ and upper 95\\% bound of $f_c$ (Hz) from the nominal profile; widths (decades) of the $\\log_{10}\\tau$ interval predicted by Eq.~(8) at $\\hat f_c$ and from the profile; identifiable predicted / observed. $^{\\dagger}$KK-inconsistent.',
    ['Tissue', '$\\sigma$', '$\\alpha$', '$\\Gamma$', '$f_c^*$', '$f_c^*$ cal.', '$\\hat f_c$', '$f_c$ upper', '$W$ Eq.~(8)', '$W$ profile', 'Ident.'], rows, 'lcccccccccc', '\\scriptsize\\setlength{\\tabcolsep}{3pt}')
# S27 drift decomposition
Dd = pd.read_csv(T/'Table_E11_drift.csv'); Pb = pd.read_csv(T/'Table_E11b_drift_ci.csv').set_index(['kk_ok', 'param']); pn = {'log10_Q': '$\\log_{10}Q$', 'alpha': '$\\alpha$', 'log10_Rinf': '$\\log_{10}R_\\infty$'}
rows = []
for r in Dd.itertuples():
    b = Pb.loc[(r.kk_ok, r.param)]; sc = (0.05, 0.2) if r.param != 'alpha' else (0.01, 0.05)
    prof = f'[{b.ci2_low:.3f}, {b.ci2_high:.3f}]' if b.tau_hat > 0 else f'$\\leq${b.upper95_onesided:.3f}'
    bay = f'{b[f"post_upper95_s{sc[0]}"]:.3f} / {b[f"post_upper95_s{sc[1]}"]:.3f}'
    rows.append([('KK-consistent' if r.kk_ok else 'KK-inconsistent') if r.param == 'log10_Q' else '', pn[r.param], f'{r.sweeps}', f'{r.median_fit_se:.4f}', f'{r.tau_drift:.4f}', prof, bay, f'{r.fit_halfwidth:.3f}', f'{r.reproducibility_halfwidth:.3f}'])
tab('Separation of fitting uncertainty and between-sweep drift (six recordings with $\\geq2$ sweeps in each group; REML). $s$: median fitting standard error (calibrated half-width/1.96); $\\tau_d$: drift SD with its 95\\% profile-likelihood interval (one-sided upper bound when $\\hat\\tau_d=0$, reference 2.71) and the 95\\% posterior upper bound under half-normal priors (scale 0.05 / 0.2 decade for $\\log_{10}$ parameters, 0.01 / 0.05 for $\\alpha$); half-widths: fitting $1.96s$ and reproducibility $1.96\\sqrt{s^2+\\tau_d^2}$.',
    ['Group', 'Parameter', 'Sweeps', '$s$', '$\\hat\\tau_d$', '\\makecell{Profile\\\\95\\% interval}', '\\makecell{Posterior\\\\upper 95\\%}', '\\makecell{Fitting\\\\half-width}', '\\makecell{Reprod.\\\\half-width}'], rows, 'llccccccc', '\\scriptsize\\setlength{\\tabcolsep}{3pt}')

open(sys.argv[1], 'w').write('\n'.join(out)); print('written', len(out))
