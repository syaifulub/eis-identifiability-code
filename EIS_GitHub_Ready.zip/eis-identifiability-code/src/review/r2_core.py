"""r2_core.py - shared engine for the second-round reanalyses (Experiments E1-E6).

Generic bounded variable projection with an optional whitening matrix (generalised least squares).
Residual vector: r = W [Re(e); Im(e)], e_k = (Z_model(w_k) - Z_k) / max(|Z_k|, 1).
W = I gives the published (independent, relatively weighted) objective; W = chol(Sigma)^-1 gives GLS.
For fixed nonlinear parameters the inner problem stays a box-constrained linear LS, so VarPro is exact.
"""
import math, glob, sys
import numpy as np, pandas as pd
from pathlib import Path
from scipy.optimize import least_squares, minimize_scalar
ROOT = Path(__file__).resolve().parents[2]; T = ROOT/'results'/'tables'
sys.path.insert(0, str(ROOT/'eisvarpro'))
from eisvarpro.core import bounded_lstsq

def _jw(w): return 1j*w
MODELS = {
    # name: nl names, nl lo, nl hi, lin names, lin lo, lin hi, basis(eta, w)
    'cole_l': (['log10_tau', 'alpha'], [-7.0, 0.30], [1.0, 1.0], ['Rinf', 'dR', 'L'], [1e-3, 1e-3, 1e-9], [1e7, 1e8, 1.0],
               lambda e, w: np.column_stack([np.ones_like(w)+0j, 1/(1 + (_jw(w)*10**e[0])**e[1]), _jw(w)])),
    'rcpe_l': (['alpha'], [0.30], [1.0], ['Rinf', 'invQ', 'L'], [1e-3, 1.0, 1e-9], [1e7, 1e12, 1.0],
               lambda e, w: np.column_stack([np.ones_like(w)+0j, _jw(w)**(-e[0]), _jw(w)])),
    'rcpe': (['alpha'], [0.30], [1.0], ['Rinf', 'invQ'], [1e-3, 1.0], [1e7, 1e12],
             lambda e, w: np.column_stack([np.ones_like(w)+0j, _jw(w)**(-e[0])])),
    # pure delay (equivalently a phase error linear in frequency): Z = Z_RCPE exp(-j w t_d), t_d in microseconds (signed)
    'rcpe_delay': (['alpha', 'td_us'], [0.30, -5.0], [1.0, 5.0], ['Rinf', 'invQ'], [1e-3, 1.0], [1e7, 1e12],
                   lambda e, w: np.column_stack([np.ones_like(w)+0j, _jw(w)**(-e[0])])*np.exp(-1j*w*e[1]*1e-6)[:, None]),
    # frequency-independent phase offset: Z = Z_RCPE exp(j phi0)
    'rcpe_phase': (['alpha', 'phi0'], [0.30, -0.8], [1.0, 0.8], ['Rinf', 'invQ'], [1e-3, 1.0], [1e7, 1e12],
                   lambda e, w: np.column_stack([np.ones_like(w)+0j, _jw(w)**(-e[0])])*np.exp(1j*e[1])),
    # generalised high-frequency CPE-type term K (j w)^nu (nu = 1 recovers the series inductance)
    'rcpe_hfcpe': (['alpha', 'nu'], [0.30, 0.30], [1.0, 1.0], ['Rinf', 'invQ', 'K'], [1e-3, 1.0, 1e-12], [1e7, 1e12, 1e6],
                   lambda e, w: np.column_stack([np.ones_like(w)+0j, _jw(w)**(-e[0]), _jw(w)**e[1]])),
}
def spec_of(name):
    nl, lo, hi, lin, llo, lhi, B = MODELS[name]
    return dict(nl=nl, lo=np.array(lo, float), hi=np.array(hi, float), lin=lin, llo=np.array(llo, float), lhi=np.array(lhi, float), basis=B)

class VP:
    def __init__(self, model, f, Z, W=None, fix=None):
        self.model = model; self.sp = spec_of(model); self.w = 2*np.pi*np.asarray(f, float); self.Z = np.asarray(Z, complex)
        self.N = len(self.w); self.n = 2*self.N; self.wt = 1/np.maximum(np.abs(self.Z), 1.0)
        self.W = np.eye(self.n) if W is None else W; zw = self.Z*self.wt; self.b = self.W @ np.r_[zw.real, zw.imag]; self.fix = fix
    def _sys(self, eta):
        A = self.sp['basis'](eta, self.w)*self.wt[:, None]; A = self.W @ np.vstack([A.real, A.imag]); b = self.b
        lb, ub = self.sp['llo'], self.sp['lhi']
        if self.fix is not None:
            j, v = self.fix; keep = [i for i in range(A.shape[1]) if i != j]
            return A[:, keep], b - A[:, j]*v, lb[keep], ub[keep], keep
        return A, b, lb, ub, list(range(A.shape[1]))
    def coef(self, eta):
        A, b, lb, ub, keep = self._sys(np.asarray(eta, float)); c, rss = bounded_lstsq(A, b, lb, ub)
        if self.fix is not None:
            full = np.empty(len(keep)+1); full[keep] = c; full[self.fix[0]] = self.fix[1]; c = full
        return c, rss
    def rss(self, eta): return self.coef(eta)[1]
    def residual(self, eta):
        A, b, lb, ub, _ = self._sys(np.asarray(eta, float)); c, _ = bounded_lstsq(A, b, lb, ub); return A @ c - b

def gmin(vp, fixed_nl=None, n1=61, grid2=(25, 13), polish=3):
    lo, hi = vp.sp['lo'], vp.sp['hi']; D = len(lo); free = [i for i in range(D) if not (fixed_nl and i == fixed_nl[0])]
    def full(u):
        e = np.empty(D); e[free] = u
        if fixed_nl: e[fixed_nl[0]] = fixed_nl[1]
        return e
    if not free:
        e = full([]); return vp.rss(e), e
    if len(free) == 1:
        i = free[0]; g = np.linspace(lo[i], hi[i], n1); v = np.array([vp.rss(full([x])) for x in g]); k = int(v.argmin())
        r = minimize_scalar(lambda x: vp.rss(full([x])), bounds=(g[max(0, k-1)], g[min(n1-1, k+1)]), method='bounded', options={'xatol': 1e-7})
        return (r.fun, full([r.x])) if r.fun < v[k] else (v[k], full([g[k]]))
    g0 = np.linspace(lo[free[0]], hi[free[0]], grid2[0]); g1 = np.linspace(lo[free[1]], hi[free[1]], grid2[1])
    P = np.array([[a, b] for a in g0 for b in g1]); v = np.array([vp.rss(full(p)) for p in P]); best, be = v.min(), full(P[int(v.argmin())])
    for k in np.argsort(v)[:polish]:
        r = least_squares(lambda u: vp.residual(full(u)), P[k], bounds=(lo[free], hi[free]), xtol=1e-10, ftol=1e-12, gtol=1e-12, max_nfev=200)
        if 2*r.cost < best: best, be = 2*r.cost, full(r.x)
    return best, be

def fit(model, f, Z, W=None):
    vp = VP(model, f, Z, W); rss, eta = gmin(vp); c, _ = vp.coef(eta); sp = vp.sp
    p = dict(zip(sp['nl'], eta)); p.update(dict(zip(sp['lin'], c)))
    if 'invQ' in p: p['Q'] = 1/p['invQ']
    return dict(params=p, eta=eta, c=c, rss=rss, n=vp.n, k=len(sp['nl'])+len(sp['lin']))

def predict(model, p, f):
    sp = spec_of(model); w = 2*np.pi*np.asarray(f, float); eta = [p[k] for k in sp['nl']]; c = np.array([p[k] for k in sp['lin']])
    return sp['basis'](eta, w) @ c

# --- parameter handling for profiles: parameter -> (kind, index, transform)
def _locate(model, param):
    sp = spec_of(model)
    if param in sp['nl']: return 'nl', sp['nl'].index(param), lambda g: g
    name = param.replace('log10_', ''); sign = 1
    if name == 'Q': name, sign = 'invQ', -1
    j = sp['lin'].index(name); return 'lin', j, (lambda g, s=sign: 10**(s*g))

def rss_fixed(model, f, Z, param, value, W=None):
    """Globally minimised RSS with one parameter fixed (value on the profile scale)."""
    kind, j, tr = _locate(model, param)
    if kind == 'nl': return gmin(VP(model, f, Z, W), fixed_nl=(j, value))[0]
    return gmin(VP(model, f, Z, W, fix=(j, tr(value))))[0]

def lr_at(model, f, Z, param, value, W=None, rss_min=None):
    rmin = fit(model, f, Z, W)['rss'] if rss_min is None else rss_min; rf = rss_fixed(model, f, Z, param, value, W)
    n = 2*len(f); return n*math.log(max(rf, rmin)/rmin)

def profile_curve(model, f, Z, param, W=None, n_grid=41):
    sp = spec_of(model); base = fit(model, f, Z, W); kind, j, _ = _locate(model, param)
    if kind == 'nl': lo, hi = sp['lo'][j], sp['hi'][j]; est = base['eta'][j]
    else:
        lo, hi = np.log10(sp['llo'][j]), np.log10(sp['lhi'][j]); est = math.log10(base['c'][j])
        if param == 'log10_Q': lo, hi, est = -hi, -lo, -est
    grid = np.unique(np.r_[np.linspace(lo, hi, n_grid), est + np.linspace(-0.06, 0.06, 13)*(hi-lo)].clip(lo, hi))
    prof = np.array([rss_fixed(model, f, Z, param, g, W) for g in grid]); rmin = min(base['rss'], prof.min())
    return grid, 2*len(f)*np.log(prof/rmin), est

def ci_from_curve(grid, lr, thr):
    i0 = int(np.argmin(lr))
    def cross(a, b): return grid[a] + (thr-lr[a])*(grid[b]-grid[a])/(lr[b]-lr[a]) if lr[b] != lr[a] else grid[a]
    j = i0
    while j > 0 and lr[j-1] <= thr: j -= 1
    lo = cross(j, j-1) if j > 0 else grid[0]
    j = i0
    while j < len(grid)-1 and lr[j+1] <= thr: j += 1
    hi = cross(j, j+1) if j < len(grid)-1 else grid[-1]
    return float(lo), float(hi), float(hi-lo), bool(lr[0] > thr and lr[-1] > thr)

def true_value(model, p, param):
    if param == 'log10_Q': return math.log10(p['Q'])
    if param.startswith('log10_') and param != 'log10_tau': return math.log10(p[param[6:]])
    return p[param]

# --- data
def spectra():
    d = pd.read_csv(T/'ecm_ready_complete_scans.csv'); kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct
    out = []
    for sf, g in d.groupby('source_file'):
        g = g.sort_values('frequency_hz'); out.append(dict(sf=sf, tissue=g.tissue.iloc[0], f=g.frequency_hz.to_numpy(float),
                     Z=(g.resistance_ohm + 1j*g.reactance_ohm).to_numpy(), kk_ok=bool(kk[sf] < 3)))
    return out

def sweeps(raw_dir):
    """Complete frequency sweeps per recording: each block of consecutive readings at one frequency is reduced to its
    median, and ascending runs covering all ten frequencies are kept."""
    res = {}
    for s in spectra():
        p = glob.glob(f'{raw_dir}/**/{s["sf"]}', recursive=True)[0]
        d = pd.read_csv(p, sep=';', comment='%', header=None, names=['st', 'f', 'mag', 'ph', 'R', 'X', 't', 'tis'])
        d['blk'] = (d.f.diff() != 0).cumsum(); B = d.groupby('blk').agg(f=('f', 'first'), R=('R', 'median'), X=('X', 'median')).reset_index(drop=True)
        cur, sw = [], []
        for _, r in B.iterrows():
            if cur and r.f <= cur[-1][0]:
                if len(cur) == 10: sw.append(cur)
                cur = []
            cur.append((r.f, r.R + 1j*r.X))
        if len(cur) == 10: sw.append(cur)
        res[s['sf']] = np.array([[z for _, z in c] for c in sw])
    return res

# --- structured covariance of the stacked relative residual [Re_1..Re_N, Im_1..Im_N]
def sigma_struct(psi, N=10):
    s0, gam, rf, rri, ratio = psi; k = np.arange(N); fk = (k+1)/1.0
    sd = s0*fk**gam; sd = np.r_[sd, ratio*sd]
    Rf = rf**np.abs(k[:, None]-k[None, :]); Rri = np.array([[1, rri], [rri, 1]])
    return np.outer(sd, sd)*np.kron(Rri, Rf)

def whitener(S):
    L = np.linalg.cholesky(S); return np.linalg.inv(L)

def noise_draw(rng, S_chol, Z):
    e = S_chol @ rng.standard_normal(S_chol.shape[0]); N = len(Z); sc = np.maximum(np.abs(Z), 1.0)
    return Z + sc*(e[:N] + 1j*e[N:])
