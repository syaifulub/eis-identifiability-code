"""Figures for the second-round analyses: calibrated coverage (E1) and band design (E5)."""
import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
import r2_core as R
T = R.T; OUT = T.parent/'figures'
C1, C2, C3, C4, C5, C6, C7 = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6'
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.size': 8.5, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                     'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'Liberation Sans', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic', 'mathtext.bf': 'Liberation Sans:bold'})
def wilson(k, n, z=1.96):
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d; h = z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h, c+h

# ---- E1 coverage
Cv = pd.read_csv(T/'e1_coverage_runs_M11.csv')
meth = [('Nominal $\\chi^2$', lambda d: d.lr_nom <= 3.84, C1, 'o'), ('Calibrated', lambda d: d.lr_nom <= d.c_nom, C2, 's'),
        ('GLS $\\chi^2$', lambda d: d.lr_gls <= 3.84, C3, '^'), ('GLS calibrated', lambda d: d.lr_gls <= d.c_gls, C7, 'D')]
conds = [('emp', 'Empirical'), ('rho_lo', '$\\rho_f-0.2$'), ('rho_hi', '$\\rho_f+0.2$'), ('white', 'White'), ('ar1', 'AR(1) 0.6')]
pars = [('log10_Q', '$\\log_{10}Q$'), ('alpha', '$\\alpha$'), ('log10_Rinf', '$\\log_{10}R_\\infty$')]
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.6), sharey=True)
rows = []
for a, (p, pl) in zip(ax, pars):
    a.axhline(95, color=INK2, lw=1, ls='--', zorder=0); a.grid(axis='y', color=GRID, lw=0.6); a.set_axisbelow(True)
    for mi, (mn, fn, col, mk) in enumerate(meth):
        xs, ys, lo, hi = [], [], [], []
        for ci, (c, cl) in enumerate(conds):
            d = Cv[(Cv.cond == c) & (Cv.param == p)]; k = int(fn(d).sum()); n = len(d); l, h = wilson(k, n)
            xs.append(ci + (mi-1.5)*0.17); ys.append(100*k/n); lo.append(100*(k/n-l)); hi.append(100*(h-k/n))
            rows.append(dict(param=p, cond=c, method=mn, n=n, coverage=100*k/n, ci_low=100*l, ci_high=100*h))
        a.errorbar(xs, ys, yerr=[lo, hi], fmt=mk, ms=4.5, color=col, mec='#fcfcfb', mew=0.6, elinewidth=1, capsize=0, label=mn)
    a.set_xticks(range(len(conds))); a.set_xticklabels([c[1] for c in conds], rotation=35, ha='right'); a.set_title(pl, color=INK, fontsize=9)
    a.set_ylim(60, 101)
ax[0].set_ylabel('Coverage of nominal 95% interval (%)')
fig.legend(*ax[0].get_legend_handles_labels(), loc='upper center', ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.04))
fig.tight_layout(rect=(0, 0, 1, 0.92)); fig.savefig(OUT/'Fig19_calibrated_coverage.png', dpi=300); plt.close(fig)
pd.DataFrame(rows).to_csv(T/'Table_E1_coverage.csv', index=False)

# ---- E5 band design
S = pd.read_csv(T/'Table_E5_band_factorial.csv'); D = pd.read_csv(T/'e5_band_runs.csv')
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))
a = ax[0]; fmin = [10e3, 3e3, 1e3, 300.0]
for fc, col, lab in [('near', C3, '$f_c$ 10–30 kHz'), ('mid', C1, '$f_c$ 1–10 kHz'), ('low', C2, '$f_c$ 0.1–1 kHz')]:
    for N, ls, mk in [(20, '-', 'o'), (10, ':', 's')]:
        y = [S[(S.design == 'base') & (S.N == N) & (S.fc_class == fc) & (S.fmin_hz == f)].tau_ident_pct.iloc[0] for f in fmin]
        a.plot(fmin, y, ls=ls, marker=mk, ms=4, lw=1.6 if N == 20 else 1.2, color=col, mec='#fcfcfb', mew=0.6, label=f'{lab}, N={N}')
a.set_xscale('log'); a.invert_xaxis(); a.set_xticks(fmin); a.set_xticklabels(['10k', '3k', '1k', '300']); a.set_xlabel('Lower band limit $f_{\\min}$ (Hz)')
a.set_ylabel('$\\log_{10}\\tau$ practically identifiable (%)'); a.set_ylim(-3, 103); a.grid(color=GRID, lw=0.6); a.set_axisbelow(True)
a.legend(frameon=False, fontsize=6.8, loc='lower right'); a.set_title('(a) Range vs number of frequencies', fontsize=9, color=INK, loc='left')
a = ax[1]; bins = ['<0.3', '0.3-1', '1-3', '3-10', '>10']
D['ratio_bin'] = pd.cut(D.ratio_fmin_fc, [0, 0.3, 1, 3, 10, 1e4], labels=bins)
for (dz, N), col, mk, lab in [(('base', 20), C1, 'o', 'White noise'), (('corr', 20), C3, '^', 'Correlated noise'), (('linear', 20), C4, 'v', 'Linear grid'),
                              (('ep10', 20), C5, 's', 'Electrode pol. 10%'), (('ep50', 20), C2, 'D', 'Electrode pol. 50%'), (('mis', 20), C7, 'P', 'Model mismatch')]:
    q = D[(D.design == dz) & (D.N == N)].groupby('ratio_bin', observed=False).tau_ident.mean().mul(100).reindex(bins)
    a.plot(range(5), q.values, marker=mk, ms=4, lw=1.4, color=col, mec='#fcfcfb', mew=0.6, label=lab)
a.set_xticks(range(5)); a.set_xticklabels(bins); a.set_xlabel('$f_{\\min}/f_c$'); a.set_ylim(-3, 103); a.grid(color=GRID, lw=0.6); a.set_axisbelow(True)
a.legend(frameon=False, fontsize=6.8, loc='upper right'); a.set_title('(b) Robustness of the $f_{\\min}/f_c$ rule (N = 20)', fontsize=9, color=INK, loc='left')
fig.tight_layout(); fig.savefig(OUT/'Fig16_band_design_v2.png', dpi=300); plt.close(fig)
print('ok')
