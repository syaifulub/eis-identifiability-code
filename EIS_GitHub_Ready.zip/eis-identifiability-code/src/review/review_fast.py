"""review_fast.py - reanalyses of existing data requested in the critical review (R3, R4, R6, R9, R10, R17, R5-tolerance).
All computations use the shipped spectra and run-level results; no new measurements."""
import sys, math, itertools, numpy as np, pandas as pd
from pathlib import Path
from scipy.stats import wilcoxon, binomtest
ROOT = Path(__file__).resolve().parents[2]; T = ROOT/'results'/'tables'
sys.path.insert(0, str(ROOT/'eisvarpro'))
from eisvarpro import kk_check, fit
from eisvarpro.core import VarPro, global_min, MODELS
rng = np.random.default_rng(20261017)
d = pd.read_csv(T/'ecm_ready_complete_scans.csv'); sub = pd.read_csv(T/'Table_subset_mapping.csv').set_index('source_file').original_subset
S = [(sf, g.sort_values('frequency_hz')) for sf, g in d.groupby('source_file')]
def spec(g): return g.frequency_hz.to_numpy(float), (g.resistance_ohm + 1j*g.reactance_ohm).to_numpy()
out = {}

# ---------- R9: Kramers-Kronig sensitivity (number of Voigt elements x threshold)
base = np.array([kk_check(*spec(g), n_voigt=5)['kk_rms_pct'] >= 3 for _, g in S]); rows = []
for M in [2, 3, 4, 5, 6, 7]:
    r = np.array([kk_check(*spec(g), n_voigt=M)['kk_rms_pct'] for _, g in S])
    rows.append(dict(n_voigt=M, median_rms_pct=np.median(r), **{f'inconsistent_at_{t}pct': int((r >= t).sum()) for t in (2, 3, 4, 5)},
                     agreement_with_5voigt_3pct=int(((r >= 3) == base).sum())))
K = pd.DataFrame(rows); K.to_csv(T/'Table_R9_KK_sensitivity.csv', index=False); out['R9'] = K

# ---------- R3: model selection robustness (M10 vs M11)
def wfit(model, f, Z, weight):
    if weight == 'relative': return fit(model, f, Z)
    s = np.mean(np.abs(Z)); r = fit(model, f, Z/s*1000.0)    # constant weight: residuals scaled by mean |Z|
    return r
def lofo(model, f, Z):
    err = []
    for k in range(len(f)):
        m = np.ones(len(f), bool); m[k] = False; F = fit(model, f[m], Z[m]); p = F['params']; w = 2*np.pi*f[k]
        if model == 'cole_l': zp = p['Rinf'] + p['dR']/(1 + (1j*w*p['tau'])**p['alpha']) + 1j*w*p['L']
        else: zp = p['Rinf'] + (1/p['Q'])*(1j*w)**(-p['alpha']) + 1j*w*p['L']
        err.append(abs(zp - Z[k])**2/abs(Z[k])**2)
    return math.sqrt(np.mean(err))
rows = []
for sf, g in S:
    f, Z = spec(g); rec = dict(source_file=sf, tissue=g.tissue.iloc[0], subset=sub[sf], kk_ok=kk_check(f, Z)['kk_rms_pct'] < 3)
    for wgt in ['relative', 'constant']:
        a, b = wfit('cole_l', f, Z, wgt), wfit('rcpe_l', f, Z, wgt); rec[f'dAICc_M10minusM11_{wgt}'] = a['AICc'] - b['AICc']
    rec['lofo_M10'] = lofo('cole_l', f, Z); rec['lofo_M11'] = lofo('rcpe_l', f, Z)
    rows.append(rec)
MS = pd.DataFrame(rows); MS.to_csv(T/'Table_R3_model_selection_runs.csv', index=False)
summ = dict(M11_pref_relative=int((MS.dAICc_M10minusM11_relative > 0).sum()), M11_pref_constant=int((MS.dAICc_M10minusM11_constant > 0).sum()),
            lofo_M11_better=int((MS.lofo_M11 < MS.lofo_M10).sum()), lofo_median_M10=MS.lofo_M10.median(), lofo_median_M11=MS.lofo_M11.median(),
            lofo_wilcoxon_p=wilcoxon(MS.lofo_M11, MS.lofo_M10).pvalue)
ref = pd.read_csv(T/'best_known_solutions.csv')
m10 = ref[ref.model == 'M10_ColeL']; m11 = ref[ref.model == 'M11_RCPEL']
summ.update(M10_alpha_at_lower=int((m10.alpha <= 0.3001).sum()), M10_alpha_at_upper=int((m10.alpha >= 0.9999).sum()), M10_logdR_at_upper=int((m10.logdR >= 7.999).sum()),
            M10_logtau_at_bound=int(((m10.logtau <= -6.999) | (m10.logtau >= 0.999)).sum()), M11_alpha_at_lower=int((m11.alpha <= 0.3001).sum()),
            M11_alpha_at_upper=int((m11.alpha >= 0.9999).sum()))
pd.DataFrame([summ]).to_csv(T/'Table_R3_model_selection_summary.csv', index=False); out['R3'] = pd.DataFrame([summ]).T

# ---------- R4 / R10: influence of the inductive term and of the two highest frequencies on M11 descriptors
rows = []
for sf, g in S:
    f, Z = spec(g); full = fit('rcpe_l', f, Z)['params']; m = f <= 80e3; trunc = fit('rcpe_l', f[m], Z[m])['params']
    vp = VarPro('rcpe_l', f, Z, fix=(2, 1e-9)); rss, eta = global_min(vp); c, _ = vp.coef(eta)   # L fixed at ~0
    rows.append(dict(source_file=sf, tissue=g.tissue.iloc[0], kk_ok=kk_check(f, Z)['kk_rms_pct'] < 3,
                     omegaL_rel_100k=2*math.pi*1e5*full['L']/abs(Z[-1]), L_mH=1e3*full['L'],
                     dlogQ_trunc=math.log10(trunc['Q']) - math.log10(full['Q']), dalpha_trunc=trunc['alpha'] - full['alpha'],
                     dlogRinf_trunc=math.log10(trunc['Rinf']) - math.log10(full['Rinf']),
                     NRMSE_full=math.sqrt(fit('rcpe_l', f, Z)['rss']/len(f)), NRMSE_noL=math.sqrt(rss/len(f))))
L = pd.DataFrame(rows); L.to_csv(T/'Table_R4_inductance_runs.csv', index=False)
q = lambda x: f"{np.median(x):.3f} [{np.quantile(x, .25):.3f}, {np.quantile(x, .75):.3f}]"
out['R4'] = pd.Series(dict(omegaL_rel_100k=q(L.omegaL_rel_100k), L_mH=q(L.L_mH), abs_dlogQ_drop90_100=q(L.dlogQ_trunc.abs()),
                           abs_dalpha_drop90_100=q(L.dalpha_trunc.abs()), abs_dlogRinf=q(L.dlogRinf_trunc.abs()),
                           NRMSE_with_L=q(L.NRMSE_full), NRMSE_without_L=q(L.NRMSE_noL),
                           kk_ok_abs_dlogQ=q(L[L.kk_ok].dlogQ_trunc.abs()), kk_ok_abs_dalpha=q(L[L.kk_ok].dalpha_trunc.abs())))
out['R4'].to_csv(T/'Table_R4_inductance_summary.csv')

# ---------- R6: equivalence analysis ASHO vs L-SHADE (per-spectrum success-rate and NRMSE differences)
def boot_ci(x, B=10000):
    x = np.asarray(x); bs = [x[rng.integers(0, len(x), len(x))].mean() for _ in range(B)]; return np.quantile(bs, [.025, .975])
rows = []
o = pd.read_csv(T/'optimizer_runs.csv'); m12 = pd.read_csv(T/'optimizer_runs_M12.csv')
vpm = {m: pd.read_csv(T/f'vp_merged_{m}.csv') for m in ['M10_ColeL', 'M11_RCPEL', 'M12_DoubleColeL']}
for model, data in [('M10_ColeL', vpm['M10_ColeL']), ('M11_RCPEL', vpm['M11_RCPEL']), ('M12_DoubleColeL', vpm['M12_DoubleColeL'])]:
    for a, b in [('ASHO-LSHADE', 'L-SHADE'), ('VP-ASHO-LSHADE', 'VP-L-SHADE'), ('ASHO-LSHADE+TRF', 'L-SHADE+TRF')]:
        x = data[data.algorithm.isin([a, b])]
        if x.algorithm.nunique() < 2: continue
        sr = x.groupby(['source_file', 'algorithm']).success.mean().unstack(); dsr = 100*(sr[a]-sr[b])
        med = x.groupby(['source_file', 'algorithm']).NRMSE.median().unstack(); drel = 100*(med[a]-med[b])/med[b]
        lo, hi = boot_ci(dsr); lo2, hi2 = boot_ci(drel)
        rows.append(dict(model=model, comparison=f'{a} - {b}', mean_dsuccess_pp=dsr.mean(), ci_low_pp=lo, ci_high_pp=hi,
                         equivalent_within_5pp=bool(lo > -5 and hi < 5), mean_dNRMSE_pct=drel.mean(), ci_low_pct=lo2, ci_high_pct=hi2,
                         equivalent_within_1pct=bool(lo2 > -1 and hi2 < 1)))
E = pd.DataFrame(rows); E.to_csv(T/'Table_R6_equivalence.csv', index=False); out['R6'] = E

# ---------- R5 (tolerance) and R17 (jackknife): VP-MS-TRF vs MS-TRF and VP-L-SHADE vs L-SHADE on M12 and M10
rows = []
for model in ['M10_ColeL', 'M12_DoubleColeL']:
    x = vpm[model]
    for tol in [1e-2, 1e-3, 1e-4]:
        s = (x.NRMSE - x.ref)/x.ref <= tol
        r = x.assign(s=s).groupby('algorithm').s.mean()
        rows.append(dict(model=model, tolerance=tol, **{k: 100*r[k] for k in ['L-SHADE', 'VP-L-SHADE', 'MS-TRF', 'VP-MS-TRF', 'VP-Screen+TRF']}))
TOL = pd.DataFrame(rows); TOL.to_csv(T/'Table_R5_tolerance.csv', index=False); out['R5tol'] = TOL
x = vpm['M12_DoubleColeL']; sr = x.groupby(['source_file', 'algorithm']).success.mean().unstack(); g = 100*(sr['VP-MS-TRF']-sr['MS-TRF'])
jk = [g.drop(i).mean() for i in g.index]
sub_strat = {s: dict(n=int((sub[g.index] == s).sum()), mean_gain=g[sub[g.index] == s].mean(), positive=int((g[sub[g.index] == s] > 0).sum()),
                     negative=int((g[sub[g.index] == s] < 0).sum())) for s in sorted(sub.unique())}
out['R17'] = pd.Series(dict(gain_mean=g.mean(), jackknife_min=min(jk), jackknife_max=max(jk), spectra_with_gain=int((g > 0).sum()),
                            spectra_with_loss=int((g < 0).sum()), sign_test_p=binomtest(int((g > 0).sum()), int((g != 0).sum()), .5).pvalue, **{f'{k}_{kk}': vv for k, v in sub_strat.items() for kk, vv in v.items()}))
out['R17'].to_csv(T/'Table_R17_jackknife.csv')

pd.set_option('display.width', 220); pd.set_option('display.max_columns', 30)
for k, v in out.items(): print('=====', k); print(v.round(4).to_string() if hasattr(v, 'round') else v)
