"""review_slow.py - simulation-based coverage of profile-likelihood intervals (R2), search-bound sensitivity (R2),
polished M13 references (R12), L-SHADE population-size sensitivity (R13) and same-machine time-to-target for
L-SHADE vs VP-L-SHADE (R5). Usage: python review_slow.py [R2|R12|R13|R5|all]"""
import sys, math, time, pickle, numpy as np, pandas as pd
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]; T = ROOT/'results'/'tables'; SRC = ROOT/'src'
sys.path.insert(0, str(ROOT/'eisvarpro')); sys.path.insert(0, str(SRC))
import eisvarpro.core as C
from eisvarpro import fit, profile, kk_check
what = sys.argv[1] if len(sys.argv) > 1 else 'all'
d = pd.read_csv(T/'ecm_ready_complete_scans.csv'); kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct
S = [(sf, g.sort_values('frequency_hz')) for sf, g in d.groupby('source_file')]
def spec(g): return g.frequency_hz.to_numpy(float), (g.resistance_ohm + 1j*g.reactance_ohm).to_numpy()

def noise(z, kind, rng, level=0.025):
    n = len(z)
    if kind == 'white': e = rng.standard_normal(n) + 1j*rng.standard_normal(n)
    elif kind == 'AR1':                                     # correlated across frequency, rho = 0.6
        def ar():
            x = np.empty(n); x[0] = rng.standard_normal()
            for k in range(1, n): x[k] = 0.6*x[k-1] + math.sqrt(1-0.36)*rng.standard_normal()
            return x
        e = ar() + 1j*ar()
    elif kind == 'hetero':                                  # relative noise rising from 1% to 4% with frequency
        s = np.linspace(0.4, 1.6, n); e = s*(rng.standard_normal(n) + 1j*rng.standard_normal(n))
    return z + level*np.abs(z)*e/math.sqrt(2)

if what in ('R2', 'all'):
    t0 = time.time(); rng = np.random.default_rng(1); rows = []
    good = [(sf, g) for sf, g in S if kk[sf] < 3]
    for sf, g in good:
        f, Z = spec(g); p = fit('rcpe_l', f, Z)['params']; w = 2*np.pi*f
        z11 = p['Rinf'] + (1/p['Q'])*(1j*w)**(-p['alpha']) + 1j*w*p['L']
        # Cole truth with f_c below the band, matched to the same high-frequency tail (dR from Q, tau, alpha)
        fc = 10**rng.uniform(np.log10(200), np.log10(3000)); tau = 1/(2*np.pi*fc); a10 = min(max(p['alpha'], 0.5), 0.95)
        dR = tau**a10/p['Q']; z10 = p['Rinf'] + dR/(1 + (1j*w*tau)**a10) + 1j*w*p['L']
        for kind in ['white', 'AR1', 'hetero']:
            for r in range(10):
                zn = noise(z11, kind, rng)
                for par, truth in [('log10_Q', math.log10(p['Q'])), ('alpha', p['alpha'])]:
                    P = profile('rcpe_l', f, zn, par); rows.append(dict(source_file=sf, model='M11', noise=kind, param=par, covered=P['ci_low'] <= truth <= P['ci_high'],
                                                                     closed=P['closed'], width=P['ci_width']))
                zn = noise(z10, kind, rng); P = profile('cole_l', f, zn, 'log10_tau')
                rows.append(dict(source_file=sf, model='M10', noise=kind, param='log10_tau', covered=P['ci_low'] <= math.log10(tau) <= P['ci_high'],
                                 closed=P['closed'], width=P['ci_width']))
        print(time.strftime('%H:%M:%S'), 'R2', sf[3:15], flush=True)
    R = pd.DataFrame(rows); R.to_csv(T/'review_R2_coverage_runs.csv', index=False)
    Sm = R.groupby(['model', 'param', 'noise']).agg(n=('covered', 'size'), coverage_pct=('covered', lambda x: 100*x.mean()),
            closed_pct=('closed', lambda x: 100*x.mean()), median_width=('width', 'median')).reset_index()
    Sm.to_csv(T/'Table_R2_coverage.csv', index=False); print(Sm.round(3).to_string())
    # search-bound sensitivity on the measured spectra
    rows = []
    for lo, hi in [(-7.0, 1.0), (-9.0, 3.0), (-6.0, 0.0)]:
        C.MODELS['cole_l']['lo'][0], C.MODELS['cole_l']['hi'][0] = lo, hi
        for sf, g in S:
            P = profile('cole_l', *spec(g), 'log10_tau'); rows.append(dict(bounds=f'[{lo:g},{hi:g}]', source_file=sf, closed=P['closed'], width=P['ci_width']))
    C.MODELS['cole_l']['lo'][0], C.MODELS['cole_l']['hi'][0] = -7.0, 1.0
    B = pd.DataFrame(rows).groupby('bounds').agg(closed=('closed', 'sum'), median_width=('width', 'median')).reset_index()
    B.to_csv(T/'Table_R2_bound_sensitivity.csv', index=False); print(B.to_string()); print('R2 sec', round(time.time()-t0))

if what in ('R12', 'all'):
    t0 = time.time(); _argv = sys.argv; sys.argv = [sys.argv[0]]; from nested_vp import Problem, LO, HI; sys.argv = _argv
    from scipy.optimize import least_squares
    runs = pd.read_csv(T/'nested_m13_runs.csv'); best = {}
    for si, (sf, g) in enumerate(S):
        f, Z = spec(g); P = Problem(2*np.pi*f, Z) if False else Problem(f*2*np.pi, Z); rng = np.random.default_rng(500+si); b = np.inf
        for k in range(60):                                   # 60 multistart partial-VarPro TRF fits from random starts
            r = least_squares(P.res_vp, rng.uniform(LO[:6], HI[:6]), bounds=(LO[:6], HI[:6]), max_nfev=3000, xtol=1e-12, ftol=1e-12)
            b = min(b, 2*r.cost/P.N)
        best[sf] = math.sqrt(b)
    runs['ref_old'] = runs.ref; runs['ref'] = [min(o, best[s]) for o, s in zip(runs.ref_old, runs.source_file)]
    for c in [200, 500, 1000, 2000]: runs[f'succ_{c}'] = (runs[f'trace_{c}'] - runs.ref)/runs.ref <= 1e-3
    improved = int(((runs.groupby('source_file').ref_old.first() - pd.Series(best))/runs.groupby('source_file').ref_old.first() > 1e-3).sum())
    Sm = runs.groupby('algorithm')[[f'succ_{c}' for c in [200, 500, 1000, 2000]]].mean().mul(100).reset_index()
    Sm['refs_improved_by_polishing'] = improved; Sm.to_csv(T/'Table_R12_M13_polished.csv', index=False); print(Sm.round(1).to_string()); print('R12 sec', round(time.time()-t0))

if what in ('R13', 'all'):
    t0 = time.time(); import eis_core as E
    from vp_common import load_spectra
    ref = pd.read_csv(T/'best_known_solutions.csv'); rows = []
    for pop in [10, 20, 40]:
        E.POP0 = pop
        for s in load_spectra():
            rr = ref[(ref.model == 'M10_ColeL') & (ref.source_file == s['sf'])].ref_NRMSE.iloc[0]; f = E.make_objective('M10_ColeL', s['w'], s['z'])
            _, lo, hi = E.MODELS['M10_ColeL']
            for r in range(10):
                _, fb, _, _ = E.lshade_family(f, lo, hi, 2000, 20261101 + s['si']*1000 + r, 'lshade')
                rows.append(dict(pop=pop, source_file=s['sf'], run=r, success=(math.sqrt(fb)-rr)/rr <= 1e-3))
    E.POP0 = 20
    P = pd.DataFrame(rows).groupby('pop').success.mean().mul(100).reset_index(); P.to_csv(T/'Table_R13_population.csv', index=False); print(P.to_string()); print('R13 sec', round(time.time()-t0))

if what in ('R5', 'all'):
    t0 = time.time(); import eis_core as E; import vp_core as V
    from vp_common import load_spectra
    rows = []
    for model in ['M10_ColeL', 'M12_DoubleColeL']:
        mrg = pd.read_csv(T/f'vp_merged_{model}.csv'); ref = mrg.groupby('source_file').ref.first(); _, lo, hi = E.MODELS[model]
        for s in load_spectra():
            target = (ref[s['sf']]*(1+1e-3))**2
            for r in range(5):
                seed = 20261101 + s['si']*1000 + r
                for name in ['L-SHADE', 'VP-L-SHADE']:
                    if name == 'L-SHADE': fobj = E.make_objective(model, s['w'], s['z']); a, b = lo, hi
                    else: vp = V.VarPro(model, s['w'], s['z']); fobj = vp.f; a, b = vp.sp['lo'], vp.sp['hi']
                    st = dict(t0=None, hit=None, n=0)
                    def g(x, fobj=fobj, st=st):
                        v = fobj(x); st['n'] += 1
                        if st['hit'] is None and v <= target: st['hit'] = (time.perf_counter()-st['t0'], st['n'])
                        return v
                    st['t0'] = time.perf_counter(); E.lshade_family(g, a, b, 2000, seed, 'lshade')
                    rows.append(dict(model=model, algorithm=name, source_file=s['sf'], run=r, hit=st['hit'] is not None,
                                     ms=1000*st['hit'][0] if st['hit'] else np.inf, nfe=st['hit'][1] if st['hit'] else np.nan))
    D = pd.DataFrame(rows); D.to_csv(T/'review_R5_timing_lshade_runs.csv', index=False)
    Sm = D.groupby(['model', 'algorithm']).agg(success_pct=('hit', lambda x: 100*x.mean()), median_ms_all=('ms', 'median'),
          median_nfe_success=('nfe', 'median')).reset_index()
    Sm.to_csv(T/'Table_R5_timing_lshade.csv', index=False); print(Sm.to_string()); print('R5 sec', round(time.time()-t0))
