Additional analyses of the current manuscript version (no new measurements)

The scripts locate the repository root from their own position (two levels up), import the shared engine
src/review/r2_core.py and read the stored spectra and results/tables/. Run them from any folder, e.g.

    cd src/revision && python eA_band_truncation.py

  eA_band_truncation.py   band truncation of the 20 measured spectra        -> out_A/ (Table 3, Table S51)
  eB_noise_sweep.py       noise sweep 0.5-5 % of the band-design simulation -> out_B/ (Table S52)
  eB2_boundary.py         collinearity-free boundary test + width exponent  -> out_B/EB2_stats.json (needs out_B/EB_runs.csv)
  eC_algorithm2_retro.py  retrospective test of Algorithm 2                 -> out_C/ (Table S53)
  make_fig1_workflow.py   Fig. 1 workflow, vector PDF/EPS                   -> figures/ (optional argument: output folder)
  make_vector_figs.py     Figs. 2-4 as vector PDF/EPS from results/tables   -> figures/ (optional argument: output folder)
  make_fig5_decision.py   Fig. 5 decision rule, vector PDF/EPS              -> figures/ (run after make_fig1_workflow.py,
                                                                               which also draws a superseded Fig. 5)

Seeds are fixed; eB_noise_sweep.py reproduces src/review/e5_band_factorial.py exactly at 2.5 % noise.
Runtime of the four analyses: about 10 min on one core. eB2_boundary.py needs scikit-learn.
The out_A/, out_B/ and out_C/ folders contain the outputs reported in the manuscript; rerunning overwrites them.
Figures use Liberation Sans (metric-compatible with Arial, embedded as TrueType) when it is installed.
