"""EA: band-truncation test of the closed-form criterion on the MEASURED spectra (no new data).

Each of the 20 measured spectra (10-100 kHz, 10 frequencies) is re-analysed on sub-bands obtained by removing
frequencies:  low-cut (f_min = 20, 30, 40 kHz), high-cut (f_max = 70 kHz), and thinning (5 frequencies over the
full range).  The equal-N pair 'lowcut40' (40-100 kHz) and 'highcut70' (10-70 kHz), both N = 7, separates the
effect of the lower band limit from that of the number of frequencies.

For every spectrum and sub-band:
  * closed-form criterion (Eqs. 8-9): D and alpha from the R-CPE-L fit on the sub-band, sigma from the Cole+L
    residuals (RSS/(2N-5)), Gamma, detection limit f_min/Gamma, predicted width at the fitted f_c;
  * profile likelihood (nominal chi2 3.84) of log10 tau (Cole+L) -> interval, closure, identifiability,
    upper 95% bound of f_c; and of log10 Q and alpha (R-CPE-L).
Outputs go to src/revision/out_A (the original results/ folder is not touched)."""
import sys, math, json, numpy as np, pandas as pd
from scipy.stats import spearmanr, wilcoxon
from pathlib import Path
HERE = Path(__file__).resolve().parent              # src/revision
ROOT = str(HERE.parents[1])                            # repository root (contains src/review and results/)
sys.path.insert(0, ROOT + '/src/review')
import r2_core as R
from pathlib import Path
OUT = HERE/'out_A'; OUT.mkdir(exist_ok=True)
LN10 = math.log(10); THR = 3.84

def stack(c): return np.r_[c.real, c.imag]
def D_factor(w, Rinf, Q, alpha, L, absZ):          # identical to e10_asymptotic.py
    jw = 1j*w; cpe = jw**(-alpha)/Q
    cols = [Rinf/absZ, -cpe/absZ, -np.log(jw)*cpe/absZ, jw*L/absZ]
    J = np.column_stack([stack(c) for c in cols]); wmin = w.min()
    ht = stack(cpe*(1j*w/wmin)**(-alpha)/absZ)
    P = np.eye(len(ht)) - J @ np.linalg.pinv(J); return float(np.linalg.norm(P @ ht))
def Gamma(D, a, s, Wstar=1.0, z=1.96): return (a*LN10*D*Wstar/(2*z*s))**(1/a)
def W_asym(D, a, s, ratio, z=1.96): return 2*z*s*ratio**a/(a*LN10*D)

F_ALL = np.arange(1, 11)*1e4
VARIANTS = {
    'full':      F_ALL,
    'lowcut20':  F_ALL[F_ALL >= 2e4],
    'lowcut30':  F_ALL[F_ALL >= 3e4],
    'lowcut40':  F_ALL[F_ALL >= 4e4],
    'highcut70': F_ALL[F_ALL <= 7e4],
    'thin5':     np.array([1e4, 3e4, 5e4, 7e4, 1e5]),
}
TAU_LO = R.spec_of('cole_l')['lo'][0]; TAU_HI = R.spec_of('cole_l')['hi'][0]
rows = []
for s in R.spectra():
    for vname, fsel in VARIANTS.items():
        m = np.isin(s['f'], fsel); f, Z = s['f'][m], s['Z'][m]; N = len(f); w = 2*np.pi*f
        F11 = R.fit('rcpe_l', f, Z); p = F11['params']; F10 = R.fit('cole_l', f, Z); q = F10['params']
        absZ = np.maximum(np.abs(Z), 1.0); sig = math.sqrt(F10['rss']/(2*N - 5))
        D = D_factor(w, p['Rinf'], p['Q'], p['alpha'], p['L'], absZ); G = Gamma(D, p['alpha'], sig)
        fc_hat = 1/(2*np.pi*10**q['log10_tau']); ratio = f.min()/fc_hat
        g, lr, est = R.profile_curve('cole_l', f, Z, 'log10_tau', n_grid=33); lo, hi, wd, cl = R.ci_from_curve(g, lr, THR)
        open_low_tau = lo <= TAU_LO + 1e-9            # interval reaches the lower tau bound -> upper f_c bound censored
        rec = dict(source_file=s['sf'], tissue=s['tissue'], kk_ok=s['kk_ok'], variant=vname, N=N, fmin=f.min(), fmax=f.max(),
                   sigma=sig, alpha11=p['alpha'], D=D, Gamma=G, fc_detect_hz=f.min()/G, fc_hat_hz=fc_hat,
                   W_asym=W_asym(D, p['alpha'], sig, ratio), r_at_boundary=G**(-p['alpha']),
                   tau_width=wd, tau_closed=cl, tau_ident=bool(cl and wd < 1.0),
                   fc_upper_hz=1/(2*np.pi*10**lo), fc_upper_censored=bool(open_low_tau))
        for par, wthr in (('log10_Q', 1.0), ('alpha', 0.2)):
            g2, lr2, _ = R.profile_curve('rcpe_l', f, Z, par, n_grid=33); lo2, hi2, wd2, cl2 = R.ci_from_curve(g2, lr2, THR)
            rec[f'{par}_width'] = wd2; rec[f'{par}_ident'] = bool(cl2 and wd2 < wthr)
        rows.append(rec)
    print(s['sf'][:40], 'done', flush=True)
A = pd.DataFrame(rows); A['tau_ident_pred'] = A.W_asym < 1.0; A.to_csv(OUT/'EA_runs.csv', index=False)

def summarize(df):
    out = []
    for v in VARIANTS:
        g = df[df.variant == v]
        out.append(dict(variant=v, N=int(g.N.iloc[0]), band=f"{g.fmin.iloc[0]/1e3:.0f}-{g.fmax.iloc[0]/1e3:.0f} kHz", n=len(g),
                        Gamma_med=g.Gamma.median(), fc_detect_khz_med=g.fc_detect_hz.median()/1e3, fc_upper_khz_med=g.fc_upper_hz.median()/1e3,
                        fc_upper_censored=int(g.fc_upper_censored.sum()), tau_ident=int(g.tau_ident.sum()), tau_ident_pred=int(g.tau_ident_pred.sum()),
                        agree_pct=100*float((g.tau_ident == g.tau_ident_pred).mean()),
                        Q_ident=int(g.log10_Q_ident.sum()), alpha_ident=int(g.alpha_ident.sum()),
                        Q_width_med=g.log10_Q_width.median(), alpha_width_med=g.alpha_width.median(), boundary_r_med=g.r_at_boundary.median()))
    return pd.DataFrame(out)
res = {}
for label, df in (('kk', A[A.kk_ok]), ('all', A)):
    S = summarize(df); S.to_csv(OUT/f'EA_summary_{label}.csv', index=False); print(label); print(S.round(3).to_string())
    # pooled rank correlation between predicted detection limit and observed upper f_c bound (all variants)
    rho_all = spearmanr(np.log(df.fc_detect_hz), np.log(df.fc_upper_hz)).statistic
    # within-spectrum: change relative to the full band
    full = df[df.variant == 'full'].set_index('source_file')
    d = df[df.variant != 'full'].copy()
    d['dlog_det'] = np.log10(d.fc_detect_hz.values/full.loc[d.source_file, 'fc_detect_hz'].values)
    d['dlog_up'] = np.log10(d.fc_upper_hz.values/full.loc[d.source_file, 'fc_upper_hz'].values)
    rho_change = spearmanr(d.dlog_det, d.dlog_up).statistic
    # equal-N pair: dropping the 3 lowest vs the 3 highest frequencies
    lc = d[d.variant == 'lowcut40'].set_index('source_file'); hc = d[d.variant == 'highcut70'].set_index('source_file').loc[lc.index]
    pair = dict(det_lowcut_med=float(lc.dlog_det.median()), det_highcut_med=float(hc.dlog_det.median()),
                up_lowcut_med=float(lc.dlog_up.median()), up_highcut_med=float(hc.dlog_up.median()),
                n_det_lowcut_gt_highcut=int((lc.dlog_det > hc.dlog_det).sum()), n_up_lowcut_gt_highcut=int((lc.dlog_up > hc.dlog_up).sum()), n=len(lc),
                p_det=float(wilcoxon(lc.dlog_det, hc.dlog_det).pvalue), p_up=float(wilcoxon(lc.dlog_up, hc.dlog_up).pvalue))
    res[label] = dict(spearman_pooled=float(rho_all), spearman_change=float(rho_change), equalN_pair=pair,
                      censored_upper=int(df.fc_upper_censored.sum()), n_rows=len(df))
    d.to_csv(OUT/f'EA_changes_{label}.csv', index=False)
json.dump(res, open(OUT/'EA_stats.json', 'w'), indent=2); print(json.dumps(res, indent=2))
