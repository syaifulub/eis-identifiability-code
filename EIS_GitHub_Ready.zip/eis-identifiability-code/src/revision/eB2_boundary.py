"""EB2: detection-boundary test without collinearity. Eq. 9 implies identifiability depends on
ln W_pred = ln sigma + [alpha ln(f_min/f_c) - ln(alpha D)] + const. Logistic regression of identifiability on
x1 = ln sigma and x2 = alpha ln(f_min/f_c) - ln(alpha D) (the band/dispersion geometry term); Eq. 9 predicts
equal coefficients (ratio 1). Cluster bootstrap over the 60 truths."""
import numpy as np, pandas as pd, json, math
from pathlib import Path
HERE = Path(__file__).resolve().parent
from sklearn.linear_model import LogisticRegression
B = pd.read_csv(HERE/'out_B/EB_runs.csv')
x1 = np.log(B.noise/math.sqrt(2)); x2 = B.alpha*np.log(B.ratio) - np.log(B.alpha*B.D); X = np.column_stack([x1, x2]); y = B.tau_ident.astype(int).values
m = LogisticRegression(C=1e6, max_iter=10000).fit(X, y); b = m.coef_[0]
keys = B[['fc_class', 'spectrum']].drop_duplicates().values; rng = np.random.default_rng(2); rat = []
for _ in range(1000):
    pick = keys[rng.integers(0, len(keys), len(keys))]
    idx = np.concatenate([np.where((B.fc_class.values == k[0]) & (B.spectrum.values == int(k[1])))[0] for k in pick])
    if y[idx].min() == y[idx].max(): continue
    bb = LogisticRegression(C=1e6, max_iter=10000).fit(X[idx], y[idx]).coef_[0]; rat.append(bb[0]/bb[1])
res = dict(coef_ln_sigma=float(b[0]), coef_geometry=float(b[1]), ratio=float(b[0]/b[1]), ratio_ci95=[float(np.quantile(rat, .025)), float(np.quantile(rat, .975))])
# width exponent: by regime of r at the lowest noise level
B['r'] = B.ratio**(-B.alpha)
sl = []
for key, g in B[B.tau_closed].groupby(['fc_class', 'spectrum', 'fmin_hz']):
    if g.noise.nunique() >= 3: sl.append(dict(r=g.r.iloc[0], slope=np.polyfit(np.log(g.noise), np.log(g.tau_width), 1)[0], wmin=g.tau_width.min()))
S = pd.DataFrame(sl); S['rbin'] = pd.cut(S.r, [0, 0.3, 1, 100], labels=['r<0.3', '0.3-1', '>1 (in band)'])
res['width_exponent_by_r'] = S.groupby('rbin', observed=True).slope.agg(['count', 'median']).round(2).reset_index().to_dict('records')
# noise needed to match band extension at f_min 10 kHz (pooled identifiability)
json.dump(res, open(HERE/'out_B/EB2_stats.json', 'w'), indent=2); print(json.dumps(res, indent=2))
