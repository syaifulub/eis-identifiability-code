"""EB: noise-level sweep of the band-design simulation (direct test of Eqs. 8-9 and of the band-versus-noise claim).

Same truths, frequency grids (log-spaced, N = 20, f_max = 100 kHz, f_min = 10, 3, 1, 0.3 kHz) and noise draws as
e5_band_factorial.py ('base', N = 20); only the relative noise level is varied: 0.5, 1, 2.5 and 5 %.
Because the same standard-normal draws are scaled, each spectrum-band is observed at four noise levels.
Tests:
  (1) identifiability of log10 tau by noise level and f_min/f_c;
  (2) width scaling: slope of log W_profile on log sigma for closed profiles (Eq. 8 predicts 1);
  (3) detection boundary: logistic regression of identifiability on alpha*ln(f_min/f_c), ln(sigma) and ln(alpha D);
      Eq. 9 predicts equal and opposite coefficients for alpha*ln(f_min/f_c) and ln(sigma) (ratio 1);
  (4) levers: identifiability gained by a 10-fold noise reduction versus a 33-fold lower f_min;
  (5) agreement of the closed-form classification at each noise level.
The 2.5 % level reproduces e5 (checked against e5_band_runs.csv)."""
import sys, math, json, pickle, time, numpy as np, pandas as pd
from pathlib import Path
from pathlib import Path
HERE = Path(__file__).resolve().parent              # src/revision
ROOT = str(HERE.parents[1])                            # repository root (contains src/review and results/)
sys.path.insert(0, ROOT + '/src/review')
import r2_core as R
from sklearn.linear_model import LogisticRegression
OUT = HERE/'out_B'; OUT.mkdir(exist_ok=True); LN10 = math.log(10)
FMIN = [10e3, 3e3, 1e3, 300.0]; FC = {'low': (100, 1000), 'mid': (1000, 10000), 'near': (10000, 30000)}
NOISE = [0.005, 0.01, 0.025, 0.05]; N = 20; NS = 20

def truth(i, fc_rng):                        # identical to e5_band_factorial.py
    rng = np.random.default_rng(424242 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(*np.log10(fc_rng)); tau = 1/(2*np.pi*fc); dR = rng.uniform(1, 3)*Rinf
    return dict(Rinf=Rinf, dR=dR, tau=tau, alpha=a, L=L, fc=fc, nu_ep=0.6, fc2=10**rng.uniform(np.log10(3e4), np.log10(3e5))), rng
def zcole(p, w): return p['Rinf'] + p['dR']/(1 + (1j*w*p['tau'])**p['alpha']) + 1j*w*p['L']
def stack(c): return np.r_[c.real, c.imag]
def D_factor(w, Rinf, Q, alpha, L, absZ):
    jw = 1j*w; cpe = jw**(-alpha)/Q
    J = np.column_stack([stack(c) for c in [Rinf/absZ, -cpe/absZ, -np.log(jw)*cpe/absZ, jw*L/absZ]])
    ht = stack(cpe*(1j*w/w.min())**(-alpha)/absZ); P = np.eye(len(ht)) - J @ np.linalg.pinv(J); return float(np.linalg.norm(P @ ht))

rows = []; cache = OUT/'EB_runs.pkl'
if cache.exists(): rows = pickle.load(open(cache, 'rb'))
else:
    t0 = time.time()
    for fcn, fcr in FC.items():
        for i in range(NS):
            p, rng = truth(i, fcr); nseed = rng.integers(1 << 30)
            for fmin in FMIN:
                f = np.logspace(np.log10(fmin), 5, N); w = 2*np.pi*f; z0 = zcole(p, w)
                nr = np.random.default_rng(nseed); e = nr.standard_normal((2, N))
                Q = p['tau']**p['alpha']/p['dR']; D = D_factor(w, p['Rinf'], Q, p['alpha'], p['L'], np.abs(z0)); ratio = fmin/p['fc']
                for s in NOISE:
                    z = z0 + s*np.abs(z0)*(e[0] + 1j*e[1])/math.sqrt(2); sig = s/math.sqrt(2)
                    g, lr, est = R.profile_curve('cole_l', f, z, 'log10_tau', n_grid=33); lo, hi, wd, cl = R.ci_from_curve(g, lr, 3.84)
                    W_pred = 2*1.96*sig*ratio**p['alpha']/(p['alpha']*LN10*D); G = (p['alpha']*LN10*D/(2*1.96*sig))**(1/p['alpha'])
                    rows.append(dict(fc_class=fcn, spectrum=i, fmin_hz=fmin, fc=p['fc'], ratio=ratio, alpha=p['alpha'], D=D, noise=s,
                                     tau_width=wd, tau_closed=cl, tau_ident=bool(cl and wd < 1.0), W_pred=W_pred, Gamma=G))
        print(time.strftime('%H:%M:%S'), fcn, f'{time.time()-t0:.0f}s', flush=True)
    pickle.dump(rows, open(cache, 'wb'))
B = pd.DataFrame(rows); B['ident_pred'] = B.W_pred < 1.0; B.to_csv(OUT/'EB_runs.csv', index=False)

# check against e5 at 2.5 %
E5 = pd.read_csv(Path(ROOT)/'results/tables/e5_band_runs.csv'); E5 = E5[(E5.design == 'base') & (E5.N == 20)]
chk = B[B.noise == 0.025].merge(E5[['fc_class', 'spectrum', 'fmin_hz', 'tau_ident', 'tau_width']], on=['fc_class', 'spectrum', 'fmin_hz'], suffixes=('', '_e5'))
res = dict(e5_reproduction_ident_match=float((chk.tau_ident == chk.tau_ident_e5).mean()),
           e5_reproduction_width_maxdiff=float(np.nanmax(np.abs(chk.tau_width - chk.tau_width_e5))))

# (1) identifiability by noise and ratio bin
B['ratio_bin'] = pd.cut(B.ratio, [0, 1, 3, 10, 1e5], labels=['<1', '1-3', '3-10', '>10'])
T1 = B.pivot_table(index='noise', columns='ratio_bin', values='tau_ident', aggfunc='mean', observed=True).mul(100)
T1['all'] = B.groupby('noise').tau_ident.mean().mul(100); T1.to_csv(OUT/'EB_ident_by_noise.csv'); print(T1.round(0).to_string())

# (2) width scaling with sigma (closed profiles at >= 2 noise levels)
slopes = []
for key, g in B[B.tau_closed].groupby(['fc_class', 'spectrum', 'fmin_hz']):
    if g.noise.nunique() >= 2: slopes.append(np.polyfit(np.log(g.noise), np.log(g.tau_width), 1)[0])
slopes = np.array(slopes)
res['width_slope'] = dict(n=int(len(slopes)), median=float(np.median(slopes)), q25=float(np.quantile(slopes, .25)), q75=float(np.quantile(slopes, .75)))
# restricted to the quadratic regime (predicted width < 1 decade at the lowest noise level -> profile close to quadratic)
quad = []
for key, g in B[B.tau_closed & (B.tau_width < 1.0)].groupby(['fc_class', 'spectrum', 'fmin_hz']):
    if g.noise.nunique() >= 2: quad.append(np.polyfit(np.log(g.noise), np.log(g.tau_width), 1)[0])
quad = np.array(quad)
res['width_slope_identifiable_regime'] = dict(n=int(len(quad)), median=float(np.median(quad)) if len(quad) else None,
                                               q25=float(np.quantile(quad, .25)) if len(quad) else None, q75=float(np.quantile(quad, .75)) if len(quad) else None)

# (3) logistic detection boundary
X = np.column_stack([B.alpha*np.log(B.ratio), np.log(B.noise/math.sqrt(2)), np.log(B.alpha*B.D)]); y = B.tau_ident.astype(int).values
lr = LogisticRegression(C=1e6, max_iter=10000).fit(X, y); b = lr.coef_[0]
res['logistic'] = dict(coef_alpha_ln_ratio=float(b[0]), coef_ln_sigma=float(b[1]), coef_ln_alphaD=float(b[2]), ratio_sigma_to_ratio=float(b[1]/b[0]),
                       ratio_alphaD_to_ratio=float(b[2]/b[0]), predicted_ratio_sigma=1.0, predicted_ratio_alphaD=-1.0)
# bootstrap over truths for the coefficient ratio
rng = np.random.default_rng(1); keys = B[['fc_class', 'spectrum']].drop_duplicates().values; rat = []
for _ in range(300):
    pick = keys[rng.integers(0, len(keys), len(keys))]
    idx = np.concatenate([np.where((B.fc_class.values == k[0]) & (B.spectrum.values == int(k[1])))[0] for k in pick])
    yy = y[idx]
    if yy.min() == yy.max(): continue
    bb = LogisticRegression(C=1e6, max_iter=10000).fit(X[idx], yy).coef_[0]; rat.append(bb[1]/bb[0])
res['logistic']['ratio_sigma_ci95'] = [float(np.quantile(rat, .025)), float(np.quantile(rat, .975))]

# (4) levers, pooled over f_c classes (60 truths)
def pct(m): return float(100*B[m].tau_ident.mean())
res['levers'] = dict(
    band10k_noise5=pct((B.fmin_hz == 10e3) & (B.noise == 0.05)), band10k_noise0p5=pct((B.fmin_hz == 10e3) & (B.noise == 0.005)),
    band10k_noise2p5=pct((B.fmin_hz == 10e3) & (B.noise == 0.025)), band0p3k_noise2p5=pct((B.fmin_hz == 300) & (B.noise == 0.025)),
    band3k_noise2p5=pct((B.fmin_hz == 3e3) & (B.noise == 0.025)), band10k_noise1=pct((B.fmin_hz == 10e3) & (B.noise == 0.01)))
L = B.pivot_table(index='fmin_hz', columns='noise', values='tau_ident', aggfunc='mean').mul(100).iloc[::-1]; L.to_csv(OUT/'EB_ident_fmin_noise.csv'); print(L.round(0).to_string())

# (5) closed-form classification agreement by noise
res['agreement_by_noise'] = {str(s): float(100*(g.ident_pred == g.tau_ident).mean()) for s, g in B.groupby('noise')}
json.dump(res, open(OUT/'EB_stats.json', 'w'), indent=2); print(json.dumps(res, indent=2))
