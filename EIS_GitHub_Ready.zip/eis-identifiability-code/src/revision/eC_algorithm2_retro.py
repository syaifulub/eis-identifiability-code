"""EC: retrospective test of Algorithm 2 (preliminary frequency-band screening from a pilot spectrum).

For each of the 60 band-design truths (Cole+L, f_c 0.1-30 kHz):
  * pilot spectrum: the instrument's band, 10-100 kHz in 10 kHz steps (N = 10), 2.5 % relative noise (own seed);
    R-CPE-L is fitted to the pilot (Algorithm 1, steps 2-5) and sigma is taken from the Cole+L residuals;
  * expected f_c: either the true f_c ('oracle') or the true f_c multiplied by 10^U, U ~ U(-0.5, 0.5) ('uncertain');
  * candidate bands: log-spaced N = 20, f_max = 100 kHz, f_min = 10, 3, 1, 0.3 kHz (as in the band-design study);
  * Algorithm 2: bands with f_min <= f_c^exp are referred to the full Cole model; otherwise D and Gamma are computed from
    the pilot circuit evaluated (extrapolated) at the candidate frequencies; if Gamma >= 2^(1/alpha) the band is classified
    by f_min < Gamma f_c^exp, else it is referred.
The classification is compared with the observed profile-likelihood identifiability of log10 tau on a simulated measurement
in that band (e5_band_runs.csv, design 'base', N = 20, 2.5 % noise). A naive variant applies f_min < Gamma f_c^exp to every
band without the domain restrictions."""
import sys, math, json, numpy as np, pandas as pd
from pathlib import Path
from pathlib import Path
HERE = Path(__file__).resolve().parent              # src/revision
ROOT = str(HERE.parents[1])                            # repository root (contains src/review and results/)
sys.path.insert(0, ROOT + '/src/review')
import r2_core as R
OUT = HERE/'out_C'; OUT.mkdir(exist_ok=True); LN10 = math.log(10)
FMIN = [10e3, 3e3, 1e3, 300.0]; FC = {'low': (100, 1000), 'mid': (1000, 10000), 'near': (10000, 30000)}; NS = 20

def truth(i, fc_rng):
    rng = np.random.default_rng(424242 + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(*np.log10(fc_rng)); tau = 1/(2*np.pi*fc); dR = rng.uniform(1, 3)*Rinf
    return dict(Rinf=Rinf, dR=dR, tau=tau, alpha=a, L=L, fc=fc)
def zcole(p, w): return p['Rinf'] + p['dR']/(1 + (1j*w*p['tau'])**p['alpha']) + 1j*w*p['L']
def stack(c): return np.r_[c.real, c.imag]
def D_factor(w, Rinf, Q, alpha, L, absZ):
    jw = 1j*w; cpe = jw**(-alpha)/Q
    J = np.column_stack([stack(c) for c in [Rinf/absZ, -cpe/absZ, -np.log(jw)*cpe/absZ, jw*L/absZ]])
    ht = stack(cpe*(1j*w/w.min())**(-alpha)/absZ); P = np.eye(len(ht)) - J @ np.linalg.pinv(J); return float(np.linalg.norm(P @ ht))

E5 = pd.read_csv(Path(ROOT)/'results/tables/e5_band_runs.csv'); E5 = E5[(E5.design == 'base') & (E5.N == 20)].set_index(['fc_class', 'spectrum', 'fmin_hz'])
fpil = np.arange(1, 11)*1e4; wpil = 2*np.pi*fpil; rows = []
for ci, (fcn, fcr) in enumerate(FC.items()):
    for i in range(NS):
        x = truth(i, fcr); prng = np.random.default_rng(777000 + 100*ci + i)
        z0 = zcole(x, wpil); e = prng.standard_normal((2, len(fpil))); zp = z0 + 0.025*np.abs(z0)*(e[0] + 1j*e[1])/math.sqrt(2)
        P = R.fit('rcpe_l', fpil, zp)['params']; F10 = R.fit('cole_l', fpil, zp); sig = math.sqrt(F10['rss']/(2*len(fpil) - 5))
        a = float(np.clip(P['alpha'], 0.3, 1.0)); U = prng.uniform(-0.5, 0.5)
        for scen, fc_exp in (('oracle', x['fc']), ('uncertain', x['fc']*10**U)):
            for fmin in FMIN:
                f = np.logspace(np.log10(fmin), 5, 20); w = 2*np.pi*f
                Zp = P['Rinf'] + (1j*w)**(-a)/P['Q'] + 1j*w*P['L']            # pilot circuit, extrapolated
                D = D_factor(w, P['Rinf'], P['Q'], a, P['L'], np.maximum(np.abs(Zp), 1.0))
                G = (a*LN10*D/(2*1.96*sig))**(1/a)
                naive = bool(fmin < G*fc_exp)
                if fmin <= fc_exp: branch, pred = 'within_band_referred', None
                elif G >= 2**(1/a): branch, pred = 'closed_form', naive
                else: branch, pred = 'boundary_outside_referred', None
                obs = bool(E5.loc[(fcn, i, fmin), 'tau_ident'])
                rows.append(dict(fc_class=fcn, spectrum=i, scenario=scen, fmin_hz=fmin, fc=x['fc'], fc_exp=fc_exp, sigma_pilot=sig, alpha_pilot=a,
                                 D=D, Gamma=G, branch=branch, pred=pred, naive=naive, obs=obs))
C = pd.DataFrame(rows); C.to_csv(OUT/'EC_runs.csv', index=False)
res = {}
for scen, g in C.groupby('scenario'):
    cf = g[g.branch == 'closed_form']; r = dict(n=len(g))
    for b, h in g.groupby('branch'): r[f'n_{b}'] = len(h); r[f'obs_ident_pct_{b}'] = float(100*h.obs.mean())
    if len(cf):
        p = cf.pred.astype(bool); o = cf.obs
        r.update(closed_form_accuracy_pct=float(100*(p == o).mean()), closed_form_false_pos=int((p & ~o).sum()), closed_form_false_neg=int((~p & o).sum()),
                 closed_form_pred_ident=int(p.sum()), closed_form_obs_ident=int(o.sum()))
    # combined rule: closed form where decided; referred bands decided by the band-design rule (within band -> identifiable)
    comb = np.where(g.branch == 'closed_form', g.pred.fillna(False).astype(bool), np.where(g.branch == 'within_band_referred', True, g.naive))
    r['combined_accuracy_pct'] = float(100*(comb == g.obs.values).mean())
    r['naive_accuracy_pct'] = float(100*(g.naive == g.obs).mean())
    r['naive_false_pos'] = int((g.naive & ~g.obs).sum()); r['naive_false_neg'] = int((~g.naive & g.obs).sum())
    res[scen] = r
json.dump(res, open(OUT/'EC_stats.json', 'w'), indent=2); print(json.dumps(res, indent=2))
print(C.groupby(['scenario', 'branch']).agg(n=('obs', 'size'), obs_ident=('obs', 'mean')).round(2))
