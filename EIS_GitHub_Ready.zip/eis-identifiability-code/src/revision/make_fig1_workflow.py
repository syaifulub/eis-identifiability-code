"""Redraw Fig1 (workflow) and Fig5 (decision rule) as vector graphics for the manuscript (the Fig5 drawn here is superseded by make_fig5_decision.py).
Font: Liberation Sans (metric-compatible with Arial), embedded as TrueType (fonttype 42)."""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

from pathlib import Path
out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent/'figures'
out.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "Liberation Sans", "pdf.fonttype": 42, "ps.fonttype": 42,
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans",
                     "mathtext.it": "Liberation Sans:italic", "mathtext.bf": "Liberation Sans:bold"})
BLUE, BLUEF = "#1f5fa5", "#e8f0fb"
MM = 1 / 25.4


def box(ax, x, y, w, h, ec="black", fc="white", lw=1.0, r=0.012):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}",
                                ec=ec, fc=fc, lw=lw, transform=ax.transAxes))


def arrow(ax, x0, y0, x1, y1, ls="-"):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), xycoords="axes fraction",
                arrowprops=dict(arrowstyle="-|>", lw=0.9, color="black", linestyle=ls,
                                shrinkA=0, shrinkB=0, mutation_scale=8))


# ---------------- Fig 1: workflow ----------------
fig = plt.figure(figsize=(174 * MM, 82 * MM))
ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
stages = [
    (1, "Data and quality control", ["20 in vivo spectra, 10–100 kHz", "51 repeated sweeps",
                                     "Kramers–Kronig check:", "12 consistent, 8 not"], False),
    (2, "Circuit representation", ["11 candidate circuits (AICc, BIC)", "R–CPE–L (M11), Cole+L (M10),",
                                   "double Cole+L (M12)", "Measurement-chain corrections"], False),
    (3, "Inversion", ["Original vs variable projection", "13 algorithms, equal budget",
                      "(2,000 evaluations, 25 runs)", "Mechanism control, timing"], True),
    (4, "Uncertainty, identifiability", ["Error model from sweeps", "Calibrated profile likelihood",
                                         "Closed-form band criterion", "Band-design simulation"], True),
    (5, "Reproducibility", ["Between sweeps: drift", "Between recordings: 35",
                            "single-frequency recordings", "Per animal"], False),
    (6, "Reporting", ["Decision rule (Fig. 5)", "Calibrated intervals,", "reproducibility limits"], False),
]
W, H = 0.30, 0.40
xs = [0.02, 0.35, 0.68]
pos = {1: (xs[0], 0.56), 2: (xs[1], 0.56), 3: (xs[2], 0.56), 6: (xs[0], 0.04), 5: (xs[1], 0.04), 4: (xs[2], 0.04)}
for n, title, lines, hl in stages:
    x, y = pos[n]
    box(ax, x, y, W, H, ec=BLUE if hl else "black", fc=BLUEF if hl else "white", lw=1.3 if hl else 1.0)
    ax.text(x + 0.018, y + H - 0.075, str(n), color=BLUE, fontsize=11, fontweight="bold",
            transform=ax.transAxes, va="center")
    ax.text(x + 0.05, y + H - 0.075, title, fontsize=9.5, fontweight="bold", transform=ax.transAxes, va="center")
    for i, t in enumerate(lines):
        ax.text(x + 0.018, y + H - 0.17 - i * 0.065, t, fontsize=8, transform=ax.transAxes, va="center")
gap = xs[1] - xs[0] - W
for a, b in [(0, 1), (1, 2)]:
    arrow(ax, xs[a] + W + 0.006, 0.76, xs[b] - 0.006, 0.76)
    arrow(ax, xs[b] - 0.006, 0.24, xs[a] + W + 0.006, 0.24)
arrow(ax, xs[2] + W / 2, 0.555, xs[2] + W / 2, 0.445)
for ext in ("pdf", "eps"):
    fig.savefig(f"{out}/Fig1_workflow.{ext}")
fig.savefig(f"{out}/Fig1_workflow_preview.png", dpi=150)
plt.close(fig)

# ---------------- Fig 5: decision rule ----------------
fig = plt.figure(figsize=(160 * MM, 128 * MM))
ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
fs = 8


def diamond(cx, cy, w, h, txt):
    ax.add_patch(Polygon([(cx - w / 2, cy), (cx, cy + h / 2), (cx + w / 2, cy), (cx, cy - h / 2)],
                         closed=True, ec="black", fc="#f5f5f5", lw=1.0, transform=ax.transAxes))
    ax.text(cx, cy, txt, ha="center", va="center", fontsize=fs, transform=ax.transAxes, linespacing=1.35)


def tbox(x, y, w, h, txt, ec="black", fc="white", bold=False):
    box(ax, x, y, w, h, ec=ec, fc=fc, lw=1.1)
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=fs, transform=ax.transAxes,
            linespacing=1.35, fontweight="bold" if bold else "normal")


tbox(0.28, 0.905, 0.44, 0.075, r"Measured spectrum $Z(f)$ on band $[f_{\min},\,f_{\max}]$", bold=True)
arrow(ax, 0.5, 0.905, 0.5, 0.865)
diamond(0.5, 0.80, 0.34, 0.13, "Linear Kramers–Kronig\nRMS residual < 3%?")
arrow(ax, 0.67, 0.80, 0.725, 0.80)
ax.text(0.675, 0.815, "no", fontsize=fs, style="italic", transform=ax.transAxes)
tbox(0.73, 0.725, 0.26, 0.15, "Flag; do not interpret\nparameters physically;\nre-measure, or report as\nKK-inconsistent with\nreproducibility limits",
     ec="#a3202e", fc="#fdecec")
arrow(ax, 0.5, 0.735, 0.5, 0.695)
ax.text(0.51, 0.712, "yes", fontsize=fs, style="italic", transform=ax.transAxes)
tbox(0.16, 0.595, 0.68, 0.095, "Fit Cole+L and R–CPE–L by variable projection with multistart refinement;\n"
     "calibrate profile-likelihood thresholds to the error model of the instrument")
arrow(ax, 0.5, 0.595, 0.5, 0.555)
diamond(0.5, 0.47, 0.72, 0.17, r"$f_{\min}\leq f_c$ and, for every Cole parameter" "\n"
        "to be reported, a calibrated 95% interval\n" r"that is closed and < 1 decade (< 0.2 for $\alpha$)?")
# yes branch (left)
ax.plot([0.14, 0.12, 0.12], [0.47, 0.47, 0.40], color="black", lw=0.9, transform=ax.transAxes)
arrow(ax, 0.12, 0.40, 0.12, 0.375)
ax.text(0.09, 0.485, "yes", fontsize=fs, style="italic", transform=ax.transAxes)
# no branch (right)
ax.plot([0.86, 0.88, 0.88], [0.47, 0.47, 0.40], color="black", lw=0.9, transform=ax.transAxes)
arrow(ax, 0.88, 0.40, 0.88, 0.375)
ax.text(0.885, 0.485, "no", fontsize=fs, style="italic", transform=ax.transAxes)
tbox(0.01, 0.175, 0.24, 0.20, "Report those Cole\nparameters with calibrated\nintervals; leave out any\nthat fail the criterion",
     ec=BLUE, fc=BLUEF)
tbox(0.75, 0.175, 0.24, 0.20, r"Report $R_\infty$, $Q$, $\alpha$ that" "\nmeet the same criterion\n"
     "(band-specific; state band,\ncorrection model and probe);\n" r"do not interpret $\tau$, $\Delta R$, $R_0$, $f_c$",
     ec=BLUE, fc=BLUEF)
tbox(0.29, 0.175, 0.42, 0.20, "With repeated sweeps or recordings, add\nthe reproducibility half-width or limit;\n"
     r"state the detection limit $f_{\min}/\Gamma$ (Eq. 9) and" "\nthe descriptor bias (Eq. 10)", ec="#555555")
arrow(ax, 0.255, 0.275, 0.285, 0.275)
arrow(ax, 0.745, 0.275, 0.715, 0.275)
ax.plot([0.87, 0.87], [0.175, 0.085], color="black", lw=0.9, ls=(0, (3, 2)), transform=ax.transAxes)
arrow(ax, 0.87, 0.085, 0.735, 0.085, ls=(0, (3, 2)))
tbox(0.27, 0.015, 0.46, 0.135, "To estimate Cole parameters: extend the band to\n"
     r"$f_{\min}\leq f_c$ of the target tissue, control electrode" "\npolarization (e.g. tetrapolar) and repeat the assessment",
     ec="#a0581b", fc="#fdf6e3")
for ext in ("pdf", "eps"):
    fig.savefig(f"{out}/Fig5_decision_rule.{ext}")
fig.savefig(f"{out}/Fig5_decision_rule_preview.png", dpi=150)
plt.close(fig)
print("done")
