"""Fig 5 (decision rule), redrawn with larger lettering and a top-to-bottom layout (current version)."""
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

from pathlib import Path
out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent/'figures'
out.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "Liberation Sans", "pdf.fonttype": 42, "ps.fonttype": 42,
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans",
                     "mathtext.it": "Liberation Sans:italic", "mathtext.bf": "Liberation Sans:bold"})
MM = 1 / 25.4
FS = 9.5
BLUE, BLUEF = "#1f5fa5", "#e8f0fb"
fig = plt.figure(figsize=(150 * MM, 185 * MM))
ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
T = ax.transAxes


def box(x, y, w, h, txt, ec="black", fc="white", bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.012",
                                ec=ec, fc=fc, lw=1.1, transform=T))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=FS, transform=T,
            linespacing=1.3, fontweight="bold" if bold else "normal")


def diamond(cx, cy, w, h, txt):
    ax.add_patch(Polygon([(cx - w / 2, cy), (cx, cy + h / 2), (cx + w / 2, cy), (cx, cy - h / 2)],
                         closed=True, ec="black", fc="#f5f5f5", lw=1.1, transform=T))
    ax.text(cx, cy, txt, ha="center", va="center", fontsize=FS, transform=T, linespacing=1.3)


def arrow(x0, y0, x1, y1, ls="-"):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), xycoords="axes fraction",
                arrowprops=dict(arrowstyle="-|>", lw=1.0, color="black", linestyle=ls,
                                shrinkA=0, shrinkB=0, mutation_scale=9))


def label(x, y, t):
    ax.text(x, y, t, fontsize=FS, style="italic", transform=T)


# 1 measured spectrum
box(0.22, 0.925, 0.56, 0.055, r"Measured spectrum $Z(f)$ on $[f_{\min},\,f_{\max}]$", bold=True)
arrow(0.5, 0.925, 0.5, 0.895)
# 2 KK diamond + flag box
diamond(0.37, 0.835, 0.52, 0.11, "Linear Kramers–Kronig\nRMS residual < 3%?")
arrow(0.63, 0.835, 0.67, 0.835); label(0.635, 0.845, "no")
box(0.675, 0.775, 0.31, 0.12, "Flag; do not interpret\nparameters physically;\nre-measure, or report as\nKK-inconsistent with\nreproducibility limits",
    ec="#a3202e", fc="#fdecec")
arrow(0.37, 0.78, 0.37, 0.745); label(0.38, 0.755, "yes")
# 3 fit box
box(0.03, 0.665, 0.68, 0.08, "Fit Cole+L and R–CPE–L by variable projection\nwith multistart refinement; calibrate profile-likelihood\nthresholds to the error model of the instrument")
arrow(0.37, 0.665, 0.37, 0.635)
# 4 identifiability diamond
diamond(0.5, 0.545, 0.94, 0.18, r"$f_{\min}\leq f_c$, and for every Cole parameter" "\nto be reported a conditionally calibrated\n95% interval that is closed and narrower\n" r"than 1 decade (0.2 for $\alpha$)?")
ax.plot([0.03, 0.01, 0.01], [0.545, 0.545, 0.43], color="black", lw=1.0, transform=T)
arrow(0.01, 0.43, 0.01, 0.415); label(0.015, 0.56, "yes")
ax.plot([0.97, 0.99, 0.99], [0.545, 0.545, 0.43], color="black", lw=1.0, transform=T)
arrow(0.99, 0.43, 0.99, 0.415); label(0.95, 0.56, "no")
# 5 yes / no boxes
box(0.0, 0.275, 0.44, 0.14, "Report those Cole parameters\nwith conditionally calibrated\nintervals; leave out any that\nfail the criterion", ec=BLUE, fc=BLUEF)
box(0.56, 0.275, 0.44, 0.14, r"Report $R_\infty$, $Q$, $\alpha$ that meet the" "\ncriterion (band-specific; state band,\ncorrection model and probe);\n" r"do not interpret $\tau$, $\Delta R$, $R_0$, $f_c$", ec=BLUE, fc=BLUEF)
# 6 common box
arrow(0.22, 0.275, 0.22, 0.235); arrow(0.78, 0.275, 0.78, 0.235)
box(0.08, 0.135, 0.84, 0.10, "With repeated sweeps or recordings, add the reproducibility half-width or limit;\n"
    r"state the detection limit $f_{\min}/\Gamma$ (Eq. 9) and the descriptor bias (Eq. 10)", ec="#555555")
# 7 band extension (from no box)
ax.plot([0.995, 0.995], [0.275, 0.07], color="black", lw=1.0, ls=(0, (3, 2)), transform=T)
arrow(0.995, 0.07, 0.93, 0.07, ls=(0, (3, 2)))
box(0.08, 0.01, 0.84, 0.105, "To estimate Cole parameters: extend the band to " r"$f_{\min}\leq f_c$" " of the target\n"
    "tissue, control electrode polarization (e.g. tetrapolar electrodes)\nand repeat the assessment", ec="#a0581b", fc="#fdf6e3")
for ext in ("pdf", "eps"):
    fig.savefig(f"{out}/Fig5_decision_rule.{ext}")
fig.savefig(f"{out}/Fig5_preview.png", dpi=110)
print("ok")
