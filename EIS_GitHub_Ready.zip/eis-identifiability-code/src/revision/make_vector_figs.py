"""Vector versions of Fig. 2 (coverage), Fig. 3 (closed-form criterion) and Fig. 4 (band design) for the manuscript.
Same data and encodings as src/review/r2_figs.py and e10_fig.py; sized for the printed width (sn-jnl text width 131 mm),
lettering >= 8 pt (Liberation Sans, Arial-metric, embedded as TrueType), panel labels instead of in-figure titles."""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
HERE = Path(__file__).resolve().parent; T = HERE.parents[1]/'results/tables'
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE/'figures'; OUT.mkdir(parents=True, exist_ok=True)
MM = 1/25.4
C1, C2, C3, C4, C5, C6, C7 = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6'
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.size': 8.5, 'axes.labelsize': 8.5, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8,
                     'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                     'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'Liberation Sans',
                     'mathtext.fontset': 'custom', 'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic',
                     'mathtext.bf': 'Liberation Sans:bold', 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.linewidth': 0.7,
                     'xtick.major.width': 0.7, 'ytick.major.width': 0.7})
def label(a, s, x=-0.16, y=1.04): a.text(x, y, s, transform=a.transAxes, fontsize=9.5, fontweight='bold', va='bottom', ha='left')
def save(fig, name, tight=False):
    kw = dict(bbox_inches='tight', pad_inches=0.03) if tight else {}
    for ext in ('pdf', 'eps'): fig.savefig(OUT/f'{name}.{ext}', **kw)
    fig.savefig(OUT/f'{name}_preview.png', dpi=150, **kw); plt.close(fig)
def wilson(k, n, z=1.96):
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d; h = z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h, c+h

# ---------------- Fig. 2: coverage ----------------
Cv = pd.read_csv(T/'e1_coverage_runs_M11.csv')
meth = [('Nominal $\\chi^2$', lambda d: d.lr_nom <= 3.84, C1, 'o'), ('Calibrated', lambda d: d.lr_nom <= d.c_nom, C2, 's'),
        ('GLS $\\chi^2$', lambda d: d.lr_gls <= 3.84, C3, '^'), ('GLS calibrated', lambda d: d.lr_gls <= d.c_gls, C7, 'D')]
conds = [('emp', 'Empirical'), ('rho_lo', '$\\rho_f-0.2$'), ('rho_hi', '$\\rho_f+0.2$'), ('white', 'White'), ('ar1', 'AR(1)')]
pars = [('log10_Q', '(a) $\\log_{10}Q$'), ('alpha', '(b) $\\alpha$'), ('log10_Rinf', '(c) $\\log_{10}R_\\infty$')]
fig, ax = plt.subplots(1, 3, figsize=(131*MM, 70*MM), sharey=True)
for a, (p, pl) in zip(ax, pars):
    a.axhline(95, color=INK2, lw=0.9, ls='--', zorder=0); a.grid(axis='y', color=GRID, lw=0.5); a.set_axisbelow(True)
    for mi, (mn, fn, col, mk) in enumerate(meth):
        xs, ys, lo, hi = [], [], [], []
        for ci, (c, cl) in enumerate(conds):
            d = Cv[(Cv.cond == c) & (Cv.param == p)]; k = int(fn(d).sum()); n = len(d); l, h = wilson(k, n)
            xs.append(ci + (mi-1.5)*0.17); ys.append(100*k/n); lo.append(100*(k/n-l)); hi.append(100*(h-k/n))
        a.errorbar(xs, ys, yerr=[lo, hi], fmt=mk, ms=3.6, color=col, mec='white', mew=0.4, elinewidth=0.9, capsize=0, label=mn)
    a.set_xticks(range(len(conds))); a.set_xticklabels([c[1] for c in conds], rotation=45, ha='right'); a.set_ylim(60, 101)
    a.text(0.0, 1.02, pl, transform=a.transAxes, fontsize=9, fontweight='bold', va='bottom')
ax[0].set_ylabel('Coverage of nominal 95% interval (%)')
fig.legend(*ax[0].get_legend_handles_labels(), loc='upper center', ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.0), handletextpad=0.3, columnspacing=1.0)
fig.tight_layout(rect=(0, 0, 1, 0.9), w_pad=0.6); save(fig, 'Fig2_coverage')

# ---------------- Fig. 3: closed-form criterion (2 + 1 layout) ----------------
A = pd.read_csv(T/'e10_synthetic.csv'); B = pd.read_csv(T/'e10_bias.csv'); M = pd.read_csv(T/'Table_E10_measured.csv')
fig = plt.figure(figsize=(131*MM, 122*MM)); gs = fig.add_gridspec(2, 4, hspace=0.42, wspace=0.9)
a = fig.add_subplot(gs[0, 0:2]); g = A[A.design.isin(['base', 'linear', 'corr']) & A.closed]
for lo, hi, col, lab in [(0, 1, '#cde2fb', '$<1$'), (1, 3, '#86b6ef', '1–3'), (3, 10, '#2a78d6', '3–10'), (10, 1e4, '#104281', '$>10$')]:
    h = g[(g.ratio >= lo) & (g.ratio < hi)]; a.scatter(h.W_asym, h.W_prof, s=6, color=col, edgecolor='none', label=lab, alpha=0.9)
lim = [3e-4, 30]; a.plot(lim, lim, color=INK2, lw=0.8); a.axhline(1, color=INK2, lw=0.6, ls='--'); a.axvline(1, color=INK2, lw=0.6, ls='--')
a.set_xscale('log'); a.set_yscale('log'); a.set_xlim(lim); a.set_ylim(lim)
a.set_xlabel('Predicted width, Eq. (8) (decades)'); a.set_ylabel('Profile-likelihood width (decades)')
a.legend(title='$f_{\\min}/f_c$', frameon=False, loc='upper left', markerscale=1.6, handletextpad=0.2, borderaxespad=0.2, labelspacing=0.3); label(a, '(a)', -0.2)
a = fig.add_subplot(gs[0, 2:4]); m = B.groupby('fmin_over_fc')[['bias_logQ_num', 'bias_logQ_formula', 'bias_alpha_num', 'bias_alpha_formula']].median(); x = m.index.values
a.plot(x, m.bias_logQ_formula, color=C1, lw=1.4, label='$\\log_{10}Q$, Eq. (10)'); a.plot(x, m.bias_logQ_num, 'o', color=C1, ms=4, mec='white', mew=0.5, label='$\\log_{10}Q$, refit')
a.plot(x, -m.bias_alpha_formula, color=C2, lw=1.4, label='$-\\alpha$, Eq. (10)'); a.plot(x, -m.bias_alpha_num, 's', color=C2, ms=4, mec='white', mew=0.5, label='$-\\alpha$, refit')
a.set_xscale('log'); a.set_yscale('log'); a.set_xlabel('$f_{\\min}/f_c$'); a.set_ylabel('Bias of R–CPE–L descriptor'); a.grid(color=GRID, lw=0.5); a.set_axisbelow(True)
a.legend(frameon=False, loc='lower left', handletextpad=0.3, borderaxespad=0.2, labelspacing=0.3); label(a, '(b)', -0.2)
a = fig.add_subplot(gs[1, 1:3])
for kk, mk, col, lab in [(True, 'o', C1, 'KK-consistent'), (False, 's', C2, 'KK-inconsistent')]:
    h = M[(M.kk_ok == kk) & (M.fc_detect_hz < 1e5)]; a.plot(h.fc_detect_hz, h.fc_ci_high_hz, mk, color=col, ms=4, mec='white', mew=0.5, label=lab, ls='none')
lim = [3e2, 1e5]; a.plot(lim, lim, color=INK2, lw=0.8); a.set_xscale('log'); a.set_yscale('log'); a.set_xlim(lim); a.set_ylim(lim)
a.set_xlabel('Detection limit $f_{\\min}/\\Gamma$ (Hz)'); a.set_ylabel('Upper 95% bound of $f_c$ (Hz)')
a.legend(frameon=False, loc='upper left', handletextpad=0.2, borderaxespad=0.2); label(a, '(c)', -0.2)
save(fig, 'Fig3_band_criterion')

# ---------------- Fig. 4: band design (stacked) ----------------
S = pd.read_csv(T/'Table_E5_band_factorial.csv'); D = pd.read_csv(T/'e5_band_runs.csv')
fig = plt.figure(figsize=(131*MM, 92*MM)); ax = [fig.add_axes([0.105, 0.43, 0.375, 0.5]), fig.add_axes([0.6, 0.43, 0.375, 0.5])]
a = ax[0]; fmin = [10e3, 3e3, 1e3, 300.0]
for fc, col, lab in [('near', C3, '$f_c$ 10–30 kHz'), ('mid', C1, '$f_c$ 1–10 kHz'), ('low', C2, '$f_c$ 0.1–1 kHz')]:
    for N, ls, mk in [(20, '-', 'o'), (10, ':', 's')]:
        y = [S[(S.design == 'base') & (S.N == N) & (S.fc_class == fc) & (S.fmin_hz == f)].tau_ident_pct.iloc[0] for f in fmin]
        a.plot(fmin, y, ls=ls, marker=mk, ms=3.4, lw=1.3 if N == 20 else 1.0, color=col, mec='white', mew=0.4, label=f'{lab}, $N$={N}')
a.set_xscale('log'); a.invert_xaxis(); a.set_xticks(fmin); a.set_xticklabels(['10k', '3k', '1k', '300']); a.minorticks_off()
a.set_xlabel('Lower band limit $f_{\\min}$ (Hz)'); a.set_ylabel('$\\log_{10}\\tau$ identifiable (%)'); a.set_ylim(-3, 103)
a.grid(color=GRID, lw=0.5); a.set_axisbelow(True); label(a, '(a)', -0.22)
a.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.45, -0.22), ncol=1, labelspacing=0.2, handlelength=2.0)
a = ax[1]; bins = ['<0.3', '0.3–1', '1–3', '3–10', '>10']
D['ratio_bin'] = pd.cut(D.ratio_fmin_fc, [0, 0.3, 1, 3, 10, 1e4], labels=bins)
for (dz, N), col, mk, lab in [(('base', 20), C1, 'o', 'White noise'), (('corr', 20), C3, '^', 'Correlated noise'), (('linear', 20), C4, 'v', 'Linear grid'),
                              (('ep10', 20), C5, 's', 'Electrode pol. 10%'), (('ep50', 20), C2, 'D', 'Electrode pol. 50%'), (('mis', 20), C7, 'P', 'Model mismatch')]:
    q = D[(D.design == dz) & (D.N == N)].groupby('ratio_bin', observed=False).tau_ident.mean().mul(100).reindex(bins)
    a.plot(range(5), q.values, marker=mk, ms=3.4, lw=1.1, color=col, mec='white', mew=0.4, label=lab)
a.set_xticks(range(5)); a.set_xticklabels(bins); a.set_xlabel('$f_{\\min}/f_c$'); a.set_ylim(-3, 103)
a.grid(color=GRID, lw=0.5); a.set_axisbelow(True); label(a, '(b)', -0.12)
a.legend(frameon=False, loc='upper center', bbox_to_anchor=(0.45, -0.22), ncol=1, labelspacing=0.2)
save(fig, 'Fig4_band_design', tight=True)
print('ok')
