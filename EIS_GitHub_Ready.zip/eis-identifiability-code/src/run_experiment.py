"""
run_experiment.py - Revised confirmatory pipeline for the ASHO-LSHADE tissue-EIS manuscript.
Usage: python run_experiment.py [--quick]
"""
import sys, os, re, json, math, time, zipfile, hashlib, platform, warnings
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import least_squares
from scipy.stats import friedmanchisquare, wilcoxon, rankdata
warnings.filterwarnings('ignore')
sys.path.insert(0, str(Path(__file__).parent))
from eis_core import *

QUICK = '--quick' in sys.argv
HERE = Path(__file__).resolve().parent.parent   # package root (outputs go to <root>/results)
RAW_ZIP = Path(os.environ.get('EIS_RAW_ZIP', HERE/'PreparedData.zip'))
OUT = HERE/('results_quick' if QUICK else 'results'); TAB = OUT/'tables'; OUT.mkdir(exist_ok=True); TAB.mkdir(exist_ok=True)
CACHE = OUT/'cache'; CACHE.mkdir(exist_ok=True)
import pickle
def cached(key, fn):
    p = CACHE/(re.sub(r'[^A-Za-z0-9_.-]', '_', key)+'.pkl')
    if p.exists(): return pickle.load(open(p, 'rb'))
    v = fn(); pickle.dump(v, open(p, 'wb')); return v
SEED0 = 20261101
RUNS, BUDGET = (3, 600) if QUICK else (25, 2000)
EXT_RUNS, EXT_BUDGET = (2, 2000) if QUICK else (10, 10000)
CPS = (100, 200, 500, 1000, 1500, 2000)
SYN_N, SYN_RUNS = (3, 2) if QUICK else (10, 10)
ECM_STARTS = 5 if QUICK else 20
def log(*a):
    print(time.strftime('%H:%M:%S'), *a, flush=True)

# =================================================================== 1. data
COLS = ['device_state','frequency_khz','magnitude_ohm','phase_deg','resistance_ohm','reactance_ohm','timestamp_scaled','tissue']
TARGET_FREQ = np.arange(10, 101, 10, dtype=float)   # kHz
def preprocess(zip_path):
    frames, qc = [], []
    with zipfile.ZipFile(zip_path) as zf:
        for name in sorted(n for n in zf.namelist() if n.lower().endswith('.txt') and '/byExperimentalTask/' in n):
            with zf.open(name) as fh:
                d = pd.read_csv(fh, sep=';', comment='%', header=None, names=COLS, engine='python')
            d = d.dropna(subset=['frequency_khz','resistance_ohm','reactance_ohm'])
            if len(d) == 0:
                qc.append({'source_file': Path(name).name, 'subset': Path(name).parent.name, 'tissue': '', 'raw_rows': 0,
                           'rows_after_exact_dedup': 0, 'exact_duplicates_removed': 0, 'n_frequencies': 0, 'frequencies_khz': ''})
                continue
            before = len(d); d = d.drop_duplicates(); after = len(d)
            d['source_file'] = Path(name).name; d['subset'] = Path(name).parent.name
            frames.append(d); fr = np.sort(d.frequency_khz.unique())
            qc.append({'source_file': Path(name).name, 'subset': Path(name).parent.name, 'tissue': d.tissue.iloc[0],
                       'raw_rows': before, 'rows_after_exact_dedup': after, 'exact_duplicates_removed': before-after,
                       'n_frequencies': len(fr), 'frequencies_khz': ','.join(f'{x:g}' for x in fr)})
    raw = pd.concat(frames, ignore_index=True)
    reps = (raw.groupby(['subset','source_file','tissue','frequency_khz'], as_index=False)
            .agg(resistance_ohm=('resistance_ohm','median'), reactance_ohm=('reactance_ohm','median'),
                 resistance_iqr_ohm=('resistance_ohm', lambda x: np.subtract(*np.percentile(x,[75,25]))),
                 reactance_iqr_ohm=('reactance_ohm', lambda x: np.subtract(*np.percentile(x,[75,25]))),
                 n_obs=('resistance_ohm','size')))
    reps['frequency_hz'] = 1000*reps.frequency_khz
    comp = [g for _, g in reps.groupby('source_file') if np.array_equal(np.sort(g.frequency_khz.unique()), TARGET_FREQ)]
    return pd.DataFrame(qc), pd.concat(comp, ignore_index=True)

qc, complete = preprocess(RAW_ZIP)
qc.to_csv(TAB/'file_qc_summary.csv', index=False); complete.to_csv(TAB/'ecm_ready_complete_scans.csv', index=False)
SPECTRA = []
for si, (sf, g) in enumerate(complete.groupby('source_file')):
    g = g.sort_values('frequency_hz')
    SPECTRA.append(dict(si=si, sf=sf, tissue=g.tissue.iloc[0], w=2*np.pi*g.frequency_hz.to_numpy(float),
                        z=g.resistance_ohm.to_numpy(float) + 1j*g.reactance_ohm.to_numpy(float)))
if QUICK: SPECTRA = SPECTRA[:4]
used = qc[qc.source_file.isin([s['sf'] for s in SPECTRA])]
log('complete spectra:', len(SPECTRA), '| raw rows', int(used.raw_rows.sum()), '-> dedup', int(used.rows_after_exact_dedup.sum()))

# ======================================================== 2. ECM screening
def cpe(w,Q,a): return 1/(Q*(1j*w)**a)
def par(z1,z2): return 1/(1/z1+1/z2)
def ecm_predict(model, x, w):
    x = np.asarray(x, float); p = 10**x
    if model=='M1_SeriesRC': return p[0] + 1/(1j*w*p[1])
    if model=='M2_FrickeMorse': return p[0] + par(p[1], 1/(1j*w*p[2]))
    if model=='M3_SingleCole': return p[0] + p[1]/(1+(1j*w*p[2])**x[3])
    if model=='M4_RandlesCPE': return p[0] + par(p[1], cpe(w,p[2],x[3]))
    if model=='M5_DoubleRC': return p[0] + par(p[1],1/(1j*w*p[2])) + par(p[3],1/(1j*w*p[4]))
    if model=='M6_FrickeCPE': return p[0] + par(p[1], cpe(w,p[2],x[3]))
    if model=='M7_DoubleCPE': return p[0] + par(p[1],cpe(w,p[3],x[5])) + par(p[2],cpe(w,p[4],x[6]))
    if model=='M8_DoubleCole': return p[0] + p[1]/(1+(1j*w*p[2])**x[5]) + p[3]/(1+(1j*w*p[4])**x[6])
    if model=='M9_ColeElectrodeCPE': return p[0] + cpe(w,p[4],x[6]) + p[1] + p[2]/(1+(1j*w*p[3])**x[5])
    if model=='M10_ColeL': return predict('M10_ColeL', x, w)
    if model=='M11_RCPEL': return predict('M11_RCPEL', x, w)
    raise KeyError(model)
SPECS = {
 'M1_SeriesRC':([-3,-12],[7,-1]), 'M2_FrickeMorse':([-3,-3,-12],[7,8,-1]),
 'M3_SingleCole':([-3,-3,-7,.3],[7,8,1,1]), 'M4_RandlesCPE':([-3,-3,-12,.3],[7,8,0,1]),
 'M5_DoubleRC':([-3,-3,-12,-3,-12],[7,8,-1,8,-1]), 'M6_FrickeCPE':([-3,-3,-12,.3],[7,8,0,1]),
 'M7_DoubleCPE':([-3,-3,-3,-12,-12,.3,.3],[7,8,8,0,0,1,1]), 'M8_DoubleCole':([-3,-3,-7,-3,-7,.3,.3],[7,8,1,8,1,1,1]),
 'M9_ColeElectrodeCPE':([-3,-3,-3,-7,-12,.3,.3],[7,7,8,1,0,1,1]),
 'M10_ColeL':(list(MODELS['M10_ColeL'][1]), list(MODELS['M10_ColeL'][2])),
 'M11_RCPEL':(list(MODELS['M11_RCPEL'][1]), list(MODELS['M11_RCPEL'][2]))}
def ecm_res(x, m, w, z):
    e = (ecm_predict(m, x, w) - z)/np.maximum(np.abs(z), 1.0); return np.r_[e.real, e.imag]
def _ecm_one(s):
    rows = []
    rng = np.random.default_rng(SEED0 + s['si'])
    for m, (lo, hi) in SPECS.items():
        lo, hi = np.array(lo, float), np.array(hi, float); best = None
        for _ in range(ECM_STARTS):
            r = least_squares(ecm_res, rng.uniform(lo, hi), bounds=(lo, hi), args=(m, s['w'], s['z']), max_nfev=4000)
            if best is None or r.cost < best.cost: best = r
        n = 2*len(s['w']); k = len(lo); rss = 2*best.cost   # weighted RSS: same metric as the fitting objective
        aic = n*np.log(rss/n) + 2*k
        rows.append(dict(source_file=s['sf'], tissue=s['tissue'], model=m, k=k, NRMSE=np.sqrt(rss/len(s['w'])),
                         AIC=aic, AICc=aic + 2*k*(k+1)/(n-k-1), BIC=n*np.log(rss/n) + k*np.log(n)))
    return rows
rows = []
for s in SPECTRA: rows += cached('ecm_'+s['sf'], lambda s=s: _ecm_one(s))
ecm = pd.DataFrame(rows)
ecm['AICc_rank'] = ecm.groupby('source_file').AICc.rank(method='min'); ecm['BIC_rank'] = ecm.groupby('source_file').BIC.rank(method='min')
ecm['dAICc'] = ecm.AICc - ecm.groupby('source_file').AICc.transform('min')
ecm_sum = (ecm.groupby('model').agg(k=('k','first'), median_NRMSE=('NRMSE','median'), mean_NRMSE=('NRMSE','mean'),
           mean_AICc_rank=('AICc_rank','mean'), AICc_wins=('AICc_rank', lambda x: int((x==1).sum())),
           median_dAICc=('dAICc','median'), within2_AICc=('dAICc', lambda x: int((x<=2).sum())),
           mean_BIC_rank=('BIC_rank','mean'), BIC_wins=('BIC_rank', lambda x: int((x==1).sum())))
           .sort_values('mean_AICc_rank'))
ecm.to_csv(TAB/'ecm_all_models.csv', index=False); ecm_sum.to_csv(TAB/'Table_ECM_screening.csv')
log('ECM screening done\n' + ecm_sum.round(4).to_string())

# ================================================== 3. confirmatory benchmark
def bench(models, algs, runs, budget, cps, tag):
    rows, traces = [], []; t0 = time.time()
    for model in models:
        names = MODELS[model][0]
        for s in SPECTRA:
          def _one(s=s, model=model, names=names):
            rows, traces = [], []
            for r in range(runs):
                seed = SEED0 + s['si']*1000 + r
                for a in algs:
                    x, fb, tr, ex, sec = run_algorithm(a, model, s['w'], s['z'], budget, seed, cps)
                    rows.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], algorithm=a, run=r+1, seed=seed,
                                     NFE=budget, NRMSE=math.sqrt(max(fb,0)), objective=fb, runtime_sec=sec, **ex,
                                     **{n: v for n, v in zip(names, x)}))
                    for c, v in tr.items(): traces.append((model, s['sf'], a, r+1, c, math.sqrt(max(v,0))))
            return rows, traces
          r_, t_ = cached(f'{tag}_{model}_{s["sf"]}', _one); rows += r_; traces += t_
          log(f'[{tag}] {model} {s["sf"][:32]} done ({time.time()-t0:.0f}s)')
    return pd.DataFrame(rows), pd.DataFrame(traces, columns=['model','source_file','algorithm','run','NFE','best_NRMSE'])

runs_df, trace_df = bench(['M10_ColeL','M11_RCPEL'], ALGORITHMS, RUNS, BUDGET, CPS, 'main')
runs_df.to_csv(TAB/'optimizer_runs.csv', index=False); trace_df.to_csv(TAB/'convergence_traces.csv', index=False)
ext_df, ext_tr = bench(['M10_ColeL','M11_RCPEL'], ['MS-TRF','L-SHADE','ASHO-LSHADE'], EXT_RUNS, EXT_BUDGET,
                       (500,1000,2000,5000,10000), 'ext')
ext_df.to_csv(TAB/'optimizer_runs_extended_budget.csv', index=False); ext_tr.to_csv(TAB/'convergence_traces_extended.csv', index=False)

# =========================================== 4. best-known reference solutions
ref = {}
for model in ['M10_ColeL','M11_RCPEL']:
    names = MODELS[model][0]
    for s in SPECTRA:
        cand = pd.concat([runs_df, ext_df])
        cand = cand[(cand.model==model)&(cand.source_file==s['sf'])].nsmallest(5, 'objective')[names].to_numpy()
        x, rss = cached(f'ref_{model}_{s["sf"]}', lambda: best_fit(model, s['w'], s['z'], list(cand), np.random.default_rng(SEED0+7+s['si']), 30 if not QUICK else 5))
        ref[(model, s['sf'])] = (x, rss/len(s['w']))
ref_df = pd.DataFrame([dict(model=m, source_file=sf, ref_objective=v[1], ref_NRMSE=math.sqrt(v[1]),
                            **{n: val for n, val in zip(MODELS[m][0], v[0])}) for (m, sf), v in ref.items()])
ref_df.to_csv(TAB/'best_known_solutions.csv', index=False)

def add_gap(df):
    df = df.merge(ref_df[['model','source_file','ref_NRMSE']], on=['model','source_file'])
    df['rel_gap'] = (df.NRMSE - df.ref_NRMSE)/df.ref_NRMSE
    df['success'] = df.rel_gap <= 1e-3      # within 0.1% of best-known NRMSE
    return df
runs_df = add_gap(runs_df); ext_df = add_gap(ext_df)
runs_df.to_csv(TAB/'optimizer_runs.csv', index=False); ext_df.to_csv(TAB/'optimizer_runs_extended_budget.csv', index=False)

# ======================================================= 5. statistics
def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); adj = np.empty_like(p); run = 0
    for rnk, j in enumerate(o):
        run = max(run, (len(p)-rnk)*p[j]); adj[j] = min(1, run)
    return adj
def boot_median(d, B=5000, seed=123):
    rng = np.random.default_rng(seed); d = np.asarray(d); n = len(d)
    v = np.array([np.median(d[rng.integers(0, n, n)]) for _ in range(B)])
    return np.median(d), np.quantile(v, .025), np.quantile(v, .975)
TIE = 1e-3   # relative NRMSE difference below 0.1% is treated as a practical tie
perf_rows, stat_rows, fried = [], [], {}
for model in ['M10_ColeL','M11_RCPEL']:
    d = runs_df[runs_df.model==model]
    med = d.groupby(['source_file','algorithm'], as_index=False).agg(NRMSE=('NRMSE','median'), success=('success','mean'),
          runtime=('runtime_sec','median'), rt=('rescue_trials','sum'), rs=('rescue_success','sum'),
          mean_pHO=('mean_pHO','mean'), final_pHO=('final_pHO','mean'))
    med['rank'] = med.groupby('source_file').NRMSE.rank(method='average')
    piv = med.pivot(index='source_file', columns='algorithm', values='NRMSE')[ALGORITHMS]
    fr = friedmanchisquare(*[piv[c] for c in ALGORITHMS]); fried[model] = (float(fr.statistic), float(fr.pvalue))
    for a in ALGORITHMS:
        m_ = med[med.algorithm==a]; da = d[d.algorithm==a]
        perf_rows.append(dict(model=model, algorithm=a, mean_spec_median_NRMSE=m_.NRMSE.mean(),
            median_spec_median_NRMSE=m_.NRMSE.median(), mean_rank=m_['rank'].mean(),
            success_rate=da.success.mean(), median_rel_gap=da.rel_gap.median(), p90_rel_gap=da.rel_gap.quantile(.9),
            worst_rel_gap=da.rel_gap.max(), median_runtime_ms=1000*da.runtime_sec.median(),
            rescue_trials=int(da.rescue_trials.sum()), rescue_success=int(da.rescue_success.sum()),
            mean_pHO=da.mean_pHO.mean(), final_pHO=da.final_pHO.mean()))
    tmp = []
    for c in [x for x in ALGORITHMS if x != 'ASHO-LSHADE']:
        delta = (piv[c] - piv['ASHO-LSHADE']).to_numpy(); rel = delta/piv['ASHO-LSHADE'].to_numpy()
        try: W, p = wilcoxon(piv['ASHO-LSHADE'], piv[c])
        except ValueError: W, p = np.nan, 1.0
        md, lo_, hi_ = boot_median(delta)
        nz = delta[delta != 0]; rk = rankdata(np.abs(nz)); rb = (rk[nz>0].sum()-rk[nz<0].sum())/rk.sum() if len(nz) else 0
        tmp.append(dict(model=model, comparator=c, W=W, p_raw=p, median_delta_NRMSE=md, boot95_low=lo_, boot95_high=hi_,
                        rank_biserial=rb, ASHO_wins=int((rel>TIE).sum()), ties=int((abs(rel)<=TIE).sum()), ASHO_losses=int((rel<-TIE).sum())))
    tmp = pd.DataFrame(tmp); tmp['p_holm'] = holm(tmp.p_raw); stat_rows.append(tmp)
perf = pd.DataFrame(perf_rows); stats = pd.concat(stat_rows, ignore_index=True)
perf['rescue_success_rate'] = perf.rescue_success/perf.rescue_trials.replace(0, np.nan)
perf.to_csv(TAB/'Table_optimizer_performance.csv', index=False); stats.to_csv(TAB/'Table_paired_statistics.csv', index=False)
log('performance\n' + perf.round(5).to_string()); log('stats\n' + stats.round(5).to_string()); log('friedman', fried)

ext_perf = ext_df.groupby(['model','algorithm']).agg(success_rate=('success','mean'), median_rel_gap=('rel_gap','median'),
           p90_rel_gap=('rel_gap', lambda x: x.quantile(.9)), median_NRMSE=('NRMSE','median')).reset_index()
ext_perf.to_csv(TAB/'Table_extended_budget.csv', index=False); log('extended\n' + ext_perf.round(5).to_string())

# ======================== 6. parameter spread among near-optimal runs (flat valleys)
spread = []
for model in ['M10_ColeL','M11_RCPEL']:
    names = MODELS[model][0]
    d = runs_df[(runs_df.model==model) & runs_df.success]
    for (sf, a), g in d.groupby(['source_file','algorithm']):
        if len(g) < 3: continue
        row = dict(model=model, source_file=sf, algorithm=a, n_success=len(g))
        for n in names: row[n+'_range'] = g[n].max() - g[n].min()
        spread.append(row)
spread = pd.DataFrame(spread); spread.to_csv(TAB/'Table_near_optimal_parameter_spread.csv', index=False)
spread_sum = spread.groupby(['model','algorithm']).median(numeric_only=True).reset_index()
spread_sum.to_csv(TAB/'Table_near_optimal_parameter_spread_summary.csv', index=False)
log('near-optimal spread\n' + spread_sum.round(4).to_string())

# ========================================= 7. identifiability: Jacobian + profiles
ident = []
for model in ['M10_ColeL','M11_RCPEL']:
    names = MODELS[model][0]
    for s in SPECTRA:
        x, J = ref[(model, s['sf'])]; cond, smin = jacobian_svd(model, x, s['w'], s['z'])
        ident.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], point='best-known', algorithm='-',
                          cond=cond, smin=smin))
        for a in ['L-SHADE','ASHO-LSHADE']:
            g = runs_df[(runs_df.model==model)&(runs_df.source_file==s['sf'])&(runs_df.algorithm==a)]
            row = g.iloc[(g.NRMSE - g.NRMSE.median()).abs().argmin()]
            c2, s2 = jacobian_svd(model, row[names].to_numpy(float), s['w'], s['z'])
            ident.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], point='median run', algorithm=a, cond=c2, smin=s2))
ident = pd.DataFrame(ident); ident.to_csv(TAB/'Table_jacobian_identifiability.csv', index=False)
cond_test = []
for model in ['M10_ColeL','M11_RCPEL']:
    q = ident[(ident.model==model)&(ident.point=='median run')].pivot(index='source_file', columns='algorithm', values='cond')
    W, p = wilcoxon(np.log10(q['ASHO-LSHADE']), np.log10(q['L-SHADE']))
    cond_test.append(dict(model=model, median_cond_LSHADE=q['L-SHADE'].median(), median_cond_ASHO=q['ASHO-LSHADE'].median(),
                          ASHO_lower_count=int((q['ASHO-LSHADE']<q['L-SHADE']).sum()), n=len(q), wilcoxon_p=p))
best_cond = ident[ident.point=='best-known'].groupby('model').cond.agg(['median','min','max']).reset_index()
cond_test = pd.DataFrame(cond_test); cond_test.to_csv(TAB/'Table_condition_number_tests.csv', index=False)
best_cond.to_csv(TAB/'Table_condition_number_best_known.csv', index=False)
log('cond tests\n' + cond_test.to_string()); log('best-known cond\n' + best_cond.to_string())

prof_rows, prof_curves = [], []
for model in ['M10_ColeL','M11_RCPEL']:
    names = MODELS[model][0]
    for s in SPECTRA:
        x, _ = ref[(model, s['sf'])]
        def _prof(x=x, s=s, model=model, names=names):
            rng = np.random.default_rng(SEED0+99+s['si']); pr, pc = [], []
            for pi, pn in enumerate(names):
                grid, lr, lo_ci, hi_ci, bounded = profile_likelihood(model, s['w'], s['z'], x, pi, 21 if QUICK else 41, rng)
                pr.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], parameter=pn, estimate=x[pi],
                               ci_low=lo_ci, ci_high=hi_ci, ci_width=hi_ci-lo_ci, identifiable=bounded))
                for g_, l_ in zip(grid, lr): pc.append((model, s['sf'], pn, g_, l_))
            return pr, pc
        pr, pc = cached(f'prof_{model}_{s["sf"]}', _prof); prof_rows += pr; prof_curves += pc
        log(f'profiles {model} {s["sf"][:32]}')
prof = pd.DataFrame(prof_rows); prof.to_csv(TAB/'Table_profile_likelihood.csv', index=False)
pd.DataFrame(prof_curves, columns=['model','source_file','parameter','value','LR']).to_csv(TAB/'profile_curves.csv', index=False)
prof_sum = prof.groupby(['model','parameter']).agg(identifiable_spectra=('identifiable','sum'), n=('identifiable','size'),
            median_ci_width=('ci_width','median')).reset_index()
prof_sum.to_csv(TAB/'Table_profile_summary.csv', index=False); log('profiles\n' + prof_sum.to_string())

# ===================================== 8. band coverage: where is f_c relative to data?
band = []
for s in SPECTRA:
    x, _ = ref[('M10_ColeL', s['sf'])]
    p = prof[(prof.model=='M10_ColeL')&(prof.source_file==s['sf'])&(prof.parameter=='logtau')].iloc[0]
    band.append(dict(source_file=s['sf'], tissue=s['tissue'], fc_hat_hz=1/(2*np.pi*10**x[2]),
                     fc_ci_low_hz=1/(2*np.pi*10**p.ci_high), fc_ci_high_hz=1/(2*np.pi*10**p.ci_low),
                     fc_below_band=1/(2*np.pi*10**x[2]) < 10e3, Z10k_ohm=abs(s['z'][0]), Z100k_ohm=abs(s['z'][-1]),
                     R0_hat_ohm=10**x[0]+10**x[1]))
band = pd.DataFrame(band); band.to_csv(TAB/'Table_fc_band_coverage.csv', index=False)
log('band\n' + band.round(2).to_string())

# ===================================== 9. physical descriptors from identifiable M11
phys = []
for s in SPECTRA:
    x, J = ref[('M11_RCPEL', s['sf'])]
    pr = prof[(prof.model=='M11_RCPEL')&(prof.source_file==s['sf'])].set_index('parameter')
    phys.append(dict(source_file=s['sf'], tissue=s['tissue'], NRMSE=math.sqrt(J), Rinf_ohm=10**x[0], Q=10**x[1], alpha=x[2],
                     L_H=10**x[3], ZCPE_50k_ohm=abs(1/(10**x[1]*(1j*2*np.pi*5e4)**x[2])),
                     Rinf_ci=f'{10**pr.loc["logRinf","ci_low"]:.0f}-{10**pr.loc["logRinf","ci_high"]:.0f}',
                     alpha_ci=f'{pr.loc["alpha","ci_low"]:.3f}-{pr.loc["alpha","ci_high"]:.3f}'))
phys = pd.DataFrame(phys); phys.to_csv(TAB/'Table_M11_physical_parameters.csv', index=False)
log('phys\n' + phys.round(5).to_string())

# =========================================== 10. synthetic recovery experiment
def synth(regime, i):
    rng = np.random.default_rng(SEED0 + (0 if regime=='A' else 50000) + i)
    Rinf = 10**rng.uniform(np.log10(500), np.log10(5000)); a = rng.uniform(0.60, 0.95); L = 10**rng.uniform(-3.4, -2.6)
    fc = 10**rng.uniform(np.log10(15e3), np.log10(60e3)) if regime=='A' else 10**rng.uniform(np.log10(50), np.log10(2e3))
    tau = 1/(2*np.pi*fc)
    # choose dR so that |Z| at 10 kHz is ~2-4x Rinf (as in the real spectra)
    w = 2*np.pi*1000*TARGET_FREQ; target = rng.uniform(2, 4)*Rinf
    dR = 10**np.interp(0, [0,1], [0,0]) ; lo, hi = 0.0, 9.0
    for _ in range(60):
        mid = (lo+hi)/2; zt = predict('M10_ColeL', [np.log10(Rinf), mid, np.log10(tau), a, np.log10(L)], w)
        lo, hi = (mid, hi) if abs(zt[0]) < target else (lo, mid)
    x = np.array([np.log10(Rinf), (lo+hi)/2, np.log10(tau), a, np.log10(L)])
    z0 = predict('M10_ColeL', x, w)
    z = z0 + 0.01*np.abs(z0)*(rng.standard_normal(10) + 1j*rng.standard_normal(10))/np.sqrt(2)
    return x, w, z
syn = []
for regime in ['A','B']:
    for i in range(SYN_N):
        xt, w, z = synth(regime, i); logQt = xt[3]*xt[2] - xt[1]
        def _syn(regime=regime, i=i, xt=xt, w=w, z=z, logQt=logQt):
          syn = []
          for r in range(SYN_RUNS):
            seed = SEED0 + 777000 + (0 if regime=='A' else 1000) + i*100 + r
            for a in ALGORITHMS:
                xh, fb, tr, ex, sec = run_algorithm(a, 'M10_ColeL', w, z, BUDGET, seed)
                err = np.abs(xh - xt)
                syn.append(dict(regime=regime, spectrum=i, run=r+1, algorithm=a, NRMSE=math.sqrt(fb),
                                fc_true_hz=1/(2*np.pi*10**xt[2]), **{f'abs_err_{n}': e for n, e in zip(MODELS['M10_ColeL'][0], err)},
                                abs_err_logQ=abs((xh[3]*xh[2]-xh[1]) - logQt)))
          return syn
        syn += cached(f'syn_{regime}_{i}', _syn)
    log('synthetic regime', regime, 'done')
syn = pd.DataFrame(syn); syn.to_csv(TAB/'synthetic_recovery_runs.csv', index=False)
syn_sum = syn.groupby(['regime','algorithm']).median(numeric_only=True).drop(columns=['spectrum','run']).reset_index()
syn_sum.to_csv(TAB/'Table_synthetic_recovery.csv', index=False); log('synthetic\n' + syn_sum.round(4).to_string())

# ============================================================= 11. manifest
man = dict(protocol='ASHO-EIS-v2.0 (revised)', quick=QUICK, runs=RUNS, budget=BUDGET, ext_runs=EXT_RUNS, ext_budget=EXT_BUDGET,
           seed_formula='SEED0 + spectrum_index*1000 + run_index', SEED0=SEED0, success_definition='NRMSE within 0.1% of best-known',
           tie_definition='relative spectrum-median NRMSE difference <= 0.1%', n_spectra=len(SPECTRA),
           frequency_grid_khz=TARGET_FREQ.tolist(), raw_zip_sha256=hashlib.sha256(RAW_ZIP.read_bytes()).hexdigest(),
           python=sys.version, platform=platform.platform(), numpy=np.__version__, pandas=pd.__version__,
           friedman=fried)
json.dump(man, open(OUT/'reproducibility_manifest.json','w'), indent=2, default=str)
log('ALL DONE')
