"""run_m12.py - higher-dimensional stress test (8-parameter double Cole + L), resumable."""
import sys; sys.argv=[sys.argv[0]]
exec(open('run_experiment.py').read().split('# ======================================================== 2. ECM screening')[0])
CPS=(100,200,500,1000,1500,2000)
def bench(model, algs, runs, budget):
    rows=[]; names=MODELS[model][0]
    for s in SPECTRA:
        def _one(s=s):
            out=[]
            for r in range(runs):
                seed=SEED0+s['si']*1000+r
                for a in algs:
                    x,fb,tr,ex,sec=run_algorithm(a,model,s['w'],s['z'],budget,seed,CPS)
                    out.append(dict(model=model,source_file=s['sf'],tissue=s['tissue'],algorithm=a,run=r+1,NRMSE=math.sqrt(fb),
                        runtime_sec=sec,**ex,**{f'trace_{k}':math.sqrt(v) for k,v in tr.items()},**dict(zip(names,x))))
            return out
        rows+=cached(f'm12_{s["sf"]}',_one); log('m12',s['sf'][:30])
    return pd.DataFrame(rows)
df=bench('M12_DoubleColeL',ALGORITHMS,RUNS,BUDGET)
best=df.groupby('source_file').NRMSE.min().rename('ref')
# polish reference with multistart least squares
refs={}
for s in SPECTRA:
    cand=df[df.source_file==s['sf']].nsmallest(5,'NRMSE')[MODELS['M12_DoubleColeL'][0]].to_numpy()
    x,rss=cached('m12ref_'+s['sf'],lambda: best_fit('M12_DoubleColeL',s['w'],s['z'],list(cand),np.random.default_rng(5+s['si']),30))
    refs[s['sf']]=min(math.sqrt(rss/len(s['w'])),best[s['sf']])
df['ref']=df.source_file.map(refs); df['rel_gap']=(df.NRMSE-df.ref)/df.ref; df['success']=df.rel_gap<=1e-3
df.to_csv(TAB/'optimizer_runs_M12.csv',index=False)
med=df.groupby(['source_file','algorithm']).NRMSE.median().unstack()[ALGORITHMS]
from scipy.stats import wilcoxon
rows=[]
for a in ALGORITHMS:
    d=df[df.algorithm==a]
    rows.append(dict(algorithm=a,success_rate=d.success.mean(),median_rel_gap=d.rel_gap.median(),p90_rel_gap=d.rel_gap.quantile(.9),
        median_runtime_ms=1000*d.runtime_sec.median(),**{f'success_at_{c}':((d[f'trace_{c}']-d.ref)/d.ref<=1e-3).mean() for c in CPS}))
perf=pd.DataFrame(rows); perf.to_csv(TAB/'Table_M12_performance.csv',index=False)
st=[]
for c in ['L-SHADE','L-SHADE-Restart','SAHO-LSHADE','MS-TRF','HO']:
    W,p=wilcoxon(med['ASHO-LSHADE'],med[c]); st.append(dict(comparator=c,p_raw=p,ASHO_better=int((med[c]>med['ASHO-LSHADE']*(1+1e-3)).sum()),ASHO_worse=int((med[c]<med['ASHO-LSHADE']*(1-1e-3)).sum())))
for c in ['L-SHADE+TRF','MS-TRF']:
    W,p=wilcoxon(med['ASHO-LSHADE+TRF'],med[c]); st.append(dict(comparator=f'ASHO+TRF vs {c}',p_raw=p,ASHO_better=int((med[c]>med['ASHO-LSHADE+TRF']*(1+1e-3)).sum()),ASHO_worse=int((med[c]<med['ASHO-LSHADE+TRF']*(1-1e-3)).sum())))
st=pd.DataFrame(st); st.to_csv(TAB/'Table_M12_paired.csv',index=False)
# per-spectrum success (hardness)
ps=df.groupby(['source_file','algorithm']).success.mean().unstack()[ALGORITHMS]; ps.to_csv(TAB/'Table_M12_success_by_spectrum.csv')
print(perf.round(4).to_string()); print(st.to_string()); print(ps.round(2).to_string()); log('M12 DONE')
