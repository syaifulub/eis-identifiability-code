"""run_rev3.py - repeatability (reading-level bootstrap), linear Kramers-Kronig check, subset mapping."""
import sys; sys.argv=[sys.argv[0]]
exec(open('run_experiment.py').read().split('# ======================================================== 2. ECM screening')[0])
ref = pd.read_csv(TAB/'best_known_solutions.csv')
# ---- reading-level data
raw = []
with zipfile.ZipFile(RAW_ZIP) as zf:
    for s in SPECTRA:
        name = [n for n in zf.namelist() if n.endswith(s['sf']) and '/byExperimentalTask/' in n][0]
        d = pd.read_csv(zf.open(name), sep=';', comment='%', header=None, names=COLS, engine='python').dropna(subset=['frequency_khz']).drop_duplicates()
        d['source_file'] = s['sf']; raw.append(d)
raw = pd.concat(raw)
nread = raw.groupby(['source_file','frequency_khz']).size()
log('readings per frequency: median', nread.median(), 'min', nread.min(), 'max', nread.max())
# ---- subset (acquisition group) mapping
sub = {}
with zipfile.ZipFile(RAW_ZIP) as zf:
    for n in zf.namelist():
        if '/byOriginalSubset/' in n and n.endswith('.txt'): sub.setdefault(Path(n).name, Path(n).parent.name)
mapping = pd.DataFrame([(s['sf'], s['tissue'], sub.get(s['sf'], 'n/a')) for s in SPECTRA], columns=['source_file','tissue','original_subset'])
mapping.to_csv(TAB/'Table_subset_mapping.csv', index=False); log('subset mapping\n' + mapping.original_subset.value_counts().to_string())
# ---- linear Kramers-Kronig (Voigt basis + R + L + C, |Z|-weighted linear least squares)
kk = []
for s in SPECTRA:
    w, z = s['w'], s['z']; M = 5
    taus = np.logspace(np.log10(1/w.max()), np.log10(1/w.min()), M)
    cols = [np.ones_like(w)+0j, 1j*w, 1/(1j*w)] + [1/(1+1j*w*t) for t in taus]
    A = np.array(cols).T; wt = 1/np.abs(z)
    Ar = np.vstack([(A*wt[:,None]).real, (A*wt[:,None]).imag]); br = np.r_[(z*wt).real, (z*wt).imag]
    c, *_ = np.linalg.lstsq(Ar, br, rcond=None); zk = A @ c
    rr = (zk.real - z.real)/np.abs(z); ri = (zk.imag - z.imag)/np.abs(z)
    kk.append(dict(source_file=s['sf'], tissue=s['tissue'], kk_rms_pct=100*np.sqrt(np.mean(np.r_[rr, ri]**2)),
                   kk_max_pct=100*np.max(np.abs(np.r_[rr, ri]))))
kk = pd.DataFrame(kk); kk = kk.merge(ref[ref.model=='M11_RCPEL'][['source_file','ref_NRMSE']], on='source_file')
kk.to_csv(TAB/'Table_KK_check.csv', index=False)
from scipy.stats import spearmanr
log('KK\n' + kk.round(3).to_string()); log('Spearman KK rms vs M11 NRMSE', spearmanr(kk.kk_rms_pct, kk.ref_NRMSE))
# ---- reading-level bootstrap repeatability
B = 40
def _boot(s):
    d = raw[raw.source_file == s['sf']]; rng = np.random.default_rng(SEED0 + 4242 + s['si']); out = []
    groups = [g for _, g in d.groupby('frequency_khz')]
    for b in range(B):
        pick = [g.iloc[rng.integers(len(g))] for g in groups]
        zb = np.array([p.resistance_ohm + 1j*p.reactance_ohm for p in pick])
        for m in ['M10_ColeL', 'M11_RCPEL']:
            names = MODELS[m][0]; x0 = ref[(ref.model==m)&(ref.source_file==s['sf'])][names].to_numpy(float)[0]
            x, rss = best_fit(m, s['w'], zb, [x0], rng, 4)
            out.append(dict(source_file=s['sf'], tissue=s['tissue'], model=m, b=b, NRMSE=math.sqrt(rss/10), **dict(zip(names, x))))
    return out
rows = []
for s in SPECTRA:
    rows += cached('boot_' + s['sf'], lambda s=s: _boot(s)); log('boot', s['sf'][:30])
bt = pd.DataFrame(rows); bt['logQ_M10'] = np.where(bt.model=='M10_ColeL', bt.alpha*bt.logtau - bt.logdR, np.nan)
bt.to_csv(TAB/'repeatability_bootstrap_fits.csv', index=False)
rep = []
for m, params in [('M10_ColeL', ['logRinf','logdR','logtau','alpha','logL','logQ_M10']), ('M11_RCPEL', ['logRinf','logQ','alpha','logL'])]:
    d = bt[bt.model==m]
    for p in params:
        within_sd = d.groupby('source_file')[p].std(); means = d.groupby('source_file')[p].mean()
        vw = (within_sd**2).mean(); vb = means.var()
        rep.append(dict(model=m, parameter=p, median_within_SD=within_sd.median(), p90_within_SD=within_sd.quantile(.9),
                        between_SD=np.sqrt(vb), ICC=vb/(vb+vw)))
rep = pd.DataFrame(rep); rep.to_csv(TAB/'Table_repeatability.csv', index=False); log('repeatability\n' + rep.round(4).to_string())
log('REV3 DONE')
