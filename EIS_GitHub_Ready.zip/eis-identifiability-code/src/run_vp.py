"""run_vp.py - benchmark of the variable-projection algorithms (same spectra, seeds, budget, checkpoints)."""
import sys, math, pickle, time, re
import numpy as np, pandas as pd
from pathlib import Path
from vp_common import *; from vp_core import *
SEED0 = 20261101; RUNS = int(sys.argv[2]) if len(sys.argv) > 2 else 25; BUDGET = 2000
CPS = (100, 200, 500, 1000, 1500, 2000)
CACHE = TAB.parent/'cache_vp'; CACHE.mkdir(exist_ok=True)
model = sys.argv[1]; names = MODELS[model][0]
S = load_spectra()
rows = []
for s in S:
    p = CACHE/(f'{model}_'+re.sub(r'[^A-Za-z0-9_.-]', '_', s['sf'])+f'_{RUNS}.pkl')
    if p.exists(): out = pickle.load(open(p, 'rb'))
    else:
        out = []
        for r in range(RUNS):
            seed = SEED0 + s['si']*1000 + r
            for a in VP_ALGORITHMS:
                x, fb, tr, sec = run_vp(a, model, s['w'], s['z'], BUDGET, seed, CPS)
                out.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], algorithm=a, run=r+1, seed=seed,
                                NRMSE=math.sqrt(fb), objective=fb, runtime_sec=sec,
                                **{f'trace_{c}': math.sqrt(v) for c, v in tr.items()}, **dict(zip(names, x))))
        pickle.dump(out, open(p, 'wb'))
    rows += out; print(time.strftime('%H:%M:%S'), model, s['si'], s['sf'][:40], flush=True)
pd.DataFrame(rows).to_csv(TAB/f'vp_runs_{model}.csv', index=False)
print('DONE', model)
