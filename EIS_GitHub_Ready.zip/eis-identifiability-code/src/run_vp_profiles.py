"""run_vp_profiles.py - profile likelihood with a GLOBAL inner optimisation made cheap by VarPro.
For each profiled value, the linear coefficients are solved exactly and the remaining nonlinear
parameters (1-2 dims) are optimised by a dense grid followed by local polishing, so the inner
problem does not depend on random restarts. Same grid, likelihood-ratio statistic, 3.84 threshold
and identifiability rule as eis_core.profile_likelihood."""
import time, math, numpy as np, pandas as pd
from scipy.optimize import least_squares, minimize_scalar
from vp_common import *; from vp_core import VarPro, VP_SPECS, basis, bounded_lstsq
from eis_core import MODELS

class FixedVP(VarPro):
    """VarPro with one linear coefficient fixed at value cfix (column moved to the right-hand side)."""
    def __init__(self, model, w, z, jfix, cfix):
        super().__init__(model, w, z); self.j, self.cf = jfix, cfix
        k = len(self.sp['llo']); self.keep = [i for i in range(k) if i != jfix]
    def solve(self, t):
        A = basis(self.model, t, self.w)*self.wt[:, None]; Ar = np.vstack([A.real, A.imag])
        rhs = self.b - Ar[:, self.j]*self.cf
        c, rss = bounded_lstsq(Ar[:, self.keep], rhs, self.sp['llo'][self.keep], self.sp['lhi'][self.keep])
        return c, rss, None
    def res(self, t):
        A = basis(self.model, t, self.w)*self.wt[:, None]; Ar = np.vstack([A.real, A.imag])
        rhs = self.b - Ar[:, self.j]*self.cf
        c, _ = bounded_lstsq(Ar[:, self.keep], rhs, self.sp['llo'][self.keep], self.sp['lhi'][self.keep])
        return Ar[:, self.keep] @ c - rhs

def min_nonlinear(vp, lo, hi, fixed=None):
    """global minimum of the reduced RSS over the free nonlinear parameters (1 or 2 dims).
    fixed=(index, value) fixes one nonlinear parameter."""
    D = len(lo); free = [i for i in range(D) if not (fixed and i == fixed[0])]
    def full(u):
        t = np.empty(D); t[free] = u
        if fixed: t[fixed[0]] = fixed[1]
        return t
    if len(free) == 0: return vp.f(full([]))*vp.N
    if len(free) == 1:
        i = free[0]; vs = np.linspace(lo[i], hi[i], 81); hv = np.array([vp.f(full([v])) for v in vs]); k = int(hv.argmin())
        r = minimize_scalar(lambda v: vp.f(full([v])), bounds=(vs[max(0, k-1)], vs[min(80, k+1)]), method='bounded',
                            options={'xatol': 1e-7})
        return min(r.fun, hv[k])*vp.N
    g0 = np.linspace(lo[0], hi[0], 33); g1 = np.linspace(lo[1], hi[1], 15)
    P = np.array([[a, b] for a in g0 for b in g1]); hv = np.array([vp.f(p) for p in P]); best = hv.min()*vp.N
    for k in np.argsort(hv)[:3]:
        r = least_squares(vp.res, P[k], bounds=(lo, hi), xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400)
        best = min(best, 2*r.cost)
    return best

def profile(model, s, xhat, pname):
    names, LO, HI = MODELS[model]; p = names.index(pname); n = 2*len(s['w'])
    span = 0.05*(HI[p]-LO[p])
    grid = np.unique(np.clip(np.r_[np.linspace(LO[p], HI[p], 41), xhat[p] + np.linspace(-span, span, 21), xhat[p]], LO[p], HI[p]))
    sp = VP_SPECS[model]; lo, hi = sp['lo'], sp['hi']; vp = VarPro(model, s['w'], s['z'])
    lin_map = {'M10_ColeL': {'logRinf': (0, 1), 'logdR': (1, 1), 'logL': (2, 1)},
               'M11_RCPEL': {'logRinf': (0, 1), 'logQ': (1, -1), 'logL': (2, 1)}}[model]
    prof = []
    for g in grid:
        if pname in sp['nl']:
            prof.append(min_nonlinear(vp, lo, hi, fixed=(sp['nl'].index(pname), g)))
        else:
            j, sgn = lin_map[pname]; fvp = FixedVP(model, s['w'], s['z'], j, 10.0**(sgn*g))
            prof.append(min_nonlinear(fvp, lo, hi))
    prof = np.array(prof); rss_min = min(prof.min(), min_nonlinear(vp, lo, hi))
    lr = n*np.log(prof/rss_min); thr = 3.84; i0 = int(np.argmin(lr))
    def cross(a, b): return grid[a] + (thr-lr[a])*(grid[b]-grid[a])/(lr[b]-lr[a]) if lr[b] != lr[a] else grid[a]
    j = i0
    while j > 0 and lr[j-1] <= thr: j -= 1
    lo_ci = cross(j, j-1) if j > 0 else grid[0]
    j = i0
    while j < len(grid)-1 and lr[j+1] <= thr: j += 1
    hi_ci = cross(j, j+1) if j < len(grid)-1 else grid[-1]
    return dict(ci_low=lo_ci, ci_high=hi_ci, ci_width=hi_ci-lo_ci, identifiable=bool(lr[0] > thr and lr[-1] > thr)), grid, lr

if __name__ == '__main__':
    S = load_spectra(); ref = pd.read_csv(TAB/'best_known_solutions.csv'); rows = []; curves = []
    t0 = time.perf_counter()
    for model in ['M10_ColeL', 'M11_RCPEL']:
        names = MODELS[model][0]
        for s in S:
            r = ref[(ref.model == model) & (ref.source_file == s['sf'])].iloc[0]; xhat = r[names].to_numpy(float)
            for pn in names:
                out, grid, lr = profile(model, s, xhat, pn)
                rows.append(dict(model=model, source_file=s['sf'], tissue=s['tissue'], parameter=pn, estimate=xhat[names.index(pn)], **out))
                curves += [dict(model=model, source_file=s['sf'], parameter=pn, value=g, LR=l) for g, l in zip(grid, lr)]
        print(time.strftime('%H:%M:%S'), model, 'done', flush=True)
    sec = time.perf_counter() - t0
    V = pd.DataFrame(rows); V.to_csv(TAB/'Table_VP_profile_likelihood.csv', index=False)
    pd.DataFrame(curves).to_csv(TAB/'vp_profile_curves.csv', index=False)
    old = pd.read_csv(TAB/'Table_profile_likelihood.csv')
    m = V.merge(old, on=['model', 'source_file', 'parameter'], suffixes=('_vp', '_old'))
    comp = m.groupby(['model', 'parameter']).agg(identifiable_old=('identifiable_old', 'sum'), identifiable_vp=('identifiable_vp', 'sum'),
              agree=('identifiable_vp', lambda x: int((x == m.loc[x.index, 'identifiable_old']).sum())),
              median_width_old=('ci_width_old', 'median'), median_width_vp=('ci_width_vp', 'median')).reset_index()
    comp.to_csv(TAB/'Table_VP_profile_comparison.csv', index=False)
    print(comp.round(3).to_string()); print('total VP profile time (s):', round(sec, 1))
