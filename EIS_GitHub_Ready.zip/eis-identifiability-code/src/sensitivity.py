"""sensitivity.py - robustness of the main conclusions to the small sample:
leave-one-animal(subset)-out, KK-consistent spectra only, and bootstrap over spectra."""
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
from pathlib import Path
T = Path(__file__).parent.parent/'results'/'tables'
sub = pd.read_csv(T/'Table_subset_mapping.csv').set_index('source_file').original_subset
kk = pd.read_csv(T/'Table_KK_check.csv').set_index('source_file').kk_rms_pct
prof = pd.read_csv(T/'Table_VP_profile_likelihood.csv')
SETS = {'All spectra': lambda s: True}
for g in sorted(sub.unique()): SETS[f'Without {g}'] = (lambda s, g=g: sub[s] != g)
SETS['KK-consistent only'] = lambda s: kk[s] < 3
rng = np.random.default_rng(20261017); rows = []
for name, keep in SETS.items():
    rec = dict(subset=name)
    for m, tag in [('M10_ColeL', 'M10'), ('M12_DoubleColeL', 'M12')]:
        d = pd.read_csv(T/f'vp_merged_{m}.csv'); d = d[d.source_file.map(keep)]
        rec['n_spectra'] = d.source_file.nunique()
        for a in ['L-SHADE', 'ASHO-LSHADE', 'MS-TRF', 'VP-L-SHADE', 'VP-ASHO-LSHADE', 'VP-MS-TRF']:
            rec[f'{tag} {a}'] = 100*d[d.algorithm == a].success.mean()
        med = d.groupby(['source_file', 'algorithm']).NRMSE.median().unstack()
        rel = (med['VP-MS-TRF']-med['MS-TRF'])/med['MS-TRF']
        rec[f'{tag} VP-MS better/worse'] = f"{int((rel < -1e-3).sum())}/{int((rel > 1e-3).sum())}"
        try: rec[f'{tag} p VP-ASHO vs VP-L-SHADE'] = wilcoxon(med['VP-ASHO-LSHADE'], med['VP-L-SHADE']).pvalue
        except ValueError: rec[f'{tag} p VP-ASHO vs VP-L-SHADE'] = 1.0
        # bootstrap over spectra: difference in success rate VP-MS-TRF - MS-TRF
        sr = d.groupby(['source_file', 'algorithm']).success.mean().unstack()
        diff = (sr['VP-MS-TRF']-sr['MS-TRF']).to_numpy(); B = [diff[rng.integers(0, len(diff), len(diff))].mean() for _ in range(10000)]
        rec[f'{tag} dSuccess VP-MS minus MS (pp)'] = 100*diff.mean(); rec[f'{tag} dSuccess CI95'] = f"{100*np.quantile(B, .025):.1f} to {100*np.quantile(B, .975):.1f}"
    p = prof[prof.source_file.map(keep)]
    for m, pn in [('M10_ColeL', 'logtau'), ('M10_ColeL', 'logdR'), ('M11_RCPEL', 'logQ'), ('M11_RCPEL', 'alpha')]:
        x = p[(p.model == m) & (p.parameter == pn)]
        rec[f'{m[:3]} {pn} identifiable'] = f"{int(x.identifiable.sum())}/{len(x)}"
    rows.append(rec)
R = pd.DataFrame(rows); R.to_csv(T/'Table_sensitivity.csv', index=False)
pd.set_option('display.width', 250); print(R.T.to_string())
