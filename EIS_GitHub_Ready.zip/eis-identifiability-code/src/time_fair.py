"""Same-machine timing: original MS-TRF vs VP-MS-TRF, wall-clock time to first reach the best-known value (0.1%)."""
import time, math, numpy as np, pandas as pd, sys
from vp_common import *; from vp_core import VarPro, vp_ms_trf
from eis_core import ms_trf, make_objective, MODELS, Tracker
import eis_core, vp_core
SEED0 = 20261101; RUNS = int(sys.argv[1]) if len(sys.argv) > 1 else 5
class TimedTracker(Tracker):
    target = None
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self.t0 = time.perf_counter(); self.t_hit = None; self.n_hit = None
    def __call__(self, x):
        v = super().__call__(x)
        if self.t_hit is None and self.best <= TimedTracker.target:
            self.t_hit = time.perf_counter()-self.t0; self.n_hit = self.nfe
        return v
eis_core.Tracker = TimedTracker; vp_core.Tracker = TimedTracker
rows = []
for model in ['M11_RCPEL', 'M10_ColeL', 'M12_DoubleColeL']:
    d = pd.read_csv(TAB/f'vp_merged_{model}.csv'); ref = d.groupby('source_file').ref.first()
    _, lo, hi = MODELS[model]
    for s in load_spectra():
        TimedTracker.target = (ref[s['sf']]*(1+1e-3))**2
        for r in range(RUNS):
            seed = SEED0 + s['si']*1000 + r
            for name in ['MS-TRF', 'VP-MS-TRF']:
                cap = {}
                orig_init = TimedTracker.__init__
                def init(self, *a, **k): orig_init(self, *a, **k); cap['T'] = self
                TimedTracker.__init__ = init
                t0 = time.perf_counter()
                if name == 'MS-TRF': ms_trf(model, s['w'], s['z'], lo, hi, 2000, seed)
                else: vp_ms_trf(VarPro(model, s['w'], s['z']), 2000, seed, ())
                tot = time.perf_counter()-t0; TimedTracker.__init__ = orig_init; T = cap['T']
                rows.append(dict(model=model, source_file=s['sf'], run=r+1, algorithm=name, total_sec=tot,
                                 hit=T.t_hit is not None, sec_to_hit=T.t_hit, nfe_to_hit=T.n_hit))
    print(model, 'done', flush=True)
D = pd.DataFrame(rows); D.to_csv(TAB/f'vp_fair_timing_runs_{RUNS}.csv', index=False)
S = D.groupby(['model', 'algorithm']).agg(runs=('hit', 'size'), success=('hit', 'mean'), median_ms_to_hit=('sec_to_hit', lambda x: 1000*x.median()),
        p90_ms_to_hit=('sec_to_hit', lambda x: 1000*x.quantile(.9)), median_nfe_to_hit=('nfe_to_hit', 'median'),
        median_total_ms_2000NFE=('total_sec', lambda x: 1000*x.median())).reset_index()
S.to_csv(TAB/f'Table_VP_fair_timing_{RUNS}runs.csv', index=False); print(S.round(2).to_string())
# all-run statistics used in Table 4 of the manuscript (unsuccessful runs counted as infinite time)
D['t'] = np.where(D.hit, 1000*D.sec_to_hit, np.inf); rows = []
for m, g in D.groupby('model'):
    p = g.pivot_table(index=['source_file', 'run'], columns='algorithm', values='t', aggfunc='first'); a, b = p['MS-TRF'], p['VP-MS-TRF']
    rows.append(dict(model=m, ms_median_all=np.median(a), vp_median_all=np.median(b), ms_q1=np.quantile(a, .25), ms_q3=np.quantile(a, .75),
                     vp_q1=np.quantile(b, .25), vp_q3=np.quantile(b, .75), vp_faster_pct=100*np.mean(b < a),
                     ms_success=100*np.isfinite(a).mean(), vp_success=100*np.isfinite(b).mean()))
A = pd.DataFrame(rows); A.to_csv(TAB/'Table_VP_fair_timing_allruns.csv', index=False); print(A.round(2).to_string())
