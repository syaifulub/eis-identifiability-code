import numpy as np, pandas as pd
from pathlib import Path
TAB = Path(__file__).parent.parent/'results'/'tables'
def load_spectra():
    d = pd.read_csv(TAB/'ecm_ready_complete_scans.csv'); S = []
    for si, (sf, g) in enumerate(d.groupby('source_file')):
        g = g.sort_values('frequency_hz')
        S.append(dict(si=si, sf=sf, tissue=g.tissue.iloc[0], w=2*np.pi*g.frequency_hz.to_numpy(float),
                      z=g.resistance_ohm.to_numpy(float)+1j*g.reactance_ohm.to_numpy(float)))
    return S
