"""
vp_core.py - Variable-projection (VarPro) reformulation of the ECM fitting problems.

Every model used in the study is *separable*: given its nonlinear parameters
(relaxation times and dispersion exponents) the impedance is a linear
combination of fixed basis functions,

    M10  Z = Rinf*1 + dR*C(w;tau,alpha)            + L*jw     nonlinear: (log tau, alpha)
    M11  Z = Rinf*1 + (1/Q)*(jw)^(-alpha)          + L*jw     nonlinear: (alpha)
    M12  Z = Rinf*1 + dR1*C(w;tau1,a1) + dR2*C(w;tau2,a2) + L*jw
                                                              nonlinear: (log tau1, log tau2, a1, a2)

with C(w;tau,a) = 1/(1+(jw tau)^a). For any value of the nonlinear parameters the
optimal linear coefficients follow from a weighted, box-bounded linear least-squares
problem (same weights 1/max(|Z|,1) as the original objective, same bounds as the
original log10 bounds). The reduced objective
        J_VP(theta_nl) = min_c J(theta_nl, c)
has the same global minimum as the full objective, but lives in 1 (M11), 2 (M10)
or 4 (M12) dimensions instead of 4, 5 and 8 (Golub & Pereyra 1973, 2003).

NFE accounting: one evaluation of J_VP builds the basis once (the cost of one
model evaluation) and solves a <=4-column linear least-squares problem; it is
counted as ONE function evaluation. Wall-clock time is reported separately so that
this convention can be checked.
"""
import itertools, math, random, time
import numpy as np
from scipy.optimize import least_squares, minimize_scalar, nnls
from eis_core import MODELS, Tracker, lshade_family, _Budget, POP0

# nonlinear parameter spaces and linear coefficient bounds (linear scale)
VP_SPECS = {
    'M10_ColeL': dict(nl=['logtau', 'alpha'], lo=np.array([-7., 0.30]), hi=np.array([1., 1.0]),
                      lin=['Rinf', 'dR', 'L'], llo=10.0**np.array([-3., -3., -9.]), lhi=10.0**np.array([7., 8., 0.])),
    'M11_RCPEL': dict(nl=['alpha'], lo=np.array([0.30]), hi=np.array([1.0]),
                      lin=['Rinf', 'invQ', 'L'], llo=10.0**np.array([-3., 0., -9.]), lhi=10.0**np.array([7., 12., 0.])),
    'M12_DoubleColeL': dict(nl=['logtau1', 'logtau2', 'alpha1', 'alpha2'],
                      lo=np.array([-7., -7., 0.30, 0.30]), hi=np.array([1., 1., 1.0, 1.0]),
                      lin=['Rinf', 'dR1', 'dR2', 'L'], llo=10.0**np.array([-3., -3., -3., -9.]),
                      lhi=10.0**np.array([7., 8., 8., 0.])),
}

def basis(model, t, w):
    jw = 1j*w; one = np.ones_like(w) + 0j
    if model == 'M10_ColeL':
        return np.column_stack([one, 1/(1 + (jw*10**t[0])**t[1]), jw])
    if model == 'M11_RCPEL':
        return np.column_stack([one, jw**(-t[0]), jw])
    if model == 'M12_DoubleColeL':
        return np.column_stack([one, 1/(1 + (jw*10**t[0])**t[2]), 1/(1 + (jw*10**t[1])**t[3]), jw])
    raise KeyError(model)

def _enum_lstsq(A, b, lb, ub):
    """Exact box-bounded least squares by active-set enumeration (k<=4 columns).
    Convex problem: the optimum is the best feasible candidate over all active sets."""
    k = A.shape[1]; s = np.linalg.norm(A, axis=0); s[s == 0] = 1.0; As = A/s
    best_c, best_v = None, math.inf
    for state in itertools.product((0, 1, 2), repeat=k):       # 0 free, 1 lower, 2 upper
        st = np.array(state); cc = np.where(st == 1, lb, np.where(st == 2, ub, 0.0))
        free = np.flatnonzero(st == 0)
        if len(free):
            cc[free] = np.linalg.lstsq(As[:, free], b - A @ cc, rcond=None)[0]/s[free]
            if np.any(cc[free] < lb[free]*(1-1e-12)) or np.any(cc[free] > ub[free]*(1+1e-12)): continue
        r = A @ cc - b; v = float(r @ r)
        if v < best_v: best_v, best_c = v, cc
    return best_c, best_v

def bounded_lstsq(A, b, lb, ub):
    """min ||A c - b||^2 s.t. lb <= c <= ub. Fast path: shift to c = lb + d, d >= 0, and
    solve the column-scaled NNLS problem (Lawson-Hanson). The upper bounds are far from
    any physically meaningful value and are almost never active; if the NNLS solution
    violates one, the exact active-set enumeration is used instead."""
    s = np.linalg.norm(A, axis=0); s[s == 0] = 1.0
    d, _ = nnls(A/s, b - A @ lb, maxiter=50*A.shape[1])
    c = lb + d/s
    if np.all(c <= ub):
        r = A @ c - b; return c, float(r @ r)
    # clamp the violated coefficients at their upper bound, re-solve NNLS for the rest and
    # verify the KKT conditions (exact certificate for this convex problem)
    up = c > ub
    for _ in range(A.shape[1]):
        fr = ~up; cc = np.where(up, ub, lb)
        rhs = b - A[:, up] @ ub[up] - A[:, fr] @ lb[fr]
        d, _ = nnls(A[:, fr]/s[fr], rhs, maxiter=50*A.shape[1]); cc[fr] = lb[fr] + d/s[fr]
        newup = up | (cc > ub)
        if np.array_equal(newup, up): break
        up = newup
    r = A @ cc - b; g = A.T @ r
    if np.all(cc <= ub*(1+1e-12)) and np.all(g[up] <= 1e-10*max(1.0, float(np.abs(g).max()))):
        return cc, float(r @ r)
    return _enum_lstsq(A, b, lb, ub)

class VarPro:
    def __init__(self, model, w, z):
        self.model, self.w, self.z = model, w, z
        sp = VP_SPECS[model]; self.sp = sp; self.N = len(w)
        self.wt = 1.0/np.maximum(np.abs(z), 1.0)
        zw = z*self.wt; self.b = np.r_[zw.real, zw.imag]
    def solve(self, t):
        A = basis(self.model, t, self.w)*self.wt[:, None]
        Ar = np.vstack([A.real, A.imag])
        c, rss = bounded_lstsq(Ar, self.b, self.sp['llo'], self.sp['lhi'])
        return c, rss, Ar
    def f(self, t):                       # reduced objective J = RSS/N (same scale as eis_core)
        return self.solve(np.asarray(t, float))[1]/self.N
    def res(self, t):                     # reduced residual vector for TRF
        c, _, Ar = self.solve(np.asarray(t, float)); return Ar @ c - self.b
    def full_params(self, t):
        """map (nonlinear, linear) back to the original log10 parameter vector of eis_core.MODELS."""
        t = np.asarray(t, float); c, _, _ = self.solve(t); lc = np.log10(np.maximum(c, self.sp['llo']))
        if self.model == 'M10_ColeL':  return np.array([lc[0], lc[1], t[0], t[1], lc[2]])
        if self.model == 'M11_RCPEL':  return np.array([lc[0], -lc[1], t[0], lc[2]])
        return np.array([lc[0], lc[1], t[0], lc[2], t[1], t[2], t[3], lc[3]])

# ------------------------------------------------------------- algorithms
def _vp_trf_loop(vp, T, starts, rng, lo, hi, budget):
    def res(t):
        if T.nfe >= budget: raise _Budget
        T(t); return vp.res(t)
    k = 0
    while T.nfe < budget:
        x0 = starts[k] if k < len(starts) else rng.uniform(lo, hi); k += 1
        try:
            least_squares(res, np.clip(x0, lo, hi), bounds=(lo, hi), jac='2-point', max_nfev=10000)
        except _Budget:
            break

def vp_ms_trf(vp, budget, seed, cps):
    lo, hi = vp.sp['lo'], vp.sp['hi']; T = Tracker(vp.f, budget, cps); rng = np.random.default_rng(seed)
    _vp_trf_loop(vp, T, [], rng, lo, hi, budget); return T

def vp_screen_trf(vp, budget, seed, cps, n_screen=None, n_polish=3):
    """Space-filling screen of the (small) nonlinear space, TRF polish from the best
    screened points, then random multistart TRF until the budget is spent."""
    lo, hi = vp.sp['lo'], vp.sp['hi']; D = len(lo); rng = np.random.default_rng(seed)
    T = Tracker(vp.f, budget, cps)
    if n_screen is None: n_screen = {1: 21, 2: 60, 4: 150}[D]
    if D == 1:
        pts = np.linspace(lo, hi, n_screen)
        pts = np.clip(pts + rng.uniform(-0.5, 0.5, pts.shape)*(hi-lo)/(n_screen-1), lo, hi)
    else:   # Latin hypercube
        u = (np.argsort(rng.random((D, n_screen)), axis=1).T + rng.random((n_screen, D)))/n_screen
        pts = lo + u*(hi-lo)
    vals = [T(p) for p in pts]
    order = np.argsort(vals); starts = [pts[i] for i in order[:n_polish]]
    _vp_trf_loop(vp, T, starts, rng, lo, hi, budget); return T

def vp_lshade(vp, budget, seed, cps, mode):
    lo, hi = vp.sp['lo'], vp.sp['hi']
    x, fb, tr, ex = lshade_family(vp.f, lo, hi, budget, seed, mode, cps)
    T = Tracker(vp.f, budget, ()); T.best = fb; T.xbest = list(x); T.trace = tr; T.extra = ex; return T

def vp_lshade_trf(vp, budget, seed, cps, mode='lshade', frac=0.5):
    lo, hi = vp.sp['lo'], vp.sp['hi']; b1 = int(frac*budget)
    x1, f1, tr1, ex = lshade_family(vp.f, lo, hi, b1, seed, mode, cps)
    T = Tracker(vp.f, budget, cps); T.nfe = b1; T.best = f1; T.xbest = list(x1)
    while T.ci < len(T.cps) and T.cps[T.ci] <= b1: T.ci += 1
    starts = [np.asarray(p, float) for p in ex.pop('final_pop')]
    _vp_trf_loop(vp, T, starts, np.random.default_rng(seed), lo, hi, budget)
    T.trace = {**tr1, **T.trace}; return T

VP_ALGORITHMS = ['VP-L-SHADE', 'VP-ASHO-LSHADE', 'VP-MS-TRF', 'VP-L-SHADE+TRF', 'VP-Screen+TRF']

def run_vp(name, model, w, z, budget, seed, cps=()):
    vp = VarPro(model, w, z); t0 = time.perf_counter()
    if name == 'VP-L-SHADE':       T = vp_lshade(vp, budget, seed, cps, 'lshade')
    elif name == 'VP-ASHO-LSHADE': T = vp_lshade(vp, budget, seed, cps, 'asho')
    elif name == 'VP-MS-TRF':      T = vp_ms_trf(vp, budget, seed, cps)
    elif name == 'VP-L-SHADE+TRF': T = vp_lshade_trf(vp, budget, seed, cps)
    elif name == 'VP-Screen+TRF':  T = vp_screen_trf(vp, budget, seed, cps)
    else: raise KeyError(name)
    sec = time.perf_counter() - t0
    tr = dict(T.trace)
    for c in cps:                                  # carry best value forward if run ended early
        if c not in tr: tr[c] = T.best
    return vp.full_params(T.xbest), T.best, tr, sec

# ------------------------------------------------------ exact cheap profiles
def vp_profile(model, w, z, pname, grid, inner_grid=61):
    """Profile likelihood through VarPro: the profiled parameter is fixed, the remaining
    NONLINEAR parameters are optimised (grid + bounded refinement) and all linear ones
    are solved exactly. Returns RSS(grid) on the eis_core residual scale."""
    vp = VarPro(model, w, z); sp = vp.sp; j = sp['nl'].index(pname); others = [i for i in range(len(sp['nl'])) if i != j]
    out = []
    for g in grid:
        if not others:
            out.append(vp.f([g])*vp.N); continue
        i = others[0]                               # M10: one remaining nonlinear parameter
        def h(v, g=g):
            t = np.empty(2); t[j] = g; t[i] = v; return vp.f(t)
        vs = np.linspace(sp['lo'][i], sp['hi'][i], inner_grid); hv = [h(v) for v in vs]; k = int(np.argmin(hv))
        a, b = vs[max(0, k-1)], vs[min(len(vs)-1, k+1)]
        r = minimize_scalar(h, bounds=(a, b), method='bounded', options={'xatol': 1e-6})
        out.append(min(r.fun, hv[k])*vp.N)
    return np.array(out)
