This folder contains the fully processed and corrected dataset, obtained after applying all procedures described in the Data Quality Assurance section. The data provided here represent the final curated version used for validation, statistical analysis, and classification experiments.

The data preserves the original hierarchical subdivision based on subject identity, measurement configuration, acquisition type.



To facilitate reuse and reproducibility, the final processed dataset is organized in two complementary ways:

1. Organization by Original Subset: the dataset preserves the original hierarchical subdivision based on subject identity, measurement configuration and acquisition type.
2. Organization by Experimental Task: the dataset is reorganized according to the implementation task, matching the experiments described in the manuscript. this structure allows users to directly access data subsets required for specific modeling tasks, reproduce classification experiments, benchmark alternative algorithms, develop new task-specific approaches.
